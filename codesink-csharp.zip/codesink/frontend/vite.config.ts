import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// В докере фронт и API — разные контейнеры, обращаться к "localhost" оттуда
// нельзя, нужно имя сервиса из docker-compose. Локально (без докера)
// используется дефолт localhost:8090.
const apiTarget = process.env.API_PROXY_TARGET || "http://localhost:8090";

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    watch: {
      usePolling: true,
    },
    proxy: {
      "/api": apiTarget,
    },
  },
});
