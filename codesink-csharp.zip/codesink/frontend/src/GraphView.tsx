import { useEffect, useRef } from "react";
import cytoscape from "cytoscape";
import dagre from "cytoscape-dagre";
import { GraphNode, GraphEdge, Finding } from "./api";

cytoscape.use(dagre);

type Props = {
  nodes: GraphNode[];
  /// Все рёбра графа (все резолвленные вызовы) — рисуются целиком, если
  /// focusPath не задан.
  edges: GraphEdge[];
  /// Путь конкретного finding — если задан, показываем только его (focus
  /// mode), а не весь граф проекта целиком.
  focusPath?: string[] | null;
  /// Id узла, вокруг которого нужно свернуть граф (сам узел + прямые
  /// входящие/исходящие связи) — для деклаттеринга плотных реальных
  /// графов. Игнорируется, если задан focusPath.
  isolateNodeId?: string | null;
  onNodeClick?: (nodeId: string) => void;
  findings?: Finding[];
};

export default function GraphView({ nodes, edges, focusPath, isolateNodeId, onNodeClick, findings = [] }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    let idsToShow: Set<string>;
    if (focusPath) {
      idsToShow = new Set(focusPath);
    } else if (isolateNodeId) {
      idsToShow = new Set([isolateNodeId]);
      for (const e of edges) {
        if (e.source === isolateNodeId) idsToShow.add(e.target);
        if (e.target === isolateNodeId) idsToShow.add(e.source);
      }
    } else {
      idsToShow = new Set(nodes.map((n) => n.id));
    }

    const visibleNodes = nodes.filter((n) => idsToShow.has(n.id));

    const sourceIds = new Set(findings.map((f) => f.source_key));
    const sinkFnIds = new Set(findings.filter((f) => f.path.length > 0).map((f) => f.path[f.path.length - 1]));

    const elements: cytoscape.ElementDefinition[] = [
      ...visibleNodes.map((n) => {
        const isSource = sourceIds.has(n.id);
        const isSink = sinkFnIds.has(n.id);
        const role = isSource && isSink ? "both" : isSource ? "source" : isSink ? "sink" : undefined;
        const shortFile = n.file.split("/").pop() || n.file;
        return {
          data: { id: n.id, label: `${n.label}\n${shortFile}:${n.start_line}`, role },
        };
      }),
    ];

    if (focusPath) {
      // Focus mode: рисуем только рёбра конкретного пути, по порядку.
      for (let i = 0; i < focusPath.length - 1; i++) {
        elements.push({
          data: {
            id: `${focusPath[i]}->${focusPath[i + 1]}`,
            source: focusPath[i],
            target: focusPath[i + 1],
          },
        });
      }
    } else {
      // Полный граф: все резолвленные вызовы между показанными узлами.
      for (const e of edges) {
        if (idsToShow.has(e.source) && idsToShow.has(e.target)) {
          elements.push({
            data: { id: `${e.source}->${e.target}`, source: e.source, target: e.target },
          });
        }
      }
    }

    const cy = cytoscape({
      container: containerRef.current,
      elements,
      style: [
        {
          selector: "node",
          style: {
            label: "data(label)",
            "font-size": 9,
            "font-family": "JetBrains Mono, monospace",
            color: "#eae6f5",
            "background-color": "#241d35",
            "border-width": 2,
            "border-color": "#3d3159",
            "text-wrap": "wrap",
            "text-max-width": "140px",
            width: 24,
            height: 24,
          } as any,
        },
        {
          selector: 'node[role="source"]',
          style: {
            "background-color": "#0c4a6e",
            "border-color": "#38bdf8",
            "border-width": 3,
            "shadow-blur": 18,
            "shadow-color": "#38bdf8",
            "shadow-opacity": 0.6,
          } as any,
        },
        {
          selector: 'node[role="sink"]',
          style: {
            "background-color": "#7f1d1d",
            "border-color": "#fb7185",
            "border-width": 3,
            "shadow-blur": 18,
            "shadow-color": "#fb7185",
            "shadow-opacity": 0.6,
          } as any,
        },
        {
          selector: 'node[role="both"]',
          style: {
            "background-color": "#4c1d95",
            "border-color": "#c084fc",
            "border-width": 3,
            "shadow-blur": 20,
            "shadow-color": "#c084fc",
            "shadow-opacity": 0.7,
          } as any,
        },
        {
          selector: "edge",
          style: {
            width: 1.8,
            "line-color": "#6d3fa8",
            "target-arrow-color": "#a855f7",
            "target-arrow-shape": "triangle",
            "curve-style": "bezier",
            opacity: 0.7,
          },
        },
      ],
      layout: { name: "dagre" } as any,
    });

    if (onNodeClick) {
      cy.on("tap", "node", (evt) => onNodeClick(evt.target.id()));
    }

    return () => cy.destroy();
  }, [nodes, edges, focusPath, isolateNodeId, findings]);

  return (
    <div
      ref={containerRef}
      style={{ width: "100%", height: "600px", background: "radial-gradient(circle at 30% 20%, #1a1428 0%, #0d0b14 70%)", borderRadius: 8 }}
    />
  );
}
