import { useEffect, useState } from "react";
import {
  Checklist,
  ChecklistItem,
  ChecklistRow,
  getChecklist,
  addChecklistItem,
  updateChecklistItem,
  deleteChecklistItem,
  promoteChecklistItem,
  addChecklistRow,
  updateChecklistRow,
  deleteChecklistRow,
} from "./api";

type Props = { projectId: string };

// Порядок и заголовки generic-секций (не зависят от языка/домена проекта).
const GENERIC_SECTIONS: { key: string; title: string }[] = [
  { key: "architecture_overview", title: "0. Общее понимание приложения" },
  { key: "trust_boundary", title: "1. Trust Boundary Map" },
  { key: "sast_triage", title: "5. SAST/MobSF триаж" },
  { key: "sc_configuration", title: "Configuration" },
  { key: "sc_input_validation", title: "Input Validation" },
  { key: "sc_output_encoding", title: "Output Encoding" },
  { key: "sc_authentication", title: "Authentication" },
  { key: "sc_authorization", title: "Authorization" },
  { key: "sc_session", title: "Session Management" },
  { key: "sc_cryptography", title: "Cryptography" },
  { key: "sc_error_handling", title: "Error & Exception Handling" },
  { key: "sc_attack_surface", title: "Reducing Attack Surface" },
  { key: "sc_secure_transmission", title: "Secure Transmission" },
  { key: "sc_logging", title: "Log Management" },
];

const TABLE_SECTIONS: Record<string, { title: string; columns: { key: string; label: string }[] }> = {
  data_classification: {
    title: "2. Data & Asset Classification",
    columns: [
      { key: "field", label: "Поле/эндпоинт" },
      { key: "onetrust", label: "OneTrust" },
      { key: "docs", label: "Документация" },
      { key: "code", label: "Видно в коде" },
      { key: "conclusion", label: "Вывод" },
    ],
  },
  authz_mapping: {
    title: "3. AuthN/AuthZ Mapping",
    columns: [
      { key: "entry_point", label: "Entry point" },
      { key: "who_can_call", label: "Кто может вызвать" },
      { key: "check_on_entry", label: "Проверка на входе в либу" },
      { key: "check_at_caller", label: "Проверка у caller'а" },
      { key: "documented", label: "Задокументирован" },
      { key: "status", label: "Статус" },
    ],
  },
};

const DOMAIN_LABELS: Record<string, string> = {
  kotlin_android: "Kotlin — Android",
  rust_cli: "Rust — CLI",
  rust_web: "Rust — Web",
  rust_blockchain: "Rust — Smart Contract / Blockchain",
  go_cli: "Go — CLI",
  go_web: "Go — Web",
  javascript_web: "JavaScript/TypeScript — Web",
  python_web: "Python — Web",
  python_ai: "Python — AI",
  csharp_web: "C# / .NET — Web & Services",
};

// Домены одного базового языка — если найдено больше одного, показываем
// выпадающий список для выбора активного, а не все сразу вперемешку.
const LANG_GROUPS: Record<string, string[]> = {
  Go: ["go_web", "go_cli"],
  Rust: ["rust_web", "rust_cli", "rust_blockchain"],
};

// Доп. стандарты, подмешиваемые по домену: 'web' — общий маркер для любого
// *_web домена (ASVS/WSTG общие для всех веб-языков, не дублируем).
const STANDARD_SECTIONS: { domain: string; section: string; title: string }[] = [
  { domain: "kotlin_android", section: "masvs", title: "OWASP MASVS" },
  { domain: "kotlin_android", section: "mstg", title: "OWASP MASTG" },
  { domain: "web", section: "asvs", title: "OWASP ASVS" },
  { domain: "web", section: "wstg", title: "OWASP WSTG" },
  { domain: "python_ai", section: "llm_top10", title: "OWASP Top 10 for LLM Applications" },
  { domain: "rust_blockchain", section: "sc_top10", title: "OWASP Smart Contract Top 10" },
];

export default function ChecklistView({ projectId }: Props) {
  const [data, setData] = useState<Checklist | null>(null);
  const [newItemLabel, setNewItemLabel] = useState<Record<string, string>>({});
  const [activeDomain, setActiveDomain] = useState<Record<string, string>>({});

  useEffect(() => {
    load();
  }, [projectId]);

  async function load() {
    setData(await getChecklist(projectId));
  }

  async function toggleItem(item: ChecklistItem) {
    await updateChecklistItem(item.id, !item.checked, item.notes);
    load();
  }

  async function saveNotes(item: ChecklistItem, notes: string) {
    await updateChecklistItem(item.id, item.checked, notes);
  }

  async function handleAddItem(section: string, language: string | null) {
    const key = `${section}:${language ?? ""}`;
    const label = (newItemLabel[key] || "").trim();
    if (!label) return;
    await addChecklistItem(projectId, section, language, label);
    setNewItemLabel((prev) => ({ ...prev, [key]: "" }));
    load();
  }

  async function handleDeleteItem(id: string) {
    await deleteChecklistItem(id);
    load();
  }

  async function handlePromote(id: string) {
    await promoteChecklistItem(id);
    load();
  }

  async function handleAddRow(section: string, columns: { key: string }[]) {
    const empty: Record<string, string> = {};
    columns.forEach((c) => (empty[c.key] = ""));
    await addChecklistRow(projectId, section, empty);
    load();
  }

  async function handleRowCellChange(row: ChecklistRow, key: string, value: string) {
    const updated = { ...row.data, [key]: value };
    await updateChecklistRow(row.id, updated);
  }

  async function handleDeleteRow(id: string) {
    await deleteChecklistRow(id);
    load();
  }

  if (!data) return <div className="empty-state">Загружаю чек-лист...</div>;

  function renderCheckboxSection(section: string, language: string | null = null) {
    const items = data!.items.filter((i) => i.section === section && i.language === language);
    const key = `${section}:${language ?? ""}`;
    return (
      <div key={key} style={{ marginBottom: 12 }}>
        {items.map((item) => (
          <div key={item.id} className="card" style={{ marginBottom: 8, padding: 12 }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <input type="checkbox" checked={item.checked} onChange={() => toggleItem(item)} style={{ marginTop: 3 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5 }}>{item.label}</div>
                <textarea
                  placeholder="Заметки / вывод..."
                  defaultValue={item.notes}
                  onBlur={(e) => saveNotes(item, e.target.value)}
                  style={{
                    width: "100%",
                    marginTop: 6,
                    background: "var(--bg-panel-2)",
                    border: "1px solid var(--border)",
                    borderRadius: 6,
                    color: "var(--text)",
                    fontSize: 12,
                    padding: 6,
                    minHeight: 32,
                    fontFamily: "var(--font-body)",
                  }}
                />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                {item.is_custom && (
                  <button className="btn-ghost" style={{ fontSize: 11, padding: "2px 6px" }} onClick={() => handlePromote(item.id)} title="Сделать пунктом по умолчанию для будущих проектов">
                    ⬆ в шаблон
                  </button>
                )}
                <button className="btn-ghost" style={{ fontSize: 11, padding: "2px 6px" }} onClick={() => handleDeleteItem(item.id)}>
                  удалить
                </button>
              </div>
            </div>
          </div>
        ))}
        <div style={{ display: "flex", gap: 6 }}>
          <input
            value={newItemLabel[key] || ""}
            onChange={(e) => setNewItemLabel((prev) => ({ ...prev, [key]: e.target.value }))}
            onKeyDown={(e) => e.key === "Enter" && handleAddItem(section, language)}
            placeholder="+ добавить свой пункт"
            style={{
              flex: 1,
              background: "var(--bg-panel-2)",
              border: "1px solid var(--border)",
              borderRadius: 6,
              color: "var(--text)",
              padding: "6px 10px",
              fontSize: 13,
            }}
          />
          <button className="btn btn-ghost" onClick={() => handleAddItem(section, language)}>
            Добавить
          </button>
        </div>
      </div>
    );
  }

  function renderTableSection(section: string) {
    const cfg = TABLE_SECTIONS[section];
    const rows = data!.rows.filter((r) => r.section === section);
    return (
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
          <thead>
            <tr>
              {cfg.columns.map((c) => (
                <th key={c.key} style={{ textAlign: "left", padding: "6px 8px", borderBottom: "1px solid var(--border)", color: "var(--text-dim)", fontWeight: 500 }}>
                  {c.label}
                </th>
              ))}
              <th />
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                {cfg.columns.map((c) => (
                  <td key={c.key} style={{ padding: "4px 8px", borderBottom: "1px solid var(--border)" }}>
                    <input
                      defaultValue={row.data[c.key] || ""}
                      onBlur={(e) => handleRowCellChange(row, c.key, e.target.value)}
                      style={{ width: "100%", background: "transparent", border: "none", color: "var(--text)", fontSize: 12.5, padding: 4 }}
                    />
                  </td>
                ))}
                <td style={{ borderBottom: "1px solid var(--border)" }}>
                  <span onClick={() => handleDeleteRow(row.id)} style={{ cursor: "pointer", opacity: 0.5, padding: "0 6px" }}>
                    ×
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="btn btn-ghost" style={{ marginTop: 8 }} onClick={() => handleAddRow(section, cfg.columns)}>
          + строка
        </button>
      </div>
    );
  }

  // Группируем найденные домены по базовому языку (Go/Rust), чтобы решить,
  // нужен ли выпадающий список выбора активного домена.
  const domainGroups: { label: string; domains: string[] }[] = [];
  const consumedDomains = new Set<string>();
  for (const [langLabel, domains] of Object.entries(LANG_GROUPS)) {
    const found = domains.filter((d) => data.languages.includes(d));
    if (found.length > 0) {
      domainGroups.push({ label: langLabel, domains: found });
      found.forEach((d) => consumedDomains.add(d));
    }
  }
  const soloDomains = data.languages.filter((d) => !consumedDomains.has(d) && d !== "web");

  return (
    <div style={{ maxWidth: 900 }}>
      {GENERIC_SECTIONS.map(({ key, title }) => (
        <div className="card" style={{ marginBottom: 20 }} key={key}>
          <h3 style={{ marginTop: 0, fontSize: 14 }}>{title}</h3>
          {renderCheckboxSection(key)}
        </div>
      ))}

      <div className="card" style={{ marginBottom: 20 }}>
        <h3 style={{ marginTop: 0, fontSize: 14 }}>{TABLE_SECTIONS.data_classification.title}</h3>
        {renderTableSection("data_classification")}
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <h3 style={{ marginTop: 0, fontSize: 14 }}>{TABLE_SECTIONS.authz_mapping.title}</h3>
        {renderTableSection("authz_mapping")}
      </div>

      {data.languages.length === 0 && (
        <div className="card" style={{ marginBottom: 20 }}>
          <p style={{ fontSize: 13, color: "var(--text-dim)", margin: 0 }}>
            Домен проекта не определён автоматически — добавь пункты сюда вручную, когда определишься с профилем.
          </p>
        </div>
      )}

      {/* Домены с несколькими вариантами (Go: web/cli, Rust: web/cli/blockchain) — выпадающий список */}
      {domainGroups.map(({ label, domains }) => {
        const active = activeDomain[label] || domains[0];
        return (
          <div key={label} className="card" style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <h3 style={{ margin: 0, fontSize: 14 }}>6. {label}</h3>
              <select
                value={active}
                onChange={(e) => setActiveDomain((prev) => ({ ...prev, [label]: e.target.value }))}
                style={{ background: "var(--bg-panel-2)", border: "1px solid var(--border)", borderRadius: 6, color: "var(--text)", padding: "4px 8px", fontSize: 12 }}
              >
                {domains.map((d) => (
                  <option key={d} value={d}>
                    {DOMAIN_LABELS[d]?.split("— ")[1] || d}
                  </option>
                ))}
              </select>
            </div>
            {renderCheckboxSection("lang_patterns", active)}
          </div>
        );
      })}

      {/* Домены без неоднозначности (Kotlin/Android, JS/Web, Python/Web или AI) */}
      {soloDomains.map((domain) => (
        <div key={domain} className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ marginTop: 0, fontSize: 14 }}>6. {DOMAIN_LABELS[domain] || domain}</h3>
          {renderCheckboxSection("lang_patterns", domain)}
        </div>
      ))}

      {/* OWASP-стандарты по обнаруженным доменам */}
      {STANDARD_SECTIONS.filter((s) => data!.languages.includes(s.domain)).map((s) => (
        <div key={s.section} className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ marginTop: 0, fontSize: 14 }}>{s.title}</h3>
          {renderCheckboxSection(s.section, s.domain)}
        </div>
      ))}
    </div>
  );
}
