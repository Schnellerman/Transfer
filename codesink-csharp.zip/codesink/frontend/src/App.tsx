import { useEffect, useState } from "react";
import {
  createProject,
  uploadFiles,
  analyzeProject,
  getFindings,
  getGraph,
  listAnnotations,
  listProjects,
  getLatestRun,
  deleteProject,
  renameProject,
  generateReport,
  Finding,
  GraphNode,
  GraphEdge,
  Annotation,
  Project,
} from "./api";
import GraphView from "./GraphView";
import CodeViewer from "./CodeViewer";
import Sidebar from "./Sidebar";
import ManualReview from "./ManualReview";
import ChecklistView from "./ChecklistView";

const CONF_COLORS: Record<string, string> = { HIGH: "#fb7185", MEDIUM: "#fbbf24", LOW: "#8b83a8" };

type Tab = "analysis" | "manual" | "checklist";

export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("analysis");
  const [findings, setFindings] = useState<Finding[]>([]);
  const [nodes, setNodes] = useState<GraphNode[]>([]);
  const [edges, setEdges] = useState<GraphEdge[]>([]);
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [focusPath, setFocusPath] = useState<string[] | null>(null);
  const [isolateNodeId, setIsolateNodeId] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [status, setStatus] = useState("");
  const [reportsVersion, setReportsVersion] = useState(0);
  const [reportStatus, setReportStatus] = useState("");

  useEffect(() => {
    refreshProjects();
  }, []);

  async function refreshProjects() {
    const p = await listProjects();
    setProjects(p);
    return p;
  }

  async function loadRunData(runId: string) {
    const [f, g] = await Promise.all([getFindings(runId), getGraph(runId)]);
    setFindings(f);
    setNodes(g.nodes);
    setEdges(g.edges);
  }

  async function selectProject(id: string) {
    setProjectId(id);
    setTab("analysis");
    setFocusPath(null);
    setSelectedFile(null);
    setFindings([]);
    setNodes([]);
      setEdges([]);
    setStatus("Загружаю...");

    const [ann, run] = await Promise.all([listAnnotations(id), getLatestRun(id)]);
    setAnnotations(ann);

    if (run.run_id && run.status === "done") {
      await loadRunData(run.run_id);
      setStatus(`Готово: ${run.node_count ?? 0} функций, ${run.findings_count ?? 0} находок`);
    } else if (run.status === "failed") {
      setStatus("Прошлый анализ завершился с ошибкой — попробуй пересчитать.");
    } else {
      setStatus("Анализ ещё не запускался.");
    }
  }

  async function runAnalysis(pid: string) {
    setStatus("Анализирую...");
    const result = await analyzeProject(pid);
    await loadRunData(result.run_id);
    setStatus(`Готово: ${result.node_count} функций, ${result.findings_count} находок`);
  }

  async function handleCreateProject(files: FileList) {
    setStatus("Создаю проект...");
    const project = await createProject(`review-${new Date().toLocaleString("ru-RU")}`);
    await refreshProjects();
    setProjectId(project.id);
    setTab("analysis");
    setAnnotations([]);
    setFindings([]);
    setNodes([]);
      setEdges([]);
    setSelectedFile(null);

    setStatus("Загружаю файлы...");
    await uploadFiles(project.id, files);
    await runAnalysis(project.id);
  }

  async function handleRenameProject(id: string, name: string) {
    await renameProject(id, name);
    await refreshProjects();
  }

  async function handleGenerateReport() {
    if (!projectId) return;
    setReportStatus("Собираю отчёт...");
    try {
      await generateReport(projectId);
      setReportsVersion((v) => v + 1);
      setReportStatus("Готово — смотри в сайдбаре, раздел «Отчёты»");
    } catch (e) {
      setReportStatus("Ошибка при генерации отчёта");
    }
  }

  async function handleDeleteProject(id: string) {
    await deleteProject(id);
    await refreshProjects();
    if (projectId === id) {
      setProjectId(null);
      setFindings([]);
      setNodes([]);
      setEdges([]);
      setAnnotations([]);
      setSelectedFile(null);
      setStatus("");
    }
  }

  function handleNodeClick(nodeId: string) {
    const node = nodes.find((n) => n.id === nodeId);
    if (node) setSelectedFile(node.file);
    setFocusPath(null);
    setIsolateNodeId(nodeId);
  }

  async function handleAnnotated() {
    if (!projectId) return;
    setAnnotations(await listAnnotations(projectId));
  }

  return (
    <div className="app-shell">
      <Sidebar
        projects={projects}
        activeId={projectId}
        onSelect={selectProject}
        onCreate={handleCreateProject}
        onDelete={handleDeleteProject}
        onRename={handleRenameProject}
        reportsVersion={reportsVersion}
      />

      <div className="main">
        <div className="hero-glow" />
        <h1>codesink</h1>
        <div className="subtitle">Kotlin source→sink review · {status || "выбери проект слева или создай новый"}</div>

        {projectId && (
          <>
            <div style={{ display: "flex", gap: 8, marginBottom: 20, alignItems: "center" }}>
              <button
                className={tab === "analysis" ? "btn" : "btn btn-ghost"}
                onClick={() => setTab("analysis")}
              >
                Анализ
              </button>
              <button
                className={tab === "manual" ? "btn" : "btn btn-ghost"}
                onClick={() => setTab("manual")}
              >
                Ручная проверка
              </button>
              <button
                className={tab === "checklist" ? "btn" : "btn btn-ghost"}
                onClick={() => setTab("checklist")}
              >
                Чек-лист
              </button>
              <button className="btn btn-ghost" style={{ marginLeft: "auto" }} onClick={() => runAnalysis(projectId)}>
                ⟳ Пересчитать анализ
              </button>
              <button className="btn" onClick={handleGenerateReport}>
                📄 Сформировать отчёт
              </button>
            </div>
            {reportStatus && <p style={{ fontSize: 12, color: "var(--text-dim)" }}>{reportStatus}</p>}
          </>
        )}

        {!projectId && (
          <div className="empty-state">Выбери проект в списке слева или создай новый, загрузив папку с Kotlin-файлами.</div>
        )}

        {projectId && tab === "analysis" && (
          <>
            {nodes.length === 0 && status.includes("не запускался") && (
              <div className="empty-state">У проекта пока нет результатов анализа.</div>
            )}

            {nodes.length > 0 && (
              <div style={{ display: "flex", gap: 24 }}>
                <div style={{ width: 340, flexShrink: 0 }}>
                  <h3 style={{ fontSize: 14, color: "var(--text-dim)", fontWeight: 500 }}>
                    Находки ({findings.length})
                  </h3>
                  {findings.length === 0 && (
                    <div className="empty-state" style={{ fontSize: 13 }}>
                      Ни одного пути source→sink не найдено автоматически. Загляни во
                      «Ручную проверку», если ожидал находку.
                    </div>
                  )}
                  {findings.map((f, i) => (
                    <div
                      key={i}
                      className="finding-card"
                      onClick={() => { setFocusPath(f.path); setIsolateNodeId(null); }}
                      style={{ background: f.sanitized ? "rgba(52,211,153,0.07)" : "rgba(251,113,133,0.06)" }}
                    >
                      <span
                        className="badge"
                        style={{
                          background: `${CONF_COLORS[f.confidence.toUpperCase()]}33`,
                          color: CONF_COLORS[f.confidence.toUpperCase()],
                        }}
                      >
                        {f.confidence.toUpperCase()}
                      </span>
                      <div style={{ marginTop: 6, fontSize: 13 }}>{f.source_key.split("::").pop()}</div>
                      <div style={{ fontSize: 12, color: "var(--text-dim)" }}>→ {f.sink_key}</div>
                      {f.sanitized && (
                        <div style={{ fontSize: 11, color: "var(--sanitizer)", marginTop: 4 }}>possibly sanitized</div>
                      )}
                    </div>
                  ))}
                </div>
                <div style={{ flex: 1 }} className="card">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                  <span style={{ fontSize: 12, color: "var(--text-dim)" }}>
                    {isolateNodeId ? "Показаны только прямые связи выбранной функции" : focusPath ? "Показан путь конкретной находки" : "Показан весь граф вызовов"}
                  </span>
                  {(isolateNodeId || focusPath) && (
                    <button className="btn btn-ghost" onClick={() => { setIsolateNodeId(null); setFocusPath(null); }}>
                      Показать весь граф
                    </button>
                  )}
                </div>
                <GraphView nodes={nodes} edges={edges} focusPath={focusPath} isolateNodeId={isolateNodeId} onNodeClick={handleNodeClick} findings={findings} />
                </div>
              </div>
            )}

            {selectedFile && (
              <div style={{ marginTop: 24 }} className="card">
                <CodeViewer
                  projectId={projectId}
                  filePath={selectedFile}
                  annotations={annotations}
                  findings={findings}
                  nodes={nodes}
                  onAnnotated={handleAnnotated}
                />
              </div>
            )}
          </>
        )}

        {projectId && tab === "manual" && (
          <ManualReview
            projectId={projectId}
            annotations={annotations}
            findings={findings}
            nodes={nodes}
            selectedFile={selectedFile}
            onSelectFile={setSelectedFile}
            onAnnotated={handleAnnotated}
          />
        )}

        {projectId && tab === "checklist" && <ChecklistView projectId={projectId} />}
      </div>
    </div>
  );
}
