import { useEffect, useRef, useState } from "react";
import { Project, Report, listReports, deleteReport, reportUrl } from "./api";

type Props = {
  projects: Project[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onCreate: (files: FileList) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, name: string) => void;
  reportsVersion: number; // инкрементируй, чтобы форсировать обновление списка отчётов
};

export default function Sidebar({ projects, activeId, onSelect, onCreate, onDelete, onRename, reportsVersion }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const [reports, setReports] = useState<Report[]>([]);

  useEffect(() => {
    listReports().then(setReports);
  }, [reportsVersion]);

  async function handleDeleteReport(id: string, name: string) {
    if (!confirm(`Удалить отчёт "${name}"? Это необратимо.`)) return;
    await deleteReport(id);
    setReports(await listReports());
  }

  function startEditing(p: Project) {
    setEditingId(p.id);
    setEditingValue(p.name);
  }

  function commitEdit() {
    if (editingId && editingValue.trim()) {
      onRename(editingId, editingValue.trim());
    }
    setEditingId(null);
  }

  return (
    <div className="sidebar">
      <div className="sidebar-title">Проекты</div>
      <div style={{ flex: 1, overflowY: "auto" }}>
        {projects.length === 0 && (
          <div style={{ color: "var(--text-dim)", fontSize: 13, padding: "8px" }}>
            Пока нет ни одного проекта
          </div>
        )}
        {projects.map((p) => (
          <div
            key={p.id}
            className={`project-item ${p.id === activeId ? "active" : ""}`}
            style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
          >
            {editingId === p.id ? (
              <input
                autoFocus
                value={editingValue}
                onChange={(e) => setEditingValue(e.target.value)}
                onBlur={commitEdit}
                onKeyDown={(e) => {
                  if (e.key === "Enter") commitEdit();
                  if (e.key === "Escape") setEditingId(null);
                }}
                style={{
                  flex: 1,
                  background: "var(--bg-panel-2)",
                  border: "1px solid var(--accent)",
                  borderRadius: 6,
                  color: "var(--text)",
                  padding: "2px 6px",
                  fontSize: 14,
                }}
              />
            ) : (
              <span
                onClick={() => onSelect(p.id)}
                onDoubleClick={() => startEditing(p)}
                title="Двойной клик — переименовать"
                style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
              >
                {p.name}
              </span>
            )}
            <span
              onClick={(e) => {
                e.stopPropagation();
                if (confirm(`Удалить проект "${p.name}"? Это необратимо.`)) onDelete(p.id);
              }}
              style={{ opacity: 0.5, padding: "0 4px", cursor: "pointer" }}
              title="Удалить проект"
            >
              ×
            </span>
          </div>
        ))}
      </div>

      <input
        ref={inputRef}
        type="file"
        // @ts-expect-error webkitdirectory не типизирован
        webkitdirectory="true"
        multiple
        style={{ display: "none" }}
        onChange={(e) => e.target.files && onCreate(e.target.files)}
      />
      <button className="new-project-btn" onClick={() => inputRef.current?.click()}>
        + Новый проект
      </button>

      <div className="sidebar-title" style={{ marginTop: 20 }}>Отчёты</div>
      <div style={{ maxHeight: 220, overflowY: "auto" }}>
        {reports.length === 0 && (
          <div style={{ color: "var(--text-dim)", fontSize: 12, padding: "8px" }}>
            Пока нет сформированных отчётов
          </div>
        )}
        {reports.map((r) => (
          <div key={r.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 8px", fontSize: 12.5 }}>
            <a
              href={reportUrl(r.id)}
              target="_blank"
              rel="noreferrer"
              style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "var(--text-dim)" }}
              title={new Date(r.created_at).toLocaleString("ru-RU")}
            >
              📄 {r.project_name}
            </a>
            <span onClick={() => handleDeleteReport(r.id, r.project_name)} style={{ opacity: 0.5, padding: "0 4px", cursor: "pointer" }} title="Удалить отчёт">
              ×
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
