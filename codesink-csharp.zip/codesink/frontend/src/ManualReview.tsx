import { useEffect, useState } from "react";
import { listProjectFiles, Annotation, Finding, GraphNode } from "./api";
import CodeViewer from "./CodeViewer";

type Props = {
  projectId: string;
  annotations: Annotation[];
  findings: Finding[];
  nodes: GraphNode[];
  selectedFile: string | null;
  onSelectFile: (file: string) => void;
  onAnnotated: () => void;
};

export default function ManualReview({
  projectId,
  annotations,
  findings,
  nodes,
  selectedFile,
  onSelectFile,
  onAnnotated,
}: Props) {
  const [files, setFiles] = useState<string[]>([]);

  useEffect(() => {
    listProjectFiles(projectId).then((f) => {
      setFiles(f);
      if (!selectedFile && f.length > 0) onSelectFile(f[0]);
    });
  }, [projectId]);

  return (
    <div>
      <p style={{ fontSize: 13, color: "var(--text-dim)", marginBottom: 12 }}>
        Выбери файл проекта и кликни по строке, чтобы вручную отметить её как
        source, sink или sanitizer — полезно, когда автоматика не распознала
        кастомную обёртку или внутренний SDK.
      </p>

      {files.length === 0 && <div className="empty-state">В проекте не найдено .kt файлов.</div>}

      {files.length > 0 && (
        <>
          <select
            value={selectedFile ?? ""}
            onChange={(e) => onSelectFile(e.target.value)}
            style={{
              marginBottom: 12,
              padding: "8px 10px",
              borderRadius: 8,
              background: "var(--bg-panel-2)",
              color: "var(--text)",
              border: "1px solid var(--border)",
              width: "100%",
              maxWidth: 480,
            }}
          >
            {files.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>

          {selectedFile && (
            <div className="card">
              <CodeViewer
                projectId={projectId}
                filePath={selectedFile}
                annotations={annotations}
                findings={findings}
                nodes={nodes}
                onAnnotated={onAnnotated}
              />
            </div>
          )}
        </>
      )}
    </div>
  );
}
