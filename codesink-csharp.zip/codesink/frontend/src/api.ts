export type Finding = {
  id: string;
  source_key: string;
  sink_key: string;
  path: string[];
  sanitized: boolean;
  confidence: string;
  status: string;
};

/// sink_key приходит с бэкенда в формате "имя@файл:строка" (см. db.rs::save_findings).
/// Строка может быть "0" для ручных меток без точной привязки к строке.
export function parseSinkKey(sinkKey: string): { name: string; file: string; line: number } {
  const atIdx = sinkKey.lastIndexOf("@");
  if (atIdx === -1) return { name: sinkKey, file: "", line: 0 };
  const name = sinkKey.slice(0, atIdx);
  const rest = sinkKey.slice(atIdx + 1);
  const colonIdx = rest.lastIndexOf(":");
  if (colonIdx === -1) return { name, file: rest, line: 0 };
  const file = rest.slice(0, colonIdx);
  const line = parseInt(rest.slice(colonIdx + 1), 10) || 0;
  return { name, file, line };
}

export type GraphNode = {
  id: string;
  label: string;
  file: string;
  start_line: number;
};

export type Project = { id: string; name: string; created_at: string };

export async function listProjects(): Promise<Project[]> {
  const res = await fetch("/api/projects");
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export type LatestRun = {
  run_id: string | null;
  status: string | null;
  node_count: number | null;
  edge_count: number | null;
  findings_count: number | null;
};

export async function getLatestRun(projectId: string): Promise<LatestRun> {
  const res = await fetch(`/api/projects/${projectId}/latest-run`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function renameProject(projectId: string, name: string): Promise<void> {
  const res = await fetch(`/api/projects/${projectId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) throw new Error(await res.text());
}

export async function deleteProject(projectId: string): Promise<void> {
  const res = await fetch(`/api/projects/${projectId}`, { method: "DELETE" });
  if (!res.ok) throw new Error(await res.text());
}

export async function listProjectFiles(projectId: string): Promise<string[]> {
  const res = await fetch(`/api/projects/${projectId}/files`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export type ChecklistItem = {
  id: string;
  section: string;
  language: string | null;
  label: string;
  checked: boolean;
  notes: string;
  is_custom: boolean;
};

export type ChecklistRow = { id: string; section: string; data: Record<string, string> };

export type Checklist = { items: ChecklistItem[]; rows: ChecklistRow[]; languages: string[] };

export async function getChecklist(projectId: string): Promise<Checklist> {
  const res = await fetch(`/api/projects/${projectId}/checklist`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function addChecklistItem(
  projectId: string,
  section: string,
  language: string | null,
  label: string
): Promise<{ id: string }> {
  const res = await fetch(`/api/projects/${projectId}/checklist`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ section, language, label }),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function updateChecklistItem(itemId: string, checked: boolean, notes: string): Promise<void> {
  const res = await fetch(`/api/checklist/items/${itemId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ checked, notes }),
  });
  if (!res.ok) throw new Error(await res.text());
}

export async function deleteChecklistItem(itemId: string): Promise<void> {
  const res = await fetch(`/api/checklist/items/${itemId}`, { method: "DELETE" });
  if (!res.ok) throw new Error(await res.text());
}

export async function promoteChecklistItem(itemId: string): Promise<void> {
  const res = await fetch(`/api/checklist/items/${itemId}/promote`, { method: "POST" });
  if (!res.ok) throw new Error(await res.text());
}

export async function addChecklistRow(
  projectId: string,
  section: string,
  data: Record<string, string>
): Promise<{ id: string }> {
  const res = await fetch(`/api/projects/${projectId}/checklist/rows`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ section, data }),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function updateChecklistRow(rowId: string, data: Record<string, string>): Promise<void> {
  const res = await fetch(`/api/checklist/rows/${rowId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ data }),
  });
  if (!res.ok) throw new Error(await res.text());
}

export async function deleteChecklistRow(rowId: string): Promise<void> {
  const res = await fetch(`/api/checklist/rows/${rowId}`, { method: "DELETE" });
  if (!res.ok) throw new Error(await res.text());
}

export type Report = { id: string; project_name: string; created_at: string };

export async function generateReport(projectId: string): Promise<{ id: string }> {
  const res = await fetch(`/api/projects/${projectId}/report`, { method: "POST" });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function listReports(): Promise<Report[]> {
  const res = await fetch(`/api/reports`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function deleteReport(reportId: string): Promise<void> {
  const res = await fetch(`/api/reports/${reportId}`, { method: "DELETE" });
  if (!res.ok) throw new Error(await res.text());
}

export function reportUrl(reportId: string): string {
  return `/api/reports/${reportId}`;
}

export async function createProject(name: string): Promise<{ id: string }> {
  const res = await fetch("/api/projects", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function uploadFiles(projectId: string, files: FileList): Promise<void> {
  const form = new FormData();
  Array.from(files).forEach((f) => form.append("file", f, f.webkitRelativePath || f.name));
  const res = await fetch(`/api/projects/${projectId}/upload`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) throw new Error(await res.text());
}

export async function analyzeProject(
  projectId: string
): Promise<{ run_id: string; node_count: number; edge_count: number; findings_count: number }> {
  const res = await fetch(`/api/projects/${projectId}/analyze`, { method: "POST" });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function getFindings(runId: string): Promise<Finding[]> {
  const res = await fetch(`/api/runs/${runId}/findings`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export type GraphEdge = { source: string; target: string };

export async function getGraph(runId: string): Promise<{ nodes: GraphNode[]; edges: GraphEdge[] }> {
  const res = await fetch(`/api/runs/${runId}/graph`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function getFileContent(projectId: string, path: string): Promise<string> {
  const res = await fetch(`/api/projects/${projectId}/file-content?path=${encodeURIComponent(path)}`);
  if (!res.ok) throw new Error(await res.text());
  return res.text();
}

export async function createAnnotation(
  projectId: string,
  file: string,
  line: number,
  kind: "source" | "sink" | "sanitizer"
): Promise<void> {
  const res = await fetch(`/api/projects/${projectId}/annotations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ file, line, kind }),
  });
  if (!res.ok) throw new Error(await res.text());
}

export type Annotation = { file: string; line: number; kind: string };

export async function listAnnotations(projectId: string): Promise<Annotation[]> {
  const res = await fetch(`/api/projects/${projectId}/annotations`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
