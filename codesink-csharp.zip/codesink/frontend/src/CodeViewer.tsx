import { useEffect, useState } from "react";
import { getFileContent, createAnnotation, Annotation, Finding, GraphNode, parseSinkKey } from "./api";

type Props = {
  projectId: string;
  filePath: string;
  annotations: Annotation[];
  findings: Finding[];
  nodes: GraphNode[];
  onAnnotated: () => void;
};

const KIND_COLORS: Record<string, string> = {
  source: "#38bdf8",
  sink: "#fb7185",
  sanitizer: "#34d399",
};

export default function CodeViewer({ projectId, filePath, annotations, findings, nodes, onAnnotated }: Props) {
  const [lines, setLines] = useState<string[]>([]);
  const [activeLine, setActiveLine] = useState<number | null>(null);

  useEffect(() => {
    getFileContent(projectId, filePath).then((text) => setLines(text.split("\n")));
  }, [filePath, projectId]);

  // Ручная разметка (по клику) — приоритетная, со сплошной цветной рамкой.
  const annotationsByLine = new Map<number, Annotation>();
  for (const a of annotations) {
    if (a.file === filePath) annotationsByLine.set(a.line, a);
  }

  // Автоматически найденные source/sink — мягкая подсветка без рамки.
  const autoByLine = new Map<number, "source" | "sink">();
  for (const f of findings) {
    const sourceNode = nodes.find((n) => n.id === f.source_key);
    if (sourceNode && sourceNode.file === filePath) {
      autoByLine.set(sourceNode.start_line, "source");
    }
    const sink = parseSinkKey(f.sink_key);
    if (sink.file === filePath && sink.line > 0) {
      autoByLine.set(sink.line, "sink");
    }
  }

  async function mark(kind: "source" | "sink" | "sanitizer") {
    if (activeLine === null) return;
    await createAnnotation(projectId, filePath, activeLine, kind);
    setActiveLine(null);
    onAnnotated();
  }

  return (
    <div style={{ fontFamily: "var(--font-mono)", fontSize: 13, background: "#0d0b14", padding: 12, borderRadius: 6, maxHeight: 600, overflow: "auto", border: "1px solid #2b2440" }}>
      <div style={{ marginBottom: 8, opacity: 0.6, display: "flex", justifyContent: "space-between" }}>
        <span>{filePath}</span>
        <span style={{ fontSize: 11 }}>
          <span style={{ color: KIND_COLORS.source }}>● source</span>{" "}
          <span style={{ color: KIND_COLORS.sink }}>● sink</span>{" "}
          <span style={{ color: KIND_COLORS.sanitizer }}>● sanitizer</span>{" "}
          <span style={{ opacity: 0.5 }}>(рамка слева = вручную, заливка = найдено автоматически)</span>
        </span>
      </div>
      {lines.map((line, i) => {
        const lineNo = i + 1;
        const manual = annotationsByLine.get(lineNo);
        const auto = autoByLine.get(lineNo);
        const bg = manual
          ? `${KIND_COLORS[manual.kind]}22`
          : auto
          ? `${KIND_COLORS[auto]}15`
          : activeLine === lineNo
          ? "rgba(168, 85, 247, 0.12)"
          : "transparent";
        const border = manual ? `3px solid ${KIND_COLORS[manual.kind]}` : "3px solid transparent";
        return (
          <div key={lineNo} style={{ position: "relative" }}>
            <div
              onClick={() => setActiveLine(activeLine === lineNo ? null : lineNo)}
              style={{
                display: "flex",
                cursor: "pointer",
                background: bg,
                borderLeft: border,
              }}
              title={auto ? `Автоматически определено как ${auto}` : undefined}
            >
              <span style={{ width: 40, textAlign: "right", opacity: 0.4, marginRight: 12, flexShrink: 0 }}>{lineNo}</span>
              <span style={{ whiteSpace: "pre" }}>{line}</span>
              {auto && !manual && (
                <span style={{ marginLeft: 12, fontSize: 10, opacity: 0.6, color: KIND_COLORS[auto] }}>
                  auto: {auto}
                </span>
              )}
            </div>
            {activeLine === lineNo && (
              <div style={{ display: "flex", gap: 6, padding: "4px 0 4px 52px" }}>
                <button onClick={() => mark("source")} style={{ background: KIND_COLORS.source, border: 0, borderRadius: 4, padding: "2px 8px", color: "#fff", cursor: "pointer" }}>
                  source
                </button>
                <button onClick={() => mark("sink")} style={{ background: KIND_COLORS.sink, border: 0, borderRadius: 4, padding: "2px 8px", color: "#fff", cursor: "pointer" }}>
                  sink
                </button>
                <button onClick={() => mark("sanitizer")} style={{ background: KIND_COLORS.sanitizer, border: 0, borderRadius: 4, padding: "2px 8px", color: "#fff", cursor: "pointer" }}>
                  sanitizer
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
