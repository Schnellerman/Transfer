# codesink — MVP скелет

Web-платформа для secure code review: загружаешь проект, тулза строит call
graph через tree-sitter, находит пути source→sink по конфигурируемым
правилам и рисует их в виде графа. Поддерживает Kotlin (проверено на
реальном коде), плюс заготовки под Go/JS/TS/Rust/Python (не проверены —
см. ниже).

## Архитектура (после мульти-языкового рефакторинга)

```
crates/
  core/        — языко-агностичное ядро: граф вызовов, правила, резолвинг.
                 НЕ знает про tree-sitter вообще.
  lang-kotlin/ — парсер Kotlin (tree-sitter-kotlin 0.3.8). ПРОВЕРЕН.
  lang-go/     — парсер Go (tree-sitter-go). НЕ ПРОВЕРЕН.
  lang-js/     — парсер JS/TS/JSX/TSX (tree-sitter-javascript + typescript). НЕ ПРОВЕРЕН.
  lang-rust/   — парсер Rust (tree-sitter-rust). НЕ ПРОВЕРЕН.
  lang-python/ — парсер Python (tree-sitter-python). НЕ ПРОВЕРЕН.
  api/         — Axum сервер: диспетчеризует файлы по расширению в нужный
                 lang-* крейт (см. api/src/dispatch.rs), объединённый
                 результат отдаёт в codesink_core::analyze_project.
```

Каждый языковой крейт — отдельный, потому что у грамматик разные (иногда
несовместимые) версии зависимости `tree-sitter`. `tree-sitter-kotlin` —
старого стиля, жёстко завязан на `tree-sitter = "0.22"`. Go/JS/TS/Rust/Python
используют новый ABI-шим (`tree-sitter-language`) и реально могли бы жить в
одном крейте на `tree-sitter = "0.25"`, но разнесены для чистоты организации
и независимых `debug_parse` бинарников.

## Как добавить ещё один язык

1. `crates/lang-<name>/` — Cargo.toml + `src/lib.rs` с `pub fn parse_file(path, source) -> Result<ParsedProject>` и `pub fn dump_sexp(...)`, `src/bin/debug_parse.rs` по образцу существующих.
2. Добавь крейт в `[workspace] members` (корневой `Cargo.toml`) и в зависимости `crates/api/Cargo.toml`.
3. Впиши расширение файла в `match` внутри `crates/api/src/dispatch.rs`.
4. `config/rules-<name>.yaml` + впиши путь в `RULE_FILES` в `crates/api/src/main.rs`.
5. **Обязательно** прогони `debug_parse` на реальном файле нужного языка и сверь, что имена функций/вызовов извлекаются верно — как мы делали для Kotlin. Само по себе "скомпилировалось" не значит "работает правильно": разные грамматики по-разному экспонируют name/body/receiver, и позиционный разбор в lang-kotlin принципиально отличается от field-based в lang-go — потому что фактическая структура дерева разная.

`codesink-core` трогать не нужно — там только универсальные структуры
(`FunctionDef`/`CallSite`) и языко-агностичная логика (граф, правила).

## Что уже работает
- Kotlin: полный пайплайн, проверенный на реальном коде (парсинг, резолвинг
  вызовов, source/sink через аннотации и вызовы, ручная разметка).
- Go/JS/TS/Rust/Python: парсеры написаны по документированной структуре
  соответствующих грамматик (в отличие от Kotlin, у них есть нормальные
  именованные поля), но **ни разу не прогонялись на реальном коде**. Со
  значительной вероятностью что-то не так — как минимум стоит ожидать
  разгон по краевым случаям (сложные деструктуризации параметров, дженерики,
  макросы в Rust и т.п.), которые сейчас просто игнорируются, а не ломают
  парсинг целиком (в худшем случае — 0 функций/вызовов там, где они есть).
- Source теперь матчится ДВУМЯ способами: (1) аннотация на объявленной
  функции (Kotlin-стиль), (2) сам факт вызова (`r.URL.Query().Get()` в Go —
  функция, которая его делает, становится точкой старта). Второй способ
  критичен для языков без аннотаций.
- Стартовые правила под все 5 языков в `config/rules-*.yaml` — заведомо
  неполные, это отправная точка, а не финальный список.
- API: создать проект → загрузить файлы (любых поддерживаемых языков сразу,
  можно смешивать) → анализ → находки + граф.
- Фронт: сайдбар с проектами (создание/выбор/удаление), граф с подсветкой
  source/sink, вкладка "Ручная проверка" с выбором любого файла и кликом по
  строке для разметки, подсветка автоматически найденного прямо в коде.

## Что придётся доделать / проверить самому
1. **Для каждого нового языка — обязательный прогон debug_parse на реальном
   файле** (см. выше). Это не формальность: Kotlin потребовал несколько
   раундов правок именно потому, что реальная структура дерева отличалась от
   ожидаемой. У Go/JS/Rust/Python шансы выше (документированные поля), но
   не 100%.
2. **JS decorators/аннотации** — собираются через `prev_sibling()` (ищем
   `decorator`-узлы перед функцией), это самое хрупкое место в lang-js,
   скорее всего потребует правки под конкретную структуру NestJS/Angular
   кода.
3. **Rust-атрибуты** (`#[get("/x")]` в actix-web) вообще не разбираются —
   sources для Rust сейчас работают только через вызовы (`web::Json` как
   параметр не читается). Если тикеты активно используют derive-based
   роутинг — этот кусок надо дописывать.
4. **sqlx offline mode**: не забывай `cargo sqlx prepare --workspace` после
   любого изменения SQL-запросов в `db.rs`/`handlers.rs`.
5. Ручная разметка (`manual_annotations`) есть в БД + API + фронте (вкладка
   "Ручная проверка"), reachability от HTTP-роутов как отдельная категория
   entrypoint пока не выделена.
6. Анализ синхронный (блокирует HTTP-запрос) — ок для одного модуля, для
   целого монорепо стоит вынести в фоновую задачу.

## Запуск

### Вариант А — всё в докере (рекомендуется для повседневного использования)

Единственное, что нужно сделать один раз ДО первого запуска — сгенерировать
offline-кэш sqlx локально (Docker-сборка не видит живую БД на этапе
компиляции, ей нужен этот кэш):

```bash
docker compose up -d postgres
sqlx migrate run --database-url postgres://codesink:codesink@localhost:5432/codesink --source migrations
export DATABASE_URL=postgres://codesink:codesink@localhost:5432/codesink
cargo sqlx prepare --workspace
```

(это уже могло быть сделано раньше — если `.sqlx/` в корне проекта уже
существует, шаг можно пропустить)

После этого — обычный запуск, одной командой:

```bash
docker compose up -d --build
```

Открывай http://localhost:5173. Все три сервиса (Postgres, API, фронт)
поднимаются вместе. Первая сборка API займёт несколько минут (компиляция
Rust + 5 грамматик tree-sitter с нуля), дальше — кэшируется, быстро.

Если менял Rust-код — пересобери только API: `docker compose up -d --build api`.
Фронтенд-файлы (`frontend/src`, `index.html`) смонтированы напрямую с хоста —
их можно редактировать и видеть изменения сразу, без пересборки контейнера
(Vite hot reload через polling — актуально в докере на macOS).

Если менял SQL-запросы в `db.rs`/`handlers.rs` — сначала обнови offline-кэш
на хосте (`cargo sqlx prepare --workspace` с той же переменной `DATABASE_URL`,
что выше), потом уже пересобирай контейнер API.

Загруженные файлы проектов и данные Postgres хранятся в docker volumes
(`codesink_uploads`, `codesink_pgdata`) — переживают перезапуск контейнеров.
`docker compose down -v` сотрёт всё, включая базу — используй с осторожностью.

### Вариант Б — руками, без докера (для активной разработки самого движка)

#### 1. Postgres
```bash
docker compose up -d postgres
cp .env.example .env
```

#### 2. Собрать и запустить API
**Важно для свежей, ещё пустой базы**: `sqlx::query!` — макрос, проверяемый
НА ЭТАПЕ КОМПИЛЯЦИИ (подключается к живой БД прямо во время `cargo build`),
а встроенный `sqlx::migrate!` применяет миграции только ВО ВРЕМЯ ВЫПОЛНЕНИЯ
уже скомпилированной программы. На полностью пустой базе это замкнутый
круг — код не скомпилируется, потому что таблиц ещё нет, а до применения
миграций дело не доходит, потому что компиляция падает раньше. Поэтому на
свежей базе миграции нужно накатить руками ОДИН раз, до первой компиляции:
```bash
docker compose up -d postgres
sqlx migrate run --database-url postgres://codesink:codesink@localhost:5432/codesink --source migrations
```
После этого:
```bash
cargo run -p codesink-api
```
На каждом следующем запуске (когда таблицы уже есть) `sqlx::migrate!`
просто молча подтвердит, что всё применено — вручную гонять `sqlx migrate
run` больше не придётся, пока не появится новая миграция.

Если меняешь SQL-запросы — после этого нужен офлайн-кэш:
```bash
export DATABASE_URL=postgres://codesink:codesink@localhost:5432/codesink
cargo sqlx prepare --workspace
```

#### 3. Проверить парсер нового языка на реальном файле (перед тем как доверять находкам)
```bash
cargo run -p codesink-lang-go --bin debug_parse -- path/to/file.go
cargo run -p codesink-lang-js --bin debug_parse -- path/to/file.ts
cargo run -p codesink-lang-rust --bin debug_parse -- path/to/file.rs
cargo run -p codesink-lang-python --bin debug_parse -- path/to/file.py
cargo run -p codesink-lang-kotlin --bin debug_parse -- path/to/file.kt
```

#### 4. Фронтенд
```bash
cd frontend
npm install
npm run dev
```
Открой http://localhost:5173.

## Перенос на другой компьютер через GitHub

Раз всё запускается через `docker compose`, на другом компьютере **не
понадобится ни Rust, ни Node.js** — только Docker Desktop и git.

### На текущем компьютере (один раз)
```bash
git init
git add .
git commit -m "codesink"
git remote add origin <ссылка-на-твой-репозиторий>
git push -u origin main
```
**Важно**: `.sqlx/` НЕ должен быть в `.gitignore` — это офлайн-кэш sqlx,
без него Docker-сборка на другой машине не соберётся (ей негде взять живую
БД на этапе компиляции). Он уже правильно НЕ игнорируется в текущем
`.gitignore` — просто не добавляй его туда сам.

Также не должны попасть в репозиторий: `.env` (свои секреты/локальные
настройки — есть `.env.example` как шаблон), `target/`, `node_modules/`,
`data/` (загруженные файлы проектов — это runtime-данные, не код).

### На новом компьютере
1. Установи Docker Desktop.
2. `git clone <ссылка> && cd codesink`
3. Разово создай `.env` из шаблона: `cp .env.example .env`
4. Одна команда — и всё поднимется:
   ```bash
   docker compose up -d --build
   ```
   Так как `.sqlx/` уже пришёл вместе с репозиторием, дополнительно гонять
   `cargo sqlx prepare` не нужно — сборка полностью офлайн, из коробки.
5. Открывай http://localhost:5173.

Единственное, что НЕ переносится автоматически — данные внутри Postgres и
загруженные файлы проектов (они живут в docker volumes конкретной машины,
не в git). На новом компьютере будет чистая пустая база — это ожидаемо,
не баг.

### Если меняешь код и хочешь запушить изменения
Ничего особенного — обычный git-флоу. Единственный момент: если менял SQL-
запросы в `db.rs`/`handlers.rs`, перед коммитом обнови офлайн-кэш:
```bash
export DATABASE_URL=postgres://codesink:codesink@localhost:5432/codesink
cargo sqlx prepare --workspace
git add .sqlx
git commit -m "update sqlx cache"
```
Иначе на другом компьютере (или в CI, если заведёшь) сборка будет ссылаться
на устаревшие SQL-схемы.

## Структура
```
codesink/
  crates/
    core/         — граф, правила, резолвинг (языко-агностично)
    lang-kotlin/  — парсер Kotlin (проверен)
    lang-go/      — парсер Go (не проверен)
    lang-js/      — парсер JS/TS (не проверен)
    lang-rust/    — парсер Rust (не проверен)
    lang-python/  — парсер Python (не проверен)
    api/          — Axum сервер + диспетчеризация по расширению
  migrations/0001_init.sql
  config/rules-*.yaml  — по одному файлу на язык, редактируй под свои тикеты
  frontend/
  Dockerfile.api        — сборка API
  frontend/Dockerfile   — сборка фронтенда (dev-режим)
  docker-compose.yml    — все три сервиса разом
```



## C# / .NET

Поддерживаются `.cs` файлы (ASP.NET Core / MVC / Web API / классический System.Web, сервисы, консоль).
Крейт `crates/lang-csharp`, правила `config/rules-csharp.yaml`, чек-лист — домен `csharp_web`
(миграция `0007_csharp.sql`; ASVS/WSTG подмешиваются через общий `web`).

Первый запуск на реальном коде — проверь парсер так же, как Kotlin:

```bash
cargo run -p codesink-lang-csharp --bin debug_parse -- test-samples/csharp/UserController.cs
```

Ожидаемо: функции `Search/BuildQuery/RunQuery/SearchSafe/Ping/RunCommand/Read/Load` с атрибутами
(`@FromQuery`, `@HttpGet("search")`, …) и вызовы с receiver (`cmd.ExecuteReader` -> receiver `cmd`,
`Process.Start` -> receiver `Process`, `new SqlCommand` -> вызов `SqlCommand`).
Если версия `tree-sitter-c-sharp` конфликтует по `links` — `cargo tree -i tree-sitter`, подбери 0.21.x.
Порядок после добавления: `sqlx migrate run` -> `cargo sqlx prepare --workspace` -> `docker compose up -d --build`.
Ограничения: лямбды Minimal API (`app.MapGet(...)`) не отдельные функции, их параметры не source;
свойства (get/set) и инициализаторы полей не обходятся.
