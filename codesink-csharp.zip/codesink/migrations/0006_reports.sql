-- Отчёты — самостоятельный артефакт. project_id обнуляется при удалении
-- проекта (ON DELETE SET NULL), а не каскадно удаляется вместе с ним —
-- сам HTML-файл на диске уже содержит полный снапшот данных и не зависит
-- от того, жив ли исходный проект.
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    project_name TEXT NOT NULL,
    file_name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reports_created ON reports(created_at DESC);
