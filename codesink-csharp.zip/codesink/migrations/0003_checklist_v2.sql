-- Убираем секцию "Signed vs Unsigned" совсем — пользователю обычно
-- присылают что-то одно, а не пару сборок для сравнения.
DELETE FROM checklist_templates WHERE section = 'signed_diff';

-- Trust Boundary Map была слишком конкретной под один кейс (App1/App2/Lib) —
-- переписываем на общие вопросы, конкретику ревьюер добавляет сам под кейс.
DELETE FROM checklist_templates WHERE section = 'trust_boundary';
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('generic', 'trust_boundary', 'Какие компоненты/сервисы взаимодействуют друг с другом и в каком направлении', 0),
('generic', 'trust_boundary', 'Где реально проходит граница доверия (может не совпадать с границей файлов/модулей/процессов)', 1),
('generic', 'trust_boundary', 'Какие данные пересекают каждую границу — на уровне "что", а не "как"', 2),
('generic', 'trust_boundary', 'Есть ли общий контекст авторизации (сессия/токен/permission) между компонентами, или каждый аутентифицируется независимо', 3),
('generic', 'trust_boundary', 'Кто конечный потребитель данных за пределами системы (третьи стороны, партнёры, публичный интернет)', 4);

-- SAST/MobSF триаж — старые вопросы сводились к "нашёл сам vs нашёл сканер".
-- Новые нацелены на реальную пользу триажа: контекст, воспроизведение,
-- накопление знания про сам сканер.
DELETE FROM checklist_templates WHERE section = 'sast_triage';
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('generic', 'sast_triage', 'Известен сканер и его типичные ложные срабатывания на этом стеке (или это первая встреча с ним)', 0),
('generic', 'sast_triage', 'Для критичных находок — воспроизведена эксплуатация вручную, а не просто доверие вердикту', 1),
('generic', 'sast_triage', 'Совпадает ли граница доверия, которую предполагает правило сканера, с реальной trust boundary этого проекта', 2),
('generic', 'sast_triage', 'Есть ли компенсирующий контроль в другом месте (инфраструктура/WAF/другой сервис), который сканер не видит', 3),
('generic', 'sast_triage', 'Нашёл ли сканер то, чего не было в ручной модели — если да, обновлена ли сама модель, а не только отчёт', 4),
('generic', 'sast_triage', 'Задокументирован паттерн false positive для этого сканера+кодовой базы — ускорит следующий триаж', 5);

-- Языко-специфичные паттерны — теперь ключ language это language_domain
-- (например rust_web, rust_blockchain), а не просто язык. Старые записи
-- (bare kotlin/go/rust/js/python) убираем — уже засеянные в существующих
-- проектах checklist_items не трогаем, это их собственная история.
DELETE FROM checklist_templates WHERE section = 'lang_patterns';

INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
-- Kotlin / Android
('kotlin_android', 'lang_patterns', 'Implicit intents / exported components без permission', 0),
('kotlin_android', 'lang_patterns', 'WebView (JS interface exposure, mixed content, insecure URL loading)', 1),
('kotlin_android', 'lang_patterns', 'Хранение секретов (SharedPreferences без шифрования, hardcoded keys, keystore misuse)', 2),
('kotlin_android', 'lang_patterns', 'Reflection / deserialization без валидации (readSerializable, Class.forName)', 3),
('kotlin_android', 'lang_patterns', 'Coroutine scope leaks с sensitive data в памяти дольше, чем нужно', 4),
('kotlin_android', 'lang_patterns', 'IPC: bindService/Messenger/AIDL — проверка вызывающего процесса (calling UID/permission)', 5),
('kotlin_android', 'lang_patterns', 'android:allowBackup=true без исключения чувствительных данных', 6),
('kotlin_android', 'lang_patterns', 'Biometric/Keystore — ключ реально привязан к аутентификации, а не просто UI-диалог', 7),
('kotlin_android', 'lang_patterns', 'Root/emulator detection используется не как единственная защита', 8),
('kotlin_android', 'lang_patterns', 'ProGuard/R8 не используется как единственный security control (обфускация — не защита)', 9),

-- Rust / CLI
('rust_cli', 'lang_patterns', 'Аргументы командной строки как источник — path traversal / command injection при передаче дальше', 0),
('rust_cli', 'lang_patterns', 'Переменные окружения как источник доверия (PATH hijacking и подобные векторы)', 1),
('rust_cli', 'lang_patterns', 'unwrap()/expect() на недоверенном вводе — паника как DoS', 2),
('rust_cli', 'lang_patterns', 'Временные файлы — предсказуемые имена, TOCTOU, права доступа', 3),
('rust_cli', 'lang_patterns', 'Чувствительные данные в stdout/stderr, которые могут попасть в CI-логи', 4),
('rust_cli', 'lang_patterns', 'Целочисленное переполнение в release-сборке (wrapping по умолчанию, не паникует)', 5),
('rust_cli', 'lang_patterns', 'Дефолтная конфигурация safe-by-default, а не dev/debug-режим', 6),

-- Rust / Web
('rust_web', 'lang_patterns', 'Web-экстракторы (query/json/form) как source — прослежен путь до sink', 0),
('rust_web', 'lang_patterns', 'unwrap()/expect() на данных запроса — паника → 500 с утечкой стектрейса', 1),
('rust_web', 'lang_patterns', 'unsafe-блоки — обоснованность и чётко очерченные границы', 2),
('rust_web', 'lang_patterns', 'SSRF через исходящие запросы (reqwest) с пользовательским URL', 3),
('rust_web', 'lang_patterns', 'Middleware авторизации применяется единообразно на всех защищённых маршрутах', 4),
('rust_web', 'lang_patterns', 'Целочисленное переполнение в release-сборке — особенно в финансовой/квотной логике', 5),
('rust_web', 'lang_patterns', 'Rate limiting на публичных эндпоинтах', 6),
('rust_web', 'lang_patterns', 'Секреты в конфиге/коде вместо секрет-менеджера', 7),

-- Rust / Smart Contract & Blockchain
('rust_blockchain', 'lang_patterns', 'Проверка подписанта (signer) на привилегированных инструкциях/функциях', 0),
('rust_blockchain', 'lang_patterns', 'Проверка владельца аккаунта / PDA-валидация (Solana/Anchor) или эквивалент для другой платформы', 1),
('rust_blockchain', 'lang_patterns', 'checked_add/checked_sub вместо +/- в финансовых расчётах (integer overflow/underflow)', 2),
('rust_blockchain', 'lang_patterns', 'Reentrancy-аналоги — внешние вызовы ДО обновления состояния (нарушение CEI-паттерна)', 3),
('rust_blockchain', 'lang_patterns', 'Replay-атаки — есть ли проверка nonce/sequence', 4),
('rust_blockchain', 'lang_patterns', 'Управление upgrade authority / admin-ключами контракта', 5),
('rust_blockchain', 'lang_patterns', 'Доверие единственному источнику цены (oracle manipulation)', 6),
('rust_blockchain', 'lang_patterns', 'Unchecked приведения типов (as u64/as i32) без проверки границ', 7),
('rust_blockchain', 'lang_patterns', 'Паника в on-chain коде как вектор отказа всей транзакции', 8),
('rust_blockchain', 'lang_patterns', 'Хранение/генерация приватных ключей и seed-фраз', 9),

-- Go / CLI
('go_cli', 'lang_patterns', 'Аргументы/переменные окружения как источник — path traversal / command injection', 0),
('go_cli', 'lang_patterns', 'Ошибки игнорируются через _ вместо обработки', 1),
('go_cli', 'lang_patterns', 'Временные файлы — os.CreateTemp vs предсказуемые имена', 2),
('go_cli', 'lang_patterns', 'Паника на недоверенном вводе без recover в критичных путях', 3),

-- Go / Web
('go_web', 'lang_patterns', 'SQL-запросы через конкатенацию строк вместо placeholder', 0),
('go_web', 'lang_patterns', 'Goroutine leaks / отсутствие context cancellation', 1),
('go_web', 'lang_patterns', 'Race conditions — общее состояние без мьютекса/атомиков (проверено go test -race?)', 2),
('go_web', 'lang_patterns', 'SSRF через исходящие http-запросы с пользовательским URL', 3),
('go_web', 'lang_patterns', 'JWT — проверка алгоритма, секрет не в коде', 4),
('go_web', 'lang_patterns', 'Middleware авторизации применяется единообразно на всех защищённых маршрутах', 5),
('go_web', 'lang_patterns', 'Error handling не утекает внутреннюю структуру/стектрейс наружу', 6),

-- JavaScript/TypeScript / Web
('javascript_web', 'lang_patterns', 'Prototype pollution через неглубокое merge/Object.assign с пользовательским вводом', 0),
('javascript_web', 'lang_patterns', 'npm-зависимости — supply chain (postinstall-скрипты, устаревшие пакеты, typosquatting)', 1),
('javascript_web', 'lang_patterns', 'CORS: Access-Control-Allow-Origin: * вместе с credentials', 2),
('javascript_web', 'lang_patterns', 'JWT — алгоритм none, секрет в коде, отсутствие проверки exp', 3),
('javascript_web', 'lang_patterns', 'XSS через dangerouslySetInnerHTML/innerHTML с пользовательским вводом', 4),
('javascript_web', 'lang_patterns', 'Cookie flags — httpOnly/secure/sameSite на сессионных куках', 5),
('javascript_web', 'lang_patterns', 'SSRF через fetch/axios с пользовательским URL', 6),
('javascript_web', 'lang_patterns', 'Открытый redirect по пользовательскому параметру', 7),
('javascript_web', 'lang_patterns', 'Rate limiting на публичных эндпоинтах', 8),

-- Python / Web
('python_web', 'lang_patterns', 'SQL-инъекция через f-строки вместо параметризованных запросов', 0),
('python_web', 'lang_patterns', 'SSRF через requests с пользовательским URL', 1),
('python_web', 'lang_patterns', 'Server-side template injection (Jinja2/Django render с пользовательским вводом)', 2),
('python_web', 'lang_patterns', 'Mass assignment — ORM принимает все поля запроса без whitelist', 3),
('python_web', 'lang_patterns', 'CORS-конфигурация', 4),
('python_web', 'lang_patterns', 'Секреты в .env/коде вместо секрет-менеджера', 5),
('python_web', 'lang_patterns', 'DEBUG=True в проде (стектрейсы наружу)', 6),

-- Python / AI
('python_ai', 'lang_patterns', 'pickle/torch.load/joblib.load на недоверенных данных', 0),
('python_ai', 'lang_patterns', 'yaml.load вместо yaml.safe_load', 1),
('python_ai', 'lang_patterns', 'Prompt injection — пользовательский ввод напрямую в system/instruction часть промпта', 2),
('python_ai', 'lang_patterns', 'Небезопасный eval/exec конфигов модели или пайплайна', 3),
('python_ai', 'lang_patterns', 'SSRF через загрузку моделей/датасетов по пользовательскому URL', 4),
('python_ai', 'lang_patterns', 'Утечка PII через логи промптов/ответов модели', 5),
('python_ai', 'lang_patterns', 'Rate limiting на inference-эндпоинтах (cost abuse / DoS через дорогие запросы)', 6),
('python_ai', 'lang_patterns', 'Dependency confusion / typosquatting в PyPI ML-пакетах', 7),
('python_ai', 'lang_patterns', 'API-ключи LLM-провайдеров в коде/конфиге вместо секрет-менеджера', 8);
