-- Новая секция 0: общие архитектурные вопросы — чтобы сначала понять
-- приложение целиком, до погружения в детали. Показывается всегда, для
-- любого проекта.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('generic', 'architecture_overview', 'Какую задачу решает приложение и кто его пользователи (внешние/внутренние)', 0),
('generic', 'architecture_overview', 'Какие внешние системы/API/провайдеры используются и насколько им доверяют', 1),
('generic', 'architecture_overview', 'Где хранятся данные (БД, файлы, кэш) и какова их чувствительность', 2),
('generic', 'architecture_overview', 'Как выглядит модель развёртывания (облако/on-prem/мобильное устройство/бинарник у клиента)', 3),
('generic', 'architecture_overview', 'Кто уже проверял этот код раньше и что нашли (история находок, если есть)', 4),
('generic', 'architecture_overview', 'Что случится в худшем случае при компрометации этого компонента (blast radius)', 5);

-- Общий secure coding чек-лист по темам — по мотивам классического чеклиста
-- OWASP-style ревью. Каждая тема — своя секция (generic, применяется ко
-- всем проектам независимо от языка/домена).
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
-- Configuration
('generic', 'sc_configuration', 'Чувствительные данные не захардкожены в конфигурационных файлах', 0),
('generic', 'sc_configuration', 'Directory listing отключён', 1),
('generic', 'sc_configuration', 'Серверы/фреймворки/компоненты обновлены и пропатчены', 2),
('generic', 'sc_configuration', 'Дефолтные/демо-аккаунты и эндпоинты удалены перед продом', 3),

-- Input Validation
('generic', 'sc_input_validation', 'Входные данные от внешних источников валидируются (параметры, URL, заголовки/куки)', 0),
('generic', 'sc_input_validation', 'Пользовательский ввод проверяется по типу, длине, формату и диапазону', 1),
('generic', 'sc_input_validation', 'Используется allow-list подход (проверка на ожидаемые значения), а не только block-list', 2),
('generic', 'sc_input_validation', 'SQL-запросы НЕ собираются динамически из пользовательского ввода', 3),
('generic', 'sc_input_validation', 'Валидация выполняется на стороне сервера, а не только на клиенте', 4),
('generic', 'sc_input_validation', 'Есть чёткое разделение данных и команд, данных и клиентских скриптов', 5),
('generic', 'sc_input_validation', 'Контекстное экранирование при передаче данных в SQL/LDAP/OS/сторонние команды', 6),
('generic', 'sc_input_validation', 'Загружаемые файлы валидируются по content-type, размеру, типу и имени', 7),
('generic', 'sc_input_validation', 'Любая ошибка валидации приводит к отклонению ввода целиком', 8),
('generic', 'sc_input_validation', 'Проверяются null-байты (%00), переводы строк (%0d/%0a), path traversal (../ )', 9),
('generic', 'sc_input_validation', 'Недоверенные данные приводятся к канонической форме перед проверкой', 10),
('generic', 'sc_input_validation', 'Данные, приходящие через redirect, тоже валидируются', 11),

-- Output Encoding
('generic', 'sc_output_encoding', 'HTML/JavaScript/CSS в выводе экранируются перед вставкой во внешний контент', 0),
('generic', 'sc_output_encoding', 'Кодирование вывода выполняется на доверенной стороне (сервере)', 1),
('generic', 'sc_output_encoding', 'Контекстная санитизация вывода для LDAP/SQL/XML-запросов', 2),

-- Authentication
('generic', 'sc_authentication', 'Аутентификация требуется на всех страницах/ресурсах, кроме явно публичных', 0),
('generic', 'sc_authentication', 'Все проверки аутентификации выполняются на backend, не только на клиенте', 1),
('generic', 'sc_authentication', 'Сообщения об ошибке входа не раскрывают, что именно неверно (логин или пароль)', 2),
('generic', 'sc_authentication', 'Требования к паролю (длина/сложность) адекватны модели угроз', 3),
('generic', 'sc_authentication', 'Неудачные попытки входа обрабатываются с lockout и rate limit', 4),
('generic', 'sc_authentication', '"Забыли пароль" не раскрывает существование аккаунта и защищён от спама', 5),
('generic', 'sc_authentication', 'Пароли не отправляются в открытом виде по email', 6),
('generic', 'sc_authentication', 'Пароли хранятся через Argon2id/bcrypt/scrypt — НЕ MD5/SHA-1/несоленый SHA-256', 7),
('generic', 'sc_authentication', 'Токены сессии генерируются через CSPRNG, а не Math.random()/timestamp', 8),
('generic', 'sc_authentication', 'Учётные данные передаются только через POST, не в URL', 9),
('generic', 'sc_authentication', 'Временные пароли/ссылки имеют короткий срок жизни', 10),

-- Authorization
('generic', 'sc_authorization', 'Проверки аутентификации И авторизации выполняются на каждом приватном запросе', 0),
('generic', 'sc_authorization', 'Проверки авторизации гранулярны — на уровне страницы/директории/действия', 1),
('generic', 'sc_authorization', 'Доступ к данным по умолчанию закрыт (deny by default)', 2),
('generic', 'sc_authorization', 'Повторная аутентификация требуется для действий с побочными эффектами (смена пароля/email)', 3),
('generic', 'sc_authorization', 'Авторизацию нельзя обойти манипуляцией параметром/cookie', 4),
('generic', 'sc_authorization', 'Сервисным аккаунтам и внешним интеграциям выдан минимально необходимый привилегий', 5),

-- Session Management
('generic', 'sc_session', 'Параметры сессии не передаются в URL', 0),
('generic', 'sc_session', 'Сессионные cookie истекают за разумное время', 1),
('generic', 'sc_session', 'Session ID достаточно длинный (128+ бит) и непредсказуемый', 2),
('generic', 'sc_session', 'Приватные данные в cookie сведены к минимуму', 3),
('generic', 'sc_session', 'Enforced inactivity timeout и лимиты сессии', 4),
('generic', 'sc_session', 'Logout реально инвалидирует сессию на сервере, а не только удаляет cookie на клиенте', 5),
('generic', 'sc_session', 'Cookie сессии не persistent, используют httpOnly/secure/sameSite', 6),

-- Cryptography
('generic', 'sc_cryptography', 'Используются современные алгоритмы шифрования (AES-256-GCM/ChaCha20-Poly1305), не ECB и не CBC без MAC', 0),
('generic', 'sc_cryptography', 'Минимальные размеры ключей соответствуют текущим рекомендациям', 1),
('generic', 'sc_cryptography', 'Чувствительные данные защищены в памяти, при хранении и в транзите', 2),
('generic', 'sc_cryptography', 'Криптографические ключи и секреты защищены от несанкционированного доступа', 3),
('generic', 'sc_cryptography', 'JWT: подпись валидируется с явным указанием алгоритма (alg: none невозможен)', 4),

-- Error & Exception Handling
('generic', 'sc_error_handling', 'Обработчики ошибок не показывают debug-информацию или стектрейс пользователю', 0),
('generic', 'sc_error_handling', 'Сообщения об ошибках максимально общие, есть кастомные страницы ошибок', 1),
('generic', 'sc_error_handling', 'Приложение failsafe — падает в безопасное состояние при исключении', 2),
('generic', 'sc_error_handling', 'Ресурсы освобождаются и транзакции откатываются при ошибке', 3),

-- Attack Surface
('generic', 'sc_attack_surface', 'Поисковые/фильтрующие операции защищены от SQL/NoSQL-инъекции через критерии поиска', 0),
('generic', 'sc_attack_surface', 'На клиенте не хранится то, что должно храниться на сервере', 1),

-- Secure Transmission
('generic', 'sc_secure_transmission', 'Чувствительные данные передаются только по TLS', 0),
('generic', 'sc_secure_transmission', 'TLS-сертификаты валидны, не истекли, с правильным доменом и intermediate-цепочкой', 1),

-- Log Management
('generic', 'sc_logging', 'Чувствительные действия пользователя логируются (кто/что/когда/где/как)', 0),
('generic', 'sc_logging', 'Чувствительная информация (пароли, токены, PII) НЕ попадает в логи', 1),
('generic', 'sc_logging', 'Пользовательский ввод санитизируется перед записью в лог (log injection)', 2),
('generic', 'sc_logging', 'Необычная активность (множественные неудачные входы и т.п.) логируется', 3),
('generic', 'sc_logging', 'Логов достаточно для восстановления событий в целях аудита', 4),
('generic', 'sc_logging', 'Целостность логов защищена (хэши/неизменяемое хранилище) — от себя: полезно, если логи вообще участвуют в разборе инцидентов', 5);

-- OWASP MASVS/MASTG — только для Kotlin/Android. Куратируемая выжимка по
-- 8 категориям MASVS v2.1.0, а не все 24 официальных контроля дословно.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('kotlin_android', 'masvs', '[STORAGE] Чувствительные данные не хранятся в открытом виде (SharedPreferences/файлы/логи/backup)', 0),
('kotlin_android', 'masvs', '[STORAGE] Данные не утекают через clipboard, keyboard cache или скриншоты (FLAG_SECURE)', 1),
('kotlin_android', 'masvs', '[CRYPTO] Используются криптографически стойкие алгоритмы и режимы (не ECB, не кастомные)', 2),
('kotlin_android', 'masvs', '[CRYPTO] Ключи генерируются и хранятся через Android Keystore, не хардкодятся', 3),
('kotlin_android', 'masvs', '[AUTH] Аутентификация не может быть обойдена бинарным патчингом/hook (учтена ли эта модель угроз)', 4),
('kotlin_android', 'masvs', '[AUTH] Биометрия криптографически привязана к операции, а не просто UI-диалог с булевым результатом', 5),
('kotlin_android', 'masvs', '[NETWORK] TLS настроен корректно (нет TrustManager, принимающего все сертификаты)', 6),
('kotlin_android', 'masvs', '[NETWORK] Certificate pinning применяется для критичных соединений, если того требует модель угроз', 7),
('kotlin_android', 'masvs', '[PLATFORM] IPC-механизмы (Intent/ContentProvider/Binder) проверяют вызывающего', 8),
('kotlin_android', 'masvs', '[PLATFORM] WebView не выполняет недоверенный JS, addJavascriptInterface ограничен', 9),
('kotlin_android', 'masvs', '[CODE] Приложение не собрано в debug-режиме для релиза (debuggable=false)', 10),
('kotlin_android', 'masvs', '[CODE] Обработка ошибок не приводит к падению с утечкой стектрейса пользователю', 11),
('kotlin_android', 'masvs', '[RESILIENCE] Есть защита от простого статического/динамического реверс-инжиниринга, если того требует модель угроз (не единственная защита!)', 12),
('kotlin_android', 'masvs', '[PRIVACY] Собираемые данные соответствуют заявленной privacy policy и разрешениям', 13);

INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('kotlin_android', 'mstg', '[STORAGE] Проверено содержимое SharedPreferences/Room DB/файлов через adb на реальном/эмуляторе устройстве', 0),
('kotlin_android', 'mstg', '[STORAGE] Проверен backup (adb backup) — не утекают ли туда чувствительные данные', 1),
('kotlin_android', 'mstg', '[CRYPTO] Проверено через jadx/frida — не захардкожен ли ключ/секрет в коде или ресурсах', 2),
('kotlin_android', 'mstg', '[NETWORK] Проверено через mitmproxy/Burp — принимает ли приложение self-signed сертификат прокси', 3),
('kotlin_android', 'mstg', '[PLATFORM] Проверены exported-компоненты через `adb shell dumpsys package` — вызваны напрямую без разрешений', 4),
('kotlin_android', 'mstg', '[RESILIENCE] Проверено поведение на рутованном устройстве/эмуляторе — приложение это обнаруживает и как реагирует', 5),
('kotlin_android', 'mstg', '[AUTH] Проверено через Frida — можно ли обойти биометрическую проверку хуком на callback', 6);

-- OWASP ASVS/WSTG — общие для ЛЮБОГО web-домена (go_web/rust_web/javascript_web/
-- python_web), поэтому ключ 'web', а не конкретный язык — не дублируем один
-- и тот же чек-лист 4 раза. Куратируемая выжимка из 17 глав ASVS 5.0.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('web', 'asvs', '[V1 Encoding] Защита от OS command injection — параметризованные вызовы, не конкатенация', 0),
('web', 'asvs', '[V2 Validation] Бизнес-логика не доверяет клиенту (цены, количества, статусы пересчитываются на сервере)', 1),
('web', 'asvs', '[V3 Frontend] CSP настроен и реально ограничивает inline-скрипты', 2),
('web', 'asvs', '[V4 API] API/веб-сервисы валидируют Content-Type и не доверяют клиентским заголовкам', 3),
('web', 'asvs', '[V5 File Handling] Загрузка файлов ограничена по типу/размеру, файлы не исполняются как код', 4),
('web', 'asvs', '[V6 Authentication] MFA доступна для чувствительных операций, есть защита от credential stuffing', 5),
('web', 'asvs', '[V7 Session] Сессия инвалидируется на сервере при logout, есть idle/absolute timeout', 6),
('web', 'asvs', '[V8 Authorization] Object-level authorization проверяется на каждый ресурс (IDOR)', 7),
('web', 'asvs', '[V9/V10 Tokens/OAuth] JWT/токены проверяют алгоритм подписи явно, redirect_uri в OAuth валидируется строго', 8),
('web', 'asvs', '[V11 Cryptography] Пароли хешируются Argon2id/bcrypt/scrypt, не MD5/SHA1', 9),
('web', 'asvs', '[V12 Secure Communication] HSTS включён, downgrade на HTTP невозможен', 10),
('web', 'asvs', '[V13 Configuration] Debug-режим и подробные ошибки отключены в проде', 11),
('web', 'asvs', '[V14 Data Protection] Чувствительные данные не логируются и не кэшируются на клиенте', 12),
('web', 'asvs', '[V15 Secure Coding] Зависимости без известных критичных CVE (SCA пройден)', 13),
('web', 'asvs', '[V16 Logging] Security-события логируются без утечки чувствительных данных в лог', 14);

INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('web', 'wstg', 'Проверена конфигурация (WSTG-CONF) — лишние HTTP-методы, версии ПО в заголовках', 0),
('web', 'wstg', 'Проверена аутентификация (WSTG-ATHN) — brute force, username enumeration, weak lockout', 1),
('web', 'wstg', 'Проверена авторизация (WSTG-ATHZ) — IDOR, privilege escalation по горизонтали/вертикали', 2),
('web', 'wstg', 'Проверено управление сессией (WSTG-SESS) — session fixation, CSRF token реально проверяется', 3),
('web', 'wstg', 'Проверена валидация ввода (WSTG-INPV) — SQLi/XSS/XXE ручными payload''ами, не только сканером', 4),
('web', 'wstg', 'Проверена обработка ошибок (WSTG-ERRH) — стектрейсы/внутренние пути в ответах', 5),
('web', 'wstg', 'Проверена бизнес-логика (WSTG-BUSL) — обход шагов процесса, race condition на критичных операциях', 6),
('web', 'wstg', 'Проверена клиентская часть (WSTG-CLNT) — DOM XSS, postMessage без проверки origin', 7);

-- OWASP Top 10 for LLM Applications (2025) — для Python/AI.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('python_ai', 'llm_top10', '[LLM01 Prompt Injection] Пользовательский ввод отделён от system/instruction-части промпта', 0),
('python_ai', 'llm_top10', '[LLM02 Sensitive Info Disclosure] Модель не может утечь PII/секреты из training-данных или контекста', 1),
('python_ai', 'llm_top10', '[LLM03 Supply Chain] Источники моделей/датасетов/пакетов проверены (не случайный HuggingFace repo)', 2),
('python_ai', 'llm_top10', '[LLM04 Data/Model Poisoning] Есть контроль целостности обучающих данных и fine-tuning датасетов', 3),
('python_ai', 'llm_top10', '[LLM05 Improper Output Handling] Вывод модели не подставляется напрямую в HTML/SQL/shell без санитизации', 4),
('python_ai', 'llm_top10', '[LLM06 Excessive Agency] Агент/tool-calling ограничен минимально нужными правами, не может выполнить произвольное действие', 5),
('python_ai', 'llm_top10', '[LLM07 System Prompt Leakage] System-промпт не содержит секретов и защищён от извлечения через запрос', 6),
('python_ai', 'llm_top10', '[LLM08 Vector/Embedding Weaknesses] Векторная БД проверяет tenant-изоляцию, нет cross-tenant утечки при поиске', 7),
('python_ai', 'llm_top10', '[LLM09 Misinformation] Есть disclaimer/human-in-the-loop для решений с юридическими/финансовыми последствиями', 8),
('python_ai', 'llm_top10', '[LLM10 Unbounded Consumption] Rate limiting и лимиты токенов/времени на inference-запрос (защита от Denial of Wallet)', 9);

-- OWASP Smart Contract Top 10 — для Rust/Blockchain.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('rust_blockchain', 'sc_top10', '[Access Control] Привилегированные функции проверяют вызывающего (onlyOwner-эквивалент)', 0),
('rust_blockchain', 'sc_top10', '[Price Oracle Manipulation] Цена не берётся из единственного мгновенного источника (TWAP/несколько оракулов)', 1),
('rust_blockchain', 'sc_top10', '[Logic Errors] Бизнес-логика соответствует спецификации — особенно округления и порядок операций', 2),
('rust_blockchain', 'sc_top10', '[Lack of Input Validation] Внешние параметры (суммы, адреса, индексы) валидируются перед использованием', 3),
('rust_blockchain', 'sc_top10', '[Reentrancy] Состояние обновляется ДО внешнего вызова (Checks-Effects-Interactions)', 4),
('rust_blockchain', 'sc_top10', '[Unchecked External Calls] Результат внешнего вызова/CPI проверяется, ошибка не игнорируется молча', 5),
('rust_blockchain', 'sc_top10', '[Flash Loan Attacks] Инварианты протокола держатся даже при мгновенном займе крупной суммы в рамках одной транзакции', 6),
('rust_blockchain', 'sc_top10', '[Integer Overflow/Underflow] Везде checked-арифметика в финансовых расчётах, не голые +/-/as-касты', 7),
('rust_blockchain', 'sc_top10', '[Insecure Randomness] Источник случайности не предсказуем майнером/валидатором (не blockhash напрямую)', 8),
('rust_blockchain', 'sc_top10', '[Denial of Service] Нет способа заблокировать контракт для всех через одну дешёвую транзакцию', 9);
