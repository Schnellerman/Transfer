-- C# / .NET: языко-специфичные паттерны. ASVS/WSTG подмешиваются через общий
-- домен 'web' (его добавляет detect_project_domains для csharp_web), а
-- архитектурные/sc_* секции — generic, поэтому здесь только lang_patterns.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
('csharp_web', 'lang_patterns', 'SQL-инъекция: SqlCommand/FromSqlRaw/ExecuteSqlRaw с конкатенацией или $"..." вместо параметров (AddWithValue, FromSqlInterpolated)', 0),
('csharp_web', 'lang_patterns', 'Небезопасная десериализация: BinaryFormatter, NetDataContractSerializer, SoapFormatter, LosFormatter, JavaScriptSerializer с SimpleTypeResolver', 1),
('csharp_web', 'lang_patterns', 'Newtonsoft.Json: TypeNameHandling != None на недоверенном вводе (gadget chains)', 2),
('csharp_web', 'lang_patterns', 'XXE: XmlDocument/XmlTextReader/XPathDocument без DtdProcessing.Prohibit и XmlResolver = null (особенно .NET Framework < 4.5.2)', 3),
('csharp_web', 'lang_patterns', 'Overposting / mass assignment: модель из тела запроса привязывается целиком без [Bind]/DTO/whitelist (IsAdmin, Role)', 4),
('csharp_web', 'lang_patterns', 'Нет [Authorize] на контроллере/экшене или [AllowAnonymous] на чувствительных методах; fallback policy не задана', 5),
('csharp_web', 'lang_patterns', 'IDOR: выборка по id из запроса без проверки владельца (User.FindFirst / ownership filter)', 6),
('csharp_web', 'lang_patterns', 'CSRF: отсутствует [ValidateAntiForgeryToken]/AutoValidateAntiforgeryToken для cookie-аутентификации', 7),
('csharp_web', 'lang_patterns', 'Path traversal: Path.Combine с пользовательским вводом (абсолютный второй аргумент отбрасывает базовый путь), File.*, PhysicalFile, ZipArchive.ExtractToDirectory (Zip Slip)', 8),
('csharp_web', 'lang_patterns', 'SSRF: HttpClient/WebClient/WebRequest с пользовательским URL; нет allow-list хостов и блокировки внутренних адресов/IMDS', 9),
('csharp_web', 'lang_patterns', 'Open redirect: Redirect(returnUrl) без Url.IsLocalUrl / LocalRedirect', 10),
('csharp_web', 'lang_patterns', 'XSS: Html.Raw, @Html.Raw, MarkupString в Blazor, отключённое кодирование в Razor', 11),
('csharp_web', 'lang_patterns', 'Command injection: Process.Start / ProcessStartInfo с пользовательскими аргументами, UseShellExecute=true', 12),
('csharp_web', 'lang_patterns', 'Секреты: connection strings, JWT-ключи, API-ключи в appsettings.json/web.config/коде вместо User Secrets / Key Vault', 13),
('csharp_web', 'lang_patterns', 'JWT: ValidateIssuer/ValidateAudience/ValidateLifetime=false, слабый или хардкод-ключ, RequireSignedTokens=false, алгоритм none', 14),
('csharp_web', 'lang_patterns', 'CORS: AllowAnyOrigin вместе с AllowCredentials или отражение Origin; UseCors порядок в pipeline', 15),
('csharp_web', 'lang_patterns', 'Cookie flags: HttpOnly/Secure/SameSite для auth- и session-кук; ExpireTimeSpan и SlidingExpiration', 16),
('csharp_web', 'lang_patterns', 'Криптография: MD5/SHA1/DES/TripleDES/ECB, Random вместо RandomNumberGenerator, Rfc2898 с малым числом итераций, собственные схемы', 17),
('csharp_web', 'lang_patterns', 'Ошибки: app.UseDeveloperExceptionPage в проде, customErrors Off, детальные ошибки в ответе, Swagger/Hangfire dashboard без авторизации', 18),
('csharp_web', 'lang_patterns', 'Reflection/динамическая загрузка: Type.GetType, Activator.CreateInstance, Assembly.Load по пользовательскому имени', 19),
('csharp_web', 'lang_patterns', 'ReDoS: Regex на пользовательском вводе без matchTimeout', 20),
('csharp_web', 'lang_patterns', 'Логирование: пользовательский ввод в логах без нейтрализации CRLF; секреты и PII в логах', 21),
('csharp_web', 'lang_patterns', 'Классический ASP.NET (Webforms/MVC 5): ViewState без MAC/шифрования, machineKey в репозитории, requestValidationMode, trace.axd/elmah.axd', 22),
('csharp_web', 'lang_patterns', 'Зависимости NuGet: устаревшие пакеты с известными CVE (dotnet list package --vulnerable), приватные фиды и dependency confusion', 23),
('csharp_web', 'lang_patterns', 'Rate limiting / lockout на login и reset-password (AddRateLimiter, Identity lockout)', 24);
