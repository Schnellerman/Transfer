-- Глобальные шаблоны пунктов чек-листа. language='generic' — секции 1/4/5
-- (одинаковые для всех языков), language='<lang>' — секция 6 (язык-специфичные
-- паттерны). Растут через "поднять в общий шаблон" из любого проекта.
CREATE TABLE checklist_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    language TEXT NOT NULL,
    section TEXT NOT NULL,
    label TEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (language, section, label)
);

-- Чекбокс-пункты конкретного проекта (секции: trust_boundary, signed_diff,
-- sast_triage, lang_patterns). Сидируются из checklist_templates при первом
-- открытии, дальше живут независимо — можно добавлять/удалять/редактировать
-- без влияния на шаблон и другие проекты.
CREATE TABLE checklist_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    section TEXT NOT NULL,
    language TEXT, -- NULL для generic-секций, конкретный язык для lang_patterns
    label TEXT NOT NULL,
    checked BOOLEAN NOT NULL DEFAULT false,
    notes TEXT NOT NULL DEFAULT '',
    is_custom BOOLEAN NOT NULL DEFAULT false, -- true = добавлен вручную, не из шаблона
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Табличные секции конкретного проекта (data_classification, authz_mapping) —
-- произвольные колонки хранятся как JSON, схему задаёт фронт.
CREATE TABLE checklist_rows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    section TEXT NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_checklist_items_project ON checklist_items(project_id);
CREATE INDEX idx_checklist_rows_project ON checklist_rows(project_id);

-- Стартовые шаблоны — секции 1/4/5 (общие) и 6 (по языку), по мотивам
-- scr-worksheet-lenovo.md.
INSERT INTO checklist_templates (language, section, label, sort_order) VALUES
-- Секция 1: Trust Boundary Map
('generic', 'trust_boundary', 'Кто вызывает кого: App1 → Lib? App2 → Lib? Lib → внешний backend?', 0),
('generic', 'trust_boundary', 'Где физическая/процессная граница доверия (не совпадает с границей файлов/модулей!)', 1),
('generic', 'trust_boundary', 'Какие данные пересекают каждую границу (на уровне "что", не "как")', 2),
('generic', 'trust_boundary', 'Есть ли общий пользовательский контекст (сессия, токен, permission) между компонентами', 3),
-- Секция 4: Signed vs Unsigned
('generic', 'signed_diff', 'android:debuggable — true в unsigned, false в signed?', 0),
('generic', 'signed_diff', 'Логирование — сравнить уровень verbosity', 1),
('generic', 'signed_diff', 'Certificate/SSL pinning — активен в обеих сборках?', 2),
('generic', 'signed_diff', 'Тестовые/staging эндпоинты — остались ли в unsigned, убраны ли в signed', 3),
('generic', 'signed_diff', 'ProGuard/R8 обфускация — включена в signed?', 4),
-- Секция 5: SAST/MobSF триаж
('generic', 'sast_triage', 'Это true positive в контексте trust boundary map?', 0),
('generic', 'sast_triage', 'Дублирует ли то, что уже найдено руками?', 1),
('generic', 'sast_triage', 'Есть ли находки сканера, которых не было в ручной модели — повод перепроверить модель', 2),
-- Секция 6: Kotlin (Android)
('kotlin', 'lang_patterns', 'Implicit intents / exported components без permission', 0),
('kotlin', 'lang_patterns', 'WebView (JS interface exposure, mixed content)', 1),
('kotlin', 'lang_patterns', 'Хранение секретов (SharedPreferences без шифрования, hardcoded keys)', 2),
('kotlin', 'lang_patterns', 'Reflection / deserialization без валидации', 3),
('kotlin', 'lang_patterns', 'Coroutine scope leaks с sensitive data в памяти дольше, чем нужно', 4),
-- Секция 6: Go
('go', 'lang_patterns', 'Ошибки игнорируются через _ вместо обработки', 0),
('go', 'lang_patterns', 'Goroutine leaks / отсутствие context cancellation', 1),
('go', 'lang_patterns', 'SQL-запросы через конкатенацию строк вместо placeholder', 2),
('go', 'lang_patterns', 'Хранение секретов в коде/конфиге без секрет-менеджера', 3),
-- Секция 6: Rust
('rust', 'lang_patterns', 'unsafe-блоки — обоснованность и границы', 0),
('rust', 'lang_patterns', 'unwrap()/expect() на данных из недоверенного источника (паника = DoS)', 1),
('rust', 'lang_patterns', 'Целочисленное переполнение в release-сборке (wrapping по умолчанию)', 2),
-- Секция 6: JavaScript/TypeScript
('javascript', 'lang_patterns', 'Prototype pollution через неглубокое merge/Object.assign с пользовательским вводом', 0),
('javascript', 'lang_patterns', 'npm-зависимости — supply chain (postinstall-скрипты, устаревшие пакеты)', 1),
('javascript', 'lang_patterns', 'CORS-конфигурация — Access-Control-Allow-Origin: *  с credentials', 2),
('javascript', 'lang_patterns', 'JWT — проверка алгоритма (alg: none), секрет в коде', 3),
-- Секция 6: Python
('python', 'lang_patterns', 'pickle/torch.load/joblib.load на недоверенных данных', 0),
('python', 'lang_patterns', 'YAML.load вместо safe_load', 1),
('python', 'lang_patterns', 'Секреты в .env / коде вместо секрет-менеджера', 2),
('python', 'lang_patterns', 'AI: prompt injection в LLM-пайплайнах, если есть внешний ввод в промпт', 3);
