CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    language TEXT NOT NULL DEFAULT 'kotlin',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE analysis_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'pending', -- pending | running | done | failed
    node_count INT,
    edge_count INT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at TIMESTAMPTZ,
    error TEXT
);

CREATE TABLE functions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES analysis_runs(id) ON DELETE CASCADE,
    function_key TEXT NOT NULL, -- FunctionId из core (file::owner.name)
    name TEXT NOT NULL,
    owner TEXT,
    receiver_type TEXT,
    file TEXT NOT NULL,
    start_line INT NOT NULL,
    end_line INT NOT NULL,
    annotations JSONB NOT NULL DEFAULT '[]',
    UNIQUE (run_id, function_key)
);

CREATE TABLE calls (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES analysis_runs(id) ON DELETE CASCADE,
    caller_key TEXT NOT NULL,
    callee_key TEXT, -- NULL если не удалось резолвить
    callee_name TEXT NOT NULL,
    file TEXT NOT NULL,
    line INT NOT NULL
);

CREATE TABLE findings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES analysis_runs(id) ON DELETE CASCADE,
    source_key TEXT NOT NULL,
    sink_key TEXT NOT NULL,
    path JSONB NOT NULL, -- массив FunctionId по порядку
    sanitized BOOLEAN NOT NULL DEFAULT false,
    confidence TEXT NOT NULL, -- low | medium | high
    status TEXT NOT NULL DEFAULT 'needs_review', -- needs_review | confirmed | false_positive
    reviewer_comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE manual_annotations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    file TEXT NOT NULL,
    line INT NOT NULL,
    kind TEXT NOT NULL, -- source | sink | sanitizer
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_functions_run ON functions(run_id);
CREATE INDEX idx_calls_run ON calls(run_id);
CREATE INDEX idx_findings_run ON findings(run_id);
CREATE INDEX idx_findings_status ON findings(status);
