using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using Microsoft.AspNetCore.Mvc;

namespace Demo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        // 1) SQLi: source -> BuildQuery -> RunQuery -> ExecuteReader (НЕ sanitized)
        [HttpGet("search")]
        public IActionResult Search([FromQuery] string name)
        {
            var sql = BuildQuery(name);
            return Ok(RunQuery(sql));
        }

        private string BuildQuery(string name) => "SELECT * FROM Users WHERE Name = '" + name + "'";

        private string RunQuery(string sql)
        {
            using var conn = new SqlConnection("Server=.;Database=demo");
            var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            return reader.ToString();
        }

        // 2) Безопасный вариант: AddWithValue на пути
        [HttpGet("search-safe")]
        public IActionResult SearchSafe([FromQuery] string name)
        {
            var cmd = new SqlCommand("SELECT * FROM Users WHERE Name = @n");
            cmd.Parameters.AddWithValue("@n", name);
            return Ok(cmd.ExecuteReader());
        }

        // 3) Command injection
        [HttpPost("ping")]
        public IActionResult Ping([FromBody] string host)
        {
            return Ok(RunCommand(host));
        }

        private string RunCommand(string host)
        {
            var p = Process.Start("ping", "-c 1 " + host);
            return p.StandardOutput.ReadToEnd();
        }

        // 4) Property-source: Request.Query["file"] -> File.ReadAllText (path traversal)
        [HttpGet("read")]
        public IActionResult Read()
        {
            var file = Request.Query["file"];
            return Ok(Load(file));
        }

        private string Load(string file) => File.ReadAllText(file);
    }
}
