package main

import (
	"database/sql"
	"net/http"
	"os/exec"
)

// Ожидаемый результат анализа:
// 1) SearchHandler -> runQuery -> db.Query      = НЕ sanitized (SQLi, конкатенация)
// 2) SearchSafeHandler -> runSafeQuery -> stmt.Exec = sanitized (через db.Prepare)
// 3) PingHandler -> runPing -> cmd.Run          = НЕ sanitized (command injection)

func SearchHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	name := r.FormValue("name")
	query := "SELECT * FROM users WHERE name = '" + name + "'"
	runQuery(db, query)
}

func runQuery(db *sql.DB, query string) {
	db.Query(query)
}

func SearchSafeHandler(w http.ResponseWriter, r *http.Request, db *sql.DB) {
	name := r.FormValue("name")
	runSafeQuery(db, name)
}

func runSafeQuery(db *sql.DB, name string) {
	stmt, _ := db.Prepare("SELECT * FROM users WHERE name = ?")
	stmt.Exec(name)
}

func PingHandler(w http.ResponseWriter, r *http.Request) {
	host := r.FormValue("host")
	runPing(host)
}

func runPing(host string) {
	cmd := exec.Command("ping", "-c", "1", host)
	cmd.Run()
}
