from flask import Flask, request
import subprocess
import sqlite3

app = Flask(__name__)

# Ожидаемый результат анализа:
# 1) search -> run_query -> execute       = НЕ sanitized (SQLi, конкатенация)
# 2) search_safe -> run_safe_query -> execute = sanitized (плейсхолдер ?), НО
#    имя sink и sanitizer здесь совпадают ("execute") — это известная
#    неточность эвристики, задокументированная в rules-python.yaml. Находка
#    появится в обоих случаях, просто с разной confidence.
# 3) ping -> run_ping -> call             = НЕ sanitized (command injection)


@app.route('/search')
def search():
    name = request.args.get('name')
    query = "SELECT * FROM users WHERE name = '" + name + "'"
    run_query(query)
    return "ok"


def run_query(query):
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute(query)
    return cursor.fetchall()


@app.route('/search-safe')
def search_safe():
    name = request.args.get('name')
    run_safe_query(name)
    return "ok"


def run_safe_query(name):
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE name = ?", (name,))
    return cursor.fetchall()


@app.route('/ping')
def ping():
    host = request.args.get('host')
    run_ping(host)
    return "ok"


def run_ping(host):
    subprocess.call("ping -c 1 " + host, shell=True)
