package com.example.demo

import org.springframework.web.bind.annotation.*
import java.sql.Connection
import java.sql.DriverManager

/**
 * Тестовый контроллер specifически под config/rules-kotlin.yaml:
 * - source: @RequestParam (аннотация на параметре)
 * - sink: Statement.execute (SQL injection через конкатенацию)
 * - sink: ProcessBuilder (command injection)
 * - sanitizer: prepareStatement (параметризованный запрос)
 *
 * Ожидаемый результат анализа:
 * 1) searchUser -> buildQuery -> runQuery  = НЕ sanitized (уязвимость, конкатенация строк)
 * 2) searchUserSafe -> buildSafeQuery -> runSafeQuery = sanitized (используется prepareStatement)
 * 3) pingHost -> runCommand -> Runtime.exec = НЕ sanitized (command injection)
 */
@RestController
class DemoController {

    // --- Уязвимый путь: SQL injection ---

    @GetMapping("/search")
    fun searchUser(@RequestParam name: String): String {
        val query = buildQuery(name)
        return runQuery(query)
    }

    fun buildQuery(userInput: String): String {
        // Явная конкатенация — классическая SQLi, source доходит до sink без очистки
        return "SELECT * FROM users WHERE name = '" + userInput + "'"
    }

    fun runQuery(sql: String): String {
        val conn: Connection = DriverManager.getConnection("jdbc:postgresql://localhost/test")
        val stmt = conn.createStatement()
        val rs = stmt.execute(sql)
        return rs.toString()
    }

    // --- Безопасный путь: тот же сценарий, но через prepareStatement ---

    @GetMapping("/search-safe")
    fun searchUserSafe(@RequestParam name: String): String {
        val query = buildSafeQuery(name)
        return runSafeQuery(query, name)
    }

    fun buildSafeQuery(userInput: String): String {
        return "SELECT * FROM users WHERE name = ?"
    }

    fun runSafeQuery(sql: String, name: String): String {
        val conn: Connection = DriverManager.getConnection("jdbc:postgresql://localhost/test")
        val stmt = conn.prepareStatement(sql)
        stmt.setString(1, name)
        val rs = stmt.execute()
        return rs.toString()
    }

    // --- Уязвимый путь: command injection ---

    @PostMapping("/ping")
    fun pingHost(@RequestBody host: String): String {
        return runCommand(host)
    }

    fun runCommand(host: String): String {
        val pb = ProcessBuilder("ping", "-c", "1", host)
        val process = pb.start()
        return process.inputStream.bufferedReader().readText()
    }
}

// --- Extension-функция для проверки резолвинга receiver-типов ---

fun String.toSafeFileName(): String {
    return this.replace(Regex("[^a-zA-Z0-9._-]"), "_")
}

class FileService {
    @GetMapping("/read")
    fun readUserFile(@RequestParam path: String): String {
        val safeName = path.toSafeFileName()
        return loadFile(safeName)
    }

    fun loadFile(fileName: String): String {
        return java.io.File(fileName).readText()
    }
}
