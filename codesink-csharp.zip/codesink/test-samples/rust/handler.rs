use actix_web::web;
use std::process::Command;

// Ожидаемый результат анализа:
// 1) search_handler -> run_query -> execute        = НЕ sanitized (SQLi, format!)
// 2) search_safe_handler -> run_safe_query -> execute = sanitized (через .bind)
// 3) ping_handler -> run_ping -> spawn             = НЕ sanitized (command injection)

pub struct SearchParams {
    pub name: String,
}

pub struct PingParams {
    pub host: String,
}

async fn search_handler(query: web::Query<SearchParams>, pool: web::Data<sqlx::PgPool>) {
    let params = query.into_inner();
    let sql = format!("SELECT * FROM users WHERE name = '{}'", params.name);
    run_query(&pool, &sql).await;
}

async fn run_query(pool: &sqlx::PgPool, sql: &str) {
    sqlx::query(sql).execute(pool).await.unwrap();
}

async fn search_safe_handler(query: web::Query<SearchParams>, pool: web::Data<sqlx::PgPool>) {
    let params = query.into_inner();
    run_safe_query(&pool, &params.name).await;
}

async fn run_safe_query(pool: &sqlx::PgPool, name: &str) {
    sqlx::query("SELECT * FROM users WHERE name = $1")
        .bind(name)
        .execute(pool)
        .await
        .unwrap();
}

async fn ping_handler(query: web::Query<PingParams>) {
    let params = query.into_inner();
    run_ping(&params.host);
}

fn run_ping(host: &str) {
    Command::new("ping").arg("-c").arg("1").arg(host).spawn().unwrap();
}
