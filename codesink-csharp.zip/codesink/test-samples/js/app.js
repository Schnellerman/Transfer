const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');

const app = express();

// Ожидаемый результат анализа:
// 1) <anon> (/search handler) -> exec        = НЕ sanitized (command injection)
// 2) <anon> (/search-safe handler) -> exec   = sanitized (через escape)
// 3) <anon> (/read handler) -> readFile      = НЕ sanitized (path traversal)
//
// Все три обработчика — инлайн-стрелочные функции прямо в аргументах
// app.get(...), без имени. Это самый хрупкий случай для lang-js парсера
// (см. предупреждение в его lib.rs) — если тут окажется 0 функций/вызовов,
// проблема почти наверняка в обработке анонимных функций.

app.get('/search', (req, res) => {
  const name = req.param('name');
  const cmd = 'grep ' + name + ' /var/log/app.log';
  exec(cmd, (err, stdout) => {
    res.send(stdout);
  });
});

app.get('/search-safe', (req, res) => {
  const name = req.param('name');
  const safe = escape(name);
  exec('grep ' + safe + ' /var/log/app.log', (err, stdout) => {
    res.send(stdout);
  });
});

app.get('/read', (req, res) => {
  const file = req.get('X-File');
  fs.readFile(file, (err, data) => {
    res.send(data);
  });
});

module.exports = app;
