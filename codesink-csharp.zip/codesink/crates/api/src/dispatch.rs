//! Обходит директорию проекта и парсит каждый файл нужным языковым крейтом
//! по расширению. Чтобы добавить ещё один язык:
//! 1. Создай crates/lang-<name> (пример свежего: lang-csharp) по образцу существующих (parse_file + dump_sexp).
//! 2. Добавь его как зависимость в Cargo.toml API.
//! 3. Допиши одну строчку в match ниже.
//! 4. Добавь config/rules-<name>.yaml и подключи его в main.rs (EXTRA_RULE_FILES).
//! Ядро (codesink-core) трогать не нужно — оно ничего не знает про языки.

use anyhow::Result;
use codesink_core::model::ParsedProject;
use std::path::Path;
use walkdir::WalkDir;

/// Определяет не просто язык, а language_domain (например "rust_web",
/// "rust_blockchain", "python_ai") — по текстовым сигнатурам в исходниках.
/// Это НЕ анализ зависимостей (Cargo.toml/package.json не парсим) — просто
/// grep по ключевым импортам/использованиям, этого достаточно, чтобы понять,
/// какой чек-лист подмешивать, но не для security-решений. Один проект может
/// дать несколько доменов сразу (например rust_web + rust_cli), если сигналы
/// обоих найдены — это нормально, оба чек-листа тогда показываются.
pub fn detect_project_domains(root: &Path) -> Vec<String> {
    use std::collections::HashSet;
    let mut domains: HashSet<String> = HashSet::new();
    let mut kotlin_present = false;
    let mut js_present = false;
    let mut csharp_present = false;

    for entry in WalkDir::new(root).into_iter().filter_map(|e| e.ok()) {
        let path = entry.path();
        let Some(ext) = path.extension().and_then(|e| e.to_str()) else {
            continue;
        };

        match ext {
            "kt" | "kts" => kotlin_present = true,
            "js" | "jsx" | "ts" | "tsx" => js_present = true,
            "go" => {
                let content = std::fs::read_to_string(path).unwrap_or_default();
                if contains_any(&content, &["net/http", "gin-gonic/gin", "labstack/echo", "gorilla/mux"]) {
                    domains.insert("go_web".to_string());
                }
                if contains_any(&content, &["spf13/cobra", "urfave/cli", "flag.Parse"]) {
                    domains.insert("go_cli".to_string());
                }
            }
            "rs" => {
                let content = std::fs::read_to_string(path).unwrap_or_default();
                if contains_any(&content, &["actix_web", "axum::", "rocket::", "warp::"]) {
                    domains.insert("rust_web".to_string());
                }
                if contains_any(&content, &["clap::", "structopt::"]) {
                    domains.insert("rust_cli".to_string());
                }
                if contains_any(
                    &content,
                    &["anchor_lang", "solana_program", "ink::", "substrate", "cosmwasm_std", "ethers::", "web3::"],
                ) {
                    domains.insert("rust_blockchain".to_string());
                }
            }
            "cs" => {
                csharp_present = true;
                let content = std::fs::read_to_string(path).unwrap_or_default();
                if contains_any(
                    &content,
                    &["Microsoft.AspNetCore", "System.Web.Mvc", "System.Web.Http", "ControllerBase", "WebApplication.Create", "[ApiController]"],
                ) {
                    domains.insert("csharp_web".to_string());
                }
            }
            "py" => {
                let content = std::fs::read_to_string(path).unwrap_or_default();
                if contains_any(&content, &["flask", "Flask(", "django", "fastapi", "FastAPI("]) {
                    domains.insert("python_web".to_string());
                }
                if contains_any(&content, &["torch", "tensorflow", "sklearn", "transformers", "openai"]) {
                    domains.insert("python_ai".to_string());
                }
            }
            _ => {}
        }
    }

    if kotlin_present {
        domains.insert("kotlin_android".to_string());
    }
    // .cs без явных веб-сигнатур (библиотека, сервис, консоль) всё равно
    // получает C#-паттерны — иначе чек-лист был бы пустым.
    if csharp_present {
        domains.insert("csharp_web".to_string());
    }
    if js_present {
        domains.insert("javascript_web".to_string());
        domains.insert("web".to_string());
    }
    // ASVS/WSTG общие для любого веб-стека — не дублируем чек-лист под
    // каждый язык отдельно, помечаем единым маркером "web".
    if domains.iter().any(|d| d.ends_with("_web")) {
        domains.insert("web".to_string());
    }

    domains.into_iter().collect()
}

fn contains_any(content: &str, needles: &[&str]) -> bool {
    needles.iter().any(|n| content.contains(n))
}

pub fn parse_project_directory(root: &Path) -> Result<ParsedProject> {
    let mut combined = ParsedProject::default();

    for entry in WalkDir::new(root).into_iter().filter_map(|e| e.ok()) {
        let full_path = entry.path();
        let Some(ext) = full_path.extension().and_then(|e| e.to_str()) else {
            continue;
        };
        // Для отображения и хранения используем путь ОТНОСИТЕЛЬНО корня
        // проекта — иначе file получается вида "data/uploads/<uuid>/..."
        // и графы/список файлов становятся нечитаемыми.
        let rel_path = full_path.strip_prefix(root).unwrap_or(full_path);

        let parsed = match ext {
            "kt" | "kts" => {
                let source = std::fs::read_to_string(full_path)?;
                Some(codesink_lang_kotlin::parse_file(rel_path, &source)?)
            }
            "go" => {
                let source = std::fs::read_to_string(full_path)?;
                Some(codesink_lang_go::parse_file(rel_path, &source)?)
            }
            "rs" => {
                let source = std::fs::read_to_string(full_path)?;
                Some(codesink_lang_rust::parse_file(rel_path, &source)?)
            }
            "py" => {
                let source = std::fs::read_to_string(full_path)?;
                Some(codesink_lang_python::parse_file(rel_path, &source)?)
            }
            "cs" => {
                // .cs часто бывают с BOM или не в UTF-8 — не валим весь анализ из-за одного файла.
                // Каталоги bin/ и obj/ — сгенерированный мусор сборки.
                if rel_path.components().any(|c| matches!(c.as_os_str().to_str(), Some("bin") | Some("obj"))) {
                    None
                } else {
                    let bytes = std::fs::read(full_path)?;
                    let source = String::from_utf8_lossy(&bytes);
                    let source = source.trim_start_matches('\u{feff}');
                    Some(codesink_lang_csharp::parse_file(rel_path, source)?)
                }
            }
            "js" | "jsx" | "ts" | "tsx" => {
                let source = std::fs::read_to_string(full_path)?;
                Some(codesink_lang_js::parse_file(rel_path, &source)?)
            }
            _ => None,
        };

        if let Some(p) = parsed {
            combined.functions.extend(p.functions);
            combined.calls.extend(p.calls);
        }
    }

    Ok(combined)
}
