mod db;
mod dispatch;
mod handlers;
mod report;

use axum::routing::{delete, get, post};
use axum::Router;
use codesink_core::rules::RuleSet;
use handlers::AppState;
use std::path::PathBuf;
use tower_http::cors::CorsLayer;
use tower_http::trace::TraceLayer;

/// Каждый язык — свой YAML в config/. При добавлении нового языка просто
/// добавь файл сюда (см. также dispatch.rs).
const RULE_FILES: &[&str] = &[
    "config/rules-kotlin.yaml",
    "config/rules-go.yaml",
    "config/rules-js.yaml",
    "config/rules-rust.yaml",
    "config/rules-python.yaml",
    "config/rules-csharp.yaml",
];

fn load_merged_rules() -> anyhow::Result<RuleSet> {
    let mut merged = RuleSet {
        language: "multi".to_string(),
        sources: Vec::new(),
        sinks: Vec::new(),
        sanitizers: Vec::new(),
    };
    for path in RULE_FILES {
        let yaml = std::fs::read_to_string(path)
            .unwrap_or_else(|_| panic!("{path} not found — run from repo root"));
        let set = RuleSet::load_from_str(&yaml)?;
        merged.sources.extend(set.sources);
        merged.sinks.extend(set.sinks);
        merged.sanitizers.extend(set.sanitizers);
    }
    Ok(merged)
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt::init();

    let database_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "postgres://codesink:codesink@localhost:5432/codesink".to_string());
    let pool = db::create_pool(&database_url).await?;

    // Миграции встроены в бинарник на этапе компиляции (sqlx::migrate!) и
    // применяются автоматически при каждом старте — руками sqlx migrate run
    // гонять больше не нужно ни локально, ни в контейнере.
    sqlx::migrate!("../../migrations").run(&pool).await?;

    let rules = load_merged_rules()?;

    let upload_dir = PathBuf::from("./data/uploads");
    std::fs::create_dir_all(&upload_dir)?;

    let state = AppState {
        pool,
        rules,
        upload_dir,
    };

    let app = Router::new()
        .route(
            "/api/projects",
            post(handlers::create_project).get(handlers::list_projects),
        )
        .route("/api/projects/{id}/upload", post(handlers::upload_files))
        .route("/api/projects/{id}/analyze", post(handlers::analyze_project))
        .route(
            "/api/projects/{id}",
            delete(handlers::delete_project).patch(handlers::rename_project),
        )
        .route("/api/projects/{id}/files", get(handlers::list_project_files))
        .route("/api/projects/{id}/file-content", get(handlers::get_file_content))
        .route("/api/projects/{id}/latest-run", get(handlers::get_latest_run))
        .route("/api/projects/{id}/report", post(handlers::generate_report))
        .route(
            "/api/reports",
            get(handlers::list_reports),
        )
        .route(
            "/api/reports/{id}",
            get(handlers::get_report).delete(handlers::delete_report_handler),
        )
        .route(
            "/api/projects/{id}/checklist",
            get(handlers::get_checklist).post(handlers::add_checklist_item),
        )
        .route(
            "/api/checklist/items/{id}",
            axum::routing::patch(handlers::update_checklist_item).delete(handlers::delete_checklist_item),
        )
        .route("/api/checklist/items/{id}/promote", post(handlers::promote_checklist_item))
        .route(
            "/api/projects/{id}/checklist/rows",
            post(handlers::add_checklist_row),
        )
        .route(
            "/api/checklist/rows/{id}",
            axum::routing::patch(handlers::update_checklist_row).delete(handlers::delete_checklist_row),
        )
        .route(
            "/api/projects/{id}/annotations",
            post(handlers::create_annotation).get(handlers::list_annotations),
        )
        .route("/api/runs/{id}/findings", get(handlers::list_findings))
        .route("/api/runs/{id}/graph", get(handlers::get_graph))

        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let listener = tokio::net::TcpListener::bind("0.0.0.0:8090").await?;
    tracing::info!("codesink-api listening on :8090");
    axum::serve(listener, app).await?;

    Ok(())
}
