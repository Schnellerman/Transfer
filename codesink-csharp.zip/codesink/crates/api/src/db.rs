use anyhow::Result;
use codesink_core::model::{Finding, FunctionDef};
use serde_json::json;
use sqlx::PgPool;
use uuid::Uuid;

pub async fn create_pool(database_url: &str) -> Result<PgPool> {
    let pool = PgPool::connect(database_url).await?;
    Ok(pool)
}

pub async fn create_project(pool: &PgPool, name: &str, language: &str) -> Result<Uuid> {
    let rec = sqlx::query!(
        "INSERT INTO projects (name, language) VALUES ($1, $2) RETURNING id",
        name,
        language
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn create_run(pool: &PgPool, project_id: Uuid) -> Result<Uuid> {
    let rec = sqlx::query!(
        "INSERT INTO analysis_runs (project_id, status) VALUES ($1, 'running') RETURNING id",
        project_id
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn finish_run(
    pool: &PgPool,
    run_id: Uuid,
    node_count: i32,
    edge_count: i32,
) -> Result<()> {
    sqlx::query!(
        "UPDATE analysis_runs SET status = 'done', node_count = $2, edge_count = $3, finished_at = now() WHERE id = $1",
        run_id,
        node_count,
        edge_count
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn fail_run(pool: &PgPool, run_id: Uuid, error: &str) -> Result<()> {
    sqlx::query!(
        "UPDATE analysis_runs SET status = 'failed', error = $2, finished_at = now() WHERE id = $1",
        run_id,
        error
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn save_functions(pool: &PgPool, run_id: Uuid, functions: &[FunctionDef]) -> Result<()> {
    for f in functions {
        sqlx::query!(
            r#"INSERT INTO functions
               (run_id, function_key, name, owner, receiver_type, file, start_line, end_line, annotations)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
               ON CONFLICT (run_id, function_key) DO NOTHING"#,
            run_id,
            f.id,
            f.name,
            f.owner,
            f.receiver_type,
            f.file,
            f.start_line as i32,
            f.end_line as i32,
            json!(f.annotations),
        )
        .execute(pool)
        .await?;
    }
    Ok(())
}

pub async fn save_findings(pool: &PgPool, run_id: Uuid, findings: &[Finding]) -> Result<()> {
    for f in findings {
        let confidence = format!("{:?}", f.confidence).to_lowercase();
        let sink_key = format!("{}@{}:{}", f.sink_name, f.sink_file, f.sink_line);
        sqlx::query!(
            r#"INSERT INTO findings (run_id, source_key, sink_key, path, sanitized, confidence)
               VALUES ($1, $2, $3, $4, $5, $6)"#,
            run_id,
            f.source,
            sink_key,
            json!(f.path),
            f.sanitized,
            confidence,
        )
        .execute(pool)
        .await?;
    }
    Ok(())
}

pub struct ProjectRow {
    pub id: Uuid,
    pub name: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

pub async fn list_projects(pool: &PgPool) -> Result<Vec<ProjectRow>> {
    let rows = sqlx::query_as!(
        ProjectRow,
        "SELECT id, name, created_at FROM projects ORDER BY created_at DESC"
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub struct LatestRunRow {
    pub id: Uuid,
    pub status: String,
    pub node_count: Option<i32>,
    pub edge_count: Option<i32>,
}

pub async fn get_latest_run(pool: &PgPool, project_id: Uuid) -> Result<Option<LatestRunRow>> {
    let row = sqlx::query_as!(
        LatestRunRow,
        r#"SELECT id, status, node_count, edge_count FROM analysis_runs
           WHERE project_id = $1 ORDER BY started_at DESC LIMIT 1"#,
        project_id
    )
    .fetch_optional(pool)
    .await?;
    Ok(row)
}

pub async fn count_findings(pool: &PgPool, run_id: Uuid) -> Result<i64> {
    let rec = sqlx::query!(
        r#"SELECT COUNT(*) as "count!" FROM findings WHERE run_id = $1"#,
        run_id
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.count)
}

pub async fn save_calls(pool: &PgPool, run_id: Uuid, calls: &[codesink_core::model::CallSite]) -> Result<()> {
    for c in calls {
        sqlx::query!(
            r#"INSERT INTO calls (run_id, caller_key, callee_key, callee_name, file, line)
               VALUES ($1, $2, $3, $4, $5, $6)"#,
            run_id,
            c.caller,
            c.callee_resolved,
            c.callee_name,
            c.file,
            c.line as i32,
        )
        .execute(pool)
        .await?;
    }
    Ok(())
}

pub async fn rename_project(pool: &PgPool, project_id: Uuid, name: &str) -> Result<()> {
    sqlx::query!("UPDATE projects SET name = $2 WHERE id = $1", project_id, name)
        .execute(pool)
        .await?;
    Ok(())
}

pub struct ChecklistItemRow {
    pub id: Uuid,
    pub section: String,
    pub language: Option<String>,
    pub label: String,
    pub checked: bool,
    pub notes: String,
    pub is_custom: bool,
    #[allow(dead_code)] // нужен только для ORDER BY в SQL, не читается после fetch
    pub sort_order: i32,
}

pub async fn list_checklist_items(pool: &PgPool, project_id: Uuid) -> Result<Vec<ChecklistItemRow>> {
    let rows = sqlx::query_as!(
        ChecklistItemRow,
        r#"SELECT id, section, language, label, checked, notes, is_custom, sort_order
           FROM checklist_items WHERE project_id = $1 ORDER BY section, sort_order"#,
        project_id
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub struct ChecklistTemplateRow {
    pub language: String,
    pub section: String,
    pub label: String,
    pub sort_order: i32,
}

pub async fn list_templates_for(pool: &PgPool, languages: &[String]) -> Result<Vec<ChecklistTemplateRow>> {
    // generic-секции всегда, плюс lang_patterns для каждого языка проекта.
    let rows = sqlx::query_as!(
        ChecklistTemplateRow,
        r#"SELECT language, section, label, sort_order FROM checklist_templates
           WHERE language = 'generic' OR language = ANY($1)
           ORDER BY section, sort_order"#,
        languages
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn seed_checklist_items(
    pool: &PgPool,
    project_id: Uuid,
    templates: &[ChecklistTemplateRow],
) -> Result<()> {
    for t in templates {
        let lang = if t.language == "generic" { None } else { Some(t.language.clone()) };
        sqlx::query!(
            r#"INSERT INTO checklist_items (project_id, section, language, label, sort_order, is_custom)
               VALUES ($1, $2, $3, $4, $5, false)"#,
            project_id,
            t.section,
            lang,
            t.label,
            t.sort_order,
        )
        .execute(pool)
        .await?;
    }
    Ok(())
}

pub async fn add_checklist_item(
    pool: &PgPool,
    project_id: Uuid,
    section: &str,
    language: Option<&str>,
    label: &str,
) -> Result<Uuid> {
    let rec = sqlx::query!(
        r#"INSERT INTO checklist_items (project_id, section, language, label, is_custom, sort_order)
           VALUES ($1, $2, $3, $4, true, 9999) RETURNING id"#,
        project_id,
        section,
        language,
        label,
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn update_checklist_item(pool: &PgPool, item_id: Uuid, checked: bool, notes: &str) -> Result<()> {
    sqlx::query!(
        "UPDATE checklist_items SET checked = $2, notes = $3 WHERE id = $1",
        item_id,
        checked,
        notes,
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn delete_checklist_item(pool: &PgPool, item_id: Uuid) -> Result<()> {
    sqlx::query!("DELETE FROM checklist_items WHERE id = $1", item_id)
        .execute(pool)
        .await?;
    Ok(())
}

pub async fn promote_checklist_item(pool: &PgPool, item_id: Uuid) -> Result<()> {
    let item = sqlx::query!(
        "SELECT section, language, label FROM checklist_items WHERE id = $1",
        item_id
    )
    .fetch_one(pool)
    .await?;
    let lang = item.language.unwrap_or_else(|| "generic".to_string());
    let max_order = sqlx::query!(
        "SELECT COALESCE(MAX(sort_order), -1) as max_order FROM checklist_templates WHERE language = $1 AND section = $2",
        lang,
        item.section
    )
    .fetch_one(pool)
    .await?
    .max_order
    .unwrap_or(-1);
    sqlx::query!(
        r#"INSERT INTO checklist_templates (language, section, label, sort_order)
           VALUES ($1, $2, $3, $4) ON CONFLICT (language, section, label) DO NOTHING"#,
        lang,
        item.section,
        item.label,
        max_order + 1,
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub struct ChecklistRowRow {
    pub id: Uuid,
    pub section: String,
    pub data: serde_json::Value,
    #[allow(dead_code)]
    pub sort_order: i32,
}

pub async fn list_checklist_rows(pool: &PgPool, project_id: Uuid) -> Result<Vec<ChecklistRowRow>> {
    let rows = sqlx::query_as!(
        ChecklistRowRow,
        "SELECT id, section, data, sort_order FROM checklist_rows WHERE project_id = $1 ORDER BY section, sort_order",
        project_id
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn add_checklist_row(pool: &PgPool, project_id: Uuid, section: &str, data: &serde_json::Value) -> Result<Uuid> {
    let rec = sqlx::query!(
        r#"INSERT INTO checklist_rows (project_id, section, data, sort_order)
           VALUES ($1, $2, $3, 9999) RETURNING id"#,
        project_id,
        section,
        data,
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn update_checklist_row(pool: &PgPool, row_id: Uuid, data: &serde_json::Value) -> Result<()> {
    sqlx::query!("UPDATE checklist_rows SET data = $2 WHERE id = $1", row_id, data)
        .execute(pool)
        .await?;
    Ok(())
}

pub async fn delete_checklist_row(pool: &PgPool, row_id: Uuid) -> Result<()> {
    sqlx::query!("DELETE FROM checklist_rows WHERE id = $1", row_id)
        .execute(pool)
        .await?;
    Ok(())
}

pub struct ReportRow {
    pub id: Uuid,
    pub project_name: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

pub async fn create_report(
    pool: &PgPool,
    project_id: Uuid,
    project_name: &str,
    file_name: &str,
) -> Result<Uuid> {
    let rec = sqlx::query!(
        r#"INSERT INTO reports (project_id, project_name, file_name) VALUES ($1, $2, $3) RETURNING id"#,
        project_id,
        project_name,
        file_name,
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn list_reports(pool: &PgPool) -> Result<Vec<ReportRow>> {
    let rows = sqlx::query_as!(
        ReportRow,
        "SELECT id, project_name, created_at FROM reports ORDER BY created_at DESC"
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

pub async fn get_report_file_name(pool: &PgPool, report_id: Uuid) -> Result<Option<String>> {
    let rec = sqlx::query!("SELECT file_name FROM reports WHERE id = $1", report_id)
        .fetch_optional(pool)
        .await?;
    Ok(rec.map(|r| r.file_name))
}

pub async fn delete_report(pool: &PgPool, report_id: Uuid) -> Result<()> {
    sqlx::query!("DELETE FROM reports WHERE id = $1", report_id)
        .execute(pool)
        .await?;
    Ok(())
}

pub struct ManualAnnotationRow {
    pub file: String,
    pub line: i32,
    pub kind: String,
}

pub async fn create_manual_annotation(
    pool: &PgPool,
    project_id: Uuid,
    file: &str,
    line: i32,
    kind: &str,
    note: Option<&str>,
) -> Result<Uuid> {
    let rec = sqlx::query!(
        "INSERT INTO manual_annotations (project_id, file, line, kind, note) VALUES ($1, $2, $3, $4, $5) RETURNING id",
        project_id,
        file,
        line,
        kind,
        note
    )
    .fetch_one(pool)
    .await?;
    Ok(rec.id)
}

pub async fn list_manual_annotations(
    pool: &PgPool,
    project_id: Uuid,
) -> Result<Vec<ManualAnnotationRow>> {
    let rows = sqlx::query_as!(
        ManualAnnotationRow,
        "SELECT file, line, kind FROM manual_annotations WHERE project_id = $1",
        project_id
    )
    .fetch_all(pool)
    .await?;
    Ok(rows)
}
