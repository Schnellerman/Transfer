//! Генерирует самодостаточный HTML-отчёт по проекту: находки (авто +
//! ручные), чек-лист целиком, граф вызовов (интерактивный, embedded
//! cytoscape.js через CDN) и кусочки кода вокруг source/sink/аннотаций —
//! НЕ весь файл, только окно в несколько строк вокруг нужной.
//!
//! Отчёт полностью самодостаточен: все данные встроены в сам HTML на
//! момент генерации, поэтому он переживает удаление исходного проекта —
//! не зависит от живых записей в БД или файлов на диске после того, как
//! был создан.

use anyhow::Result;
use serde::Serialize;
use sqlx::PgPool;
use std::path::Path;
use uuid::Uuid;

const SNIPPET_CONTEXT_LINES: usize = 3;

pub struct ReportInput {
    pub project_name: String,
    pub upload_dir: std::path::PathBuf,
    pub project_id: Uuid,
}

#[derive(Serialize)]
struct GraphNodeJson {
    id: String,
    label: String,
    file: String,
    line: i32,
}

#[derive(Serialize)]
struct GraphEdgeJson {
    source: String,
    target: String,
}

pub async fn generate_html(pool: &PgPool, input: &ReportInput) -> Result<String> {
    let project_dir = input.upload_dir.join(input.project_id.to_string());

    // Последний завершённый прогон анализа.
    let run = sqlx::query!(
        "SELECT id, node_count, edge_count FROM analysis_runs WHERE project_id = $1 AND status = 'done' ORDER BY started_at DESC LIMIT 1",
        input.project_id
    )
    .fetch_optional(pool)
    .await?;

    let (findings_html, graph_nodes, graph_edges, findings_count) = if let Some(ref run) = run {
        let functions = sqlx::query!(
            "SELECT function_key, name, file, start_line FROM functions WHERE run_id = $1",
            run.id
        )
        .fetch_all(pool)
        .await?;

        let func_by_key: std::collections::HashMap<String, (String, i32)> = functions
            .iter()
            .map(|f| (f.function_key.clone(), (f.file.clone(), f.start_line)))
            .collect();

        let nodes: Vec<GraphNodeJson> = functions
            .iter()
            .map(|f| GraphNodeJson {
                id: f.function_key.clone(),
                label: f.name.clone(),
                file: f.file.clone(),
                line: f.start_line,
            })
            .collect();

        let call_rows = sqlx::query!(
            "SELECT caller_key, callee_key FROM calls WHERE run_id = $1 AND callee_key IS NOT NULL",
            run.id
        )
        .fetch_all(pool)
        .await?;
        let edges: Vec<GraphEdgeJson> = call_rows
            .into_iter()
            .filter_map(|r| r.callee_key.map(|target| GraphEdgeJson { source: r.caller_key, target }))
            .collect();

        let findings = sqlx::query!(
            r#"SELECT source_key, sink_key, path, sanitized, confidence, status
               FROM findings WHERE run_id = $1 ORDER BY confidence DESC"#,
            run.id
        )
        .fetch_all(pool)
        .await?;

        let mut findings_html = String::new();
        for f in &findings {
            let (source_file, source_line) = func_by_key
                .get(&f.source_key)
                .cloned()
                .unwrap_or_else(|| ("?".to_string(), 0));
            let (sink_name, sink_file, sink_line) = parse_sink_key(&f.sink_key);

            let source_snippet = read_snippet(&project_dir, &source_file, source_line as usize);
            let sink_snippet = read_snippet(&project_dir, &sink_file, sink_line);

            let badge_color = match f.confidence.as_str() {
                "high" => "#fb7185",
                "medium" => "#fbbf24",
                _ => "#8b83a8",
            };
            let sanitized_note = if f.sanitized {
                "<div class='sanitized-note'>possibly sanitized — проверь глазами, что санитайзер реально применяется к этому пути</div>"
            } else {
                ""
            };

            findings_html.push_str(&format!(
                r#"<div class="finding">
                    <div class="finding-header">
                        <span class="badge" style="background:{badge_color}22;color:{badge_color}">{confidence}</span>
                        <span class="finding-status">{status}</span>
                    </div>
                    <div class="finding-path"><b>{source_name}</b> ({source_file}:{source_line}) → <b>{sink_name}</b> ({sink_file}:{sink_line})</div>
                    {sanitized_note}
                    <div class="snippet-pair">
                        <div><div class="snippet-label">source</div>{source_snippet}</div>
                        <div><div class="snippet-label">sink</div>{sink_snippet}</div>
                    </div>
                </div>"#,
                badge_color = badge_color,
                confidence = html_escape(&f.confidence.to_uppercase()),
                status = html_escape(&f.status),
                source_name = html_escape(f.source_key.split("::").last().unwrap_or(&f.source_key)),
                source_file = html_escape(&source_file),
                source_line = source_line,
                sink_name = html_escape(&sink_name),
                sink_file = html_escape(&sink_file),
                sink_line = sink_line,
                sanitized_note = sanitized_note,
                source_snippet = source_snippet,
                sink_snippet = sink_snippet,
            ));
        }

        (findings_html, nodes, edges, findings.len())
    } else {
        (
            "<p class='muted'>Анализ ни разу не запускался успешно для этого проекта.</p>".to_string(),
            vec![],
            vec![],
            0,
        )
    };

    // Ручная разметка.
    let manual = sqlx::query!(
        "SELECT file, line, kind, note FROM manual_annotations WHERE project_id = $1 ORDER BY file, line",
        input.project_id
    )
    .fetch_all(pool)
    .await?;

    let mut manual_html = String::new();
    if manual.is_empty() {
        manual_html.push_str("<p class='muted'>Ручная разметка не использовалась.</p>");
    }
    for m in &manual {
        let snippet = read_snippet(&project_dir, &m.file, m.line as usize);
        let kind_color = match m.kind.as_str() {
            "source" => "#38bdf8",
            "sink" => "#fb7185",
            _ => "#34d399",
        };
        manual_html.push_str(&format!(
            r#"<div class="finding">
                <div class="finding-header">
                    <span class="badge" style="background:{kind_color}22;color:{kind_color}">{kind}</span>
                </div>
                <div class="finding-path">{file}:{line}{note}</div>
                {snippet}
            </div>"#,
            kind_color = kind_color,
            kind = html_escape(&m.kind),
            file = html_escape(&m.file),
            line = m.line,
            note = m.note.as_deref().map(|n| format!(" — {}", html_escape(n))).unwrap_or_default(),
            snippet = snippet,
        ));
    }

    // Чек-лист целиком.
    let items = sqlx::query!(
        r#"SELECT section, language, label, checked, notes FROM checklist_items
           WHERE project_id = $1 ORDER BY section, sort_order"#,
        input.project_id
    )
    .fetch_all(pool)
    .await?;
    let rows = sqlx::query!(
        "SELECT section, data FROM checklist_rows WHERE project_id = $1 ORDER BY section, sort_order",
        input.project_id
    )
    .fetch_all(pool)
    .await?;

    let mut sections: std::collections::BTreeMap<String, Vec<(String, bool, String)>> = Default::default();
    for i in &items {
        let label = match &i.language {
            Some(lang) => format!("[{lang}] {}", i.label),
            None => i.label.clone(),
        };
        sections.entry(i.section.clone()).or_default().push((label, i.checked, i.notes.clone()));
    }

    let mut checklist_html = String::new();
    for (section, entries) in &sections {
        let checked_count = entries.iter().filter(|(_, c, _)| *c).count();
        checklist_html.push_str(&format!(
            "<details><summary>{section} — {checked}/{total}</summary><div class='section-body'>",
            section = html_escape(section),
            checked = checked_count,
            total = entries.len()
        ));
        for (label, checked, notes) in entries {
            let mark = if *checked { "✅" } else { "☐" };
            checklist_html.push_str(&format!(
                "<div class='checklist-row'><span>{mark}</span><div><div>{label}</div>{notes}</div></div>",
                mark = mark,
                label = html_escape(label),
                notes = if notes.trim().is_empty() {
                    String::new()
                } else {
                    format!("<div class='muted small'>{}</div>", html_escape(notes))
                }
            ));
        }
        checklist_html.push_str("</div></details>");
    }
    for row in &rows {
        let obj = row.data.as_object();
        let cells = obj
            .map(|m| {
                m.iter()
                    .map(|(k, v)| format!("<b>{}</b>: {}", html_escape(k), html_escape(v.as_str().unwrap_or(""))))
                    .collect::<Vec<_>>()
                    .join(" · ")
            })
            .unwrap_or_default();
        checklist_html.push_str(&format!(
            "<div class='table-row-report'><span class='muted small'>[{}]</span> {}</div>",
            html_escape(&row.section),
            cells
        ));
    }

    let nodes_json = serde_json::to_string(&graph_nodes)?;
    let edges_json = serde_json::to_string(&graph_edges)?;
    let generated_at = chrono::Utc::now().format("%Y-%m-%d %H:%M UTC").to_string();

    Ok(build_page(
        &input.project_name,
        &generated_at,
        graph_nodes.len(),
        graph_edges.len(),
        findings_count,
        &findings_html,
        &manual_html,
        &checklist_html,
        &nodes_json,
        &edges_json,
    ))
}

/// sink_key формата "имя@файл:строка" (см. db.rs::save_findings на стороне API).
fn parse_sink_key(sink_key: &str) -> (String, String, usize) {
    if let Some(at) = sink_key.rfind('@') {
        let name = &sink_key[..at];
        let rest = &sink_key[at + 1..];
        if let Some(colon) = rest.rfind(':') {
            let file = &rest[..colon];
            let line: usize = rest[colon + 1..].parse().unwrap_or(0);
            return (name.to_string(), file.to_string(), line);
        }
        return (name.to_string(), rest.to_string(), 0);
    }
    (sink_key.to_string(), String::new(), 0)
}

/// Читает окно в несколько строк вокруг нужной — НЕ весь файл. Если файл
/// недоступен (например, был удалён) — просто пропускает сниппет молча,
/// отчёт уже содержит достаточно контекста без него.
fn read_snippet(project_dir: &Path, rel_file: &str, target_line: usize) -> String {
    if rel_file.is_empty() || target_line == 0 {
        return String::new();
    }
    let full_path = project_dir.join(rel_file);
    let Ok(content) = std::fs::read_to_string(&full_path) else {
        return String::new();
    };
    let lines: Vec<&str> = content.lines().collect();
    if target_line == 0 || target_line > lines.len() {
        return String::new();
    }
    let start = target_line.saturating_sub(SNIPPET_CONTEXT_LINES + 1);
    let end = (target_line + SNIPPET_CONTEXT_LINES).min(lines.len());

    let mut out = String::from("<pre class='snippet'>");
    for (i, line) in lines[start..end].iter().enumerate() {
        let line_no = start + i + 1;
        let is_target = line_no == target_line;
        out.push_str(&format!(
            "<span class='{cls}'>{line_no:>4} | {content}</span>\n",
            cls = if is_target { "snippet-target-line" } else { "" },
            line_no = line_no,
            content = html_escape(line)
        ));
    }
    out.push_str("</pre>");
    out
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;")
}

#[allow(clippy::too_many_arguments)]
fn build_page(
    project_name: &str,
    generated_at: &str,
    node_count: usize,
    edge_count: usize,
    findings_count: usize,
    findings_html: &str,
    manual_html: &str,
    checklist_html: &str,
    nodes_json: &str,
    edges_json: &str,
) -> String {
    format!(
        r##"<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>codesink report — {project_name}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/dagre@0.8.5/dist/dagre.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/cytoscape-dagre@2.5.0/cytoscape-dagre.min.js"></script>
<style>
  :root {{
    --bg: #0a0910; --bg-panel: #14111d; --bg-panel-2: #1c1729;
    --border: #2b2440; --text: #eae6f5; --text-dim: #8b83a8;
    --accent: #a855f7; --accent-bright: #c084fc;
    --source: #38bdf8; --sink: #fb7185; --sanitizer: #34d399;
  }}
  * {{ box-sizing: border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--text); font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }}
  .wrap {{ max-width: 1000px; margin: 0 auto; padding: 32px 24px 80px; }}
  h1 {{ font-size: 24px; margin-bottom: 4px; }}
  .subtitle {{ color: var(--text-dim); font-size: 13px; margin-bottom: 28px; }}
  .stats {{ display:flex; gap: 16px; margin-bottom: 28px; }}
  .stat {{ background: var(--bg-panel); border:1px solid var(--border); border-radius: 10px; padding: 12px 18px; }}
  .stat b {{ display:block; font-size: 20px; }}
  .stat span {{ font-size: 11px; color: var(--text-dim); text-transform: uppercase; }}
  h2 {{ font-size: 16px; margin: 32px 0 12px; border-bottom: 1px solid var(--border); padding-bottom: 8px; }}
  .card {{ background: var(--bg-panel); border:1px solid var(--border); border-radius: 10px; padding: 16px; margin-bottom: 20px; }}
  .finding {{ background: var(--bg-panel-2); border:1px solid var(--border); border-radius: 8px; padding: 12px; margin-bottom: 10px; }}
  .finding-header {{ display:flex; gap:8px; align-items:center; margin-bottom:6px; }}
  .badge {{ font-family: monospace; font-size: 10px; padding: 2px 8px; border-radius: 4px; font-weight:600; }}
  .finding-status {{ font-size: 11px; color: var(--text-dim); }}
  .finding-path {{ font-size: 13px; margin-bottom: 8px; }}
  .sanitized-note {{ font-size: 11px; color: var(--sanitizer); margin-bottom: 8px; }}
  .snippet-pair {{ display:grid; grid-template-columns: 1fr 1fr; gap: 10px; }}
  .snippet-label {{ font-size: 10px; text-transform: uppercase; color: var(--text-dim); margin-bottom: 4px; }}
  .snippet {{ background: #0d0b14; border:1px solid var(--border); border-radius: 6px; padding: 8px; font-size: 11.5px; overflow-x:auto; margin:0; font-family: "JetBrains Mono", monospace; }}
  .snippet span {{ display:block; white-space:pre; }}
  .snippet-target-line {{ background: rgba(168,85,247,0.18); }}
  .muted {{ color: var(--text-dim); font-size: 13px; }}
  .small {{ font-size: 11px; }}
  details {{ background: var(--bg-panel); border:1px solid var(--border); border-radius: 8px; margin-bottom: 8px; }}
  summary {{ padding: 10px 14px; cursor: pointer; font-size: 13px; }}
  .section-body {{ padding: 0 14px 12px; }}
  .checklist-row {{ display:flex; gap:8px; padding: 6px 0; border-top: 1px solid var(--border); font-size: 12.5px; }}
  .table-row-report {{ font-size: 12px; padding: 4px 0; border-bottom: 1px solid var(--border); }}
  #graph {{ width: 100%; height: 600px; background: radial-gradient(circle at 30% 20%, #1a1428 0%, #0d0b14 70%); border-radius: 8px; }}
</style>
</head>
<body>
<div class="wrap">
  <h1>{project_name}</h1>
  <div class="subtitle">codesink отчёт · сгенерирован {generated_at}</div>

  <div class="stats">
    <div class="stat"><b>{node_count}</b><span>функций</span></div>
    <div class="stat"><b>{edge_count}</b><span>связей</span></div>
    <div class="stat"><b>{findings_count}</b><span>находок</span></div>
  </div>

  <h2>Граф вызовов</h2>
  <div class="card"><div id="graph"></div></div>

  <h2>Находки (автоматические)</h2>
  {findings_html}

  <h2>Ручная разметка</h2>
  {manual_html}

  <h2>Чек-лист</h2>
  {checklist_html}
</div>

<script>
  const nodes = {nodes_json};
  const edges = {edges_json};
  const elements = [
    ...nodes.map(n => ({{ data: {{ id: n.id, label: n.label + "\n" + n.file.split("/").pop() + ":" + n.line }} }})),
    ...edges.map(e => ({{ data: {{ id: e.source + "->" + e.target, source: e.source, target: e.target }} }})),
  ];
  cytoscape.use(cytoscapeDagre);
  cytoscape({{
    container: document.getElementById("graph"),
    elements,
    style: [
      {{ selector: "node", style: {{ label: "data(label)", "font-size": 9, color: "#eae6f5", "background-color": "#241d35", "border-width": 2, "border-color": "#3d3159", "text-wrap": "wrap", "text-max-width": "140px", width: 24, height: 24 }} }},
      {{ selector: "edge", style: {{ width: 1.8, "line-color": "#6d3fa8", "target-arrow-color": "#a855f7", "target-arrow-shape": "triangle", "curve-style": "bezier", opacity: 0.7 }} }},
    ],
    layout: {{ name: "dagre" }},
  }});
</script>
</body>
</html>"##,
        project_name = html_escape(project_name),
        generated_at = generated_at,
        node_count = node_count,
        edge_count = edge_count,
        findings_count = findings_count,
        findings_html = findings_html,
        manual_html = manual_html,
        checklist_html = checklist_html,
        nodes_json = nodes_json,
        edges_json = edges_json,
    )
}
