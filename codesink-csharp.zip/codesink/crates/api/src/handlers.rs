use crate::db;
use crate::dispatch;
use axum::{
    extract::{Multipart, Path as AxPath, Query, State},
    http::StatusCode,
    Json,
};
use codesink_core::model::MatchKind;
use codesink_core::rules::RuleSet;
use codesink_core::ManualAnnotation;
use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use std::path::PathBuf;
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    pub rules: RuleSet,
    /// Директория, куда временно распаковываются загруженные проекты
    pub upload_dir: PathBuf,
}

#[derive(Deserialize)]
pub struct CreateProjectReq {
    pub name: String,
}

#[derive(Serialize)]
pub struct CreateProjectResp {
    pub id: Uuid,
}

pub async fn create_project(
    State(state): State<AppState>,
    Json(req): Json<CreateProjectReq>,
) -> Result<Json<CreateProjectResp>, (StatusCode, String)> {
    let id = db::create_project(&state.pool, &req.name, "kotlin")
        .await
        .map_err(internal_err)?;
    Ok(Json(CreateProjectResp { id }))
}

/// Принимает .kt файлы через multipart/form-data, сохраняет их на диск
/// в директорию проекта. Реальная загрузка zip-архива и его распаковка —
/// TODO, для MVP шлём файлы по одному полем "file".
pub async fn upload_files(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    mut multipart: Multipart,
) -> Result<StatusCode, (StatusCode, String)> {
    let project_dir = state.upload_dir.join(project_id.to_string());
    std::fs::create_dir_all(&project_dir).map_err(internal_err)?;

    while let Some(field) = multipart.next_field().await.map_err(internal_err)? {
        let file_name = field
            .file_name()
            .map(|s| s.to_string())
            .unwrap_or_else(|| "unnamed.kt".to_string());
        let data = field.bytes().await.map_err(internal_err)?;
        let dest = project_dir.join(file_name);
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent).map_err(internal_err)?;
        }
        std::fs::write(dest, data).map_err(internal_err)?;
    }

    Ok(StatusCode::CREATED)
}

#[derive(Serialize)]
pub struct AnalyzeResp {
    pub run_id: Uuid,
    pub node_count: usize,
    pub edge_count: usize,
    pub findings_count: usize,
}

/// Запускает анализ синхронно (для MVP — без очереди задач).
/// На реальных проектах в сотни файлов стоит перенести это в фоновую
/// tokio-задачу со статусом "running" и поллингом с фронта.
pub async fn analyze_project(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<AnalyzeResp>, (StatusCode, String)> {
    let project_dir = state.upload_dir.join(project_id.to_string());
    if !project_dir.exists() {
        return Err((StatusCode::NOT_FOUND, "no files uploaded yet".into()));
    }

    let run_id = db::create_run(&state.pool, project_id)
        .await
        .map_err(internal_err)?;

    let manual_rows = db::list_manual_annotations(&state.pool, project_id)
        .await
        .map_err(internal_err)?;
    let manual_annotations: Vec<ManualAnnotation> = manual_rows
        .into_iter()
        .filter_map(|r| {
            let kind = match r.kind.as_str() {
                "source" => Some(MatchKind::Source),
                "sink" => Some(MatchKind::Sink),
                "sanitizer" => Some(MatchKind::Sanitizer),
                _ => None,
            }?;
            Some(ManualAnnotation {
                file: r.file,
                line: r.line as usize,
                kind,
            })
        })
        .collect();

    let result = dispatch::parse_project_directory(&project_dir)
        .and_then(|parsed| {
            codesink_core::analyze_project(parsed, &state.rules, &manual_annotations, 12)
        });

    match result {
        Ok(analysis) => {
            db::save_functions(&state.pool, run_id, &analysis.parsed.functions)
                .await
                .map_err(internal_err)?;
            db::save_calls(&state.pool, run_id, &analysis.parsed.calls)
                .await
                .map_err(internal_err)?;
            db::save_findings(&state.pool, run_id, &analysis.findings)
                .await
                .map_err(internal_err)?;
            db::finish_run(
                &state.pool,
                run_id,
                analysis.node_count as i32,
                analysis.edge_count as i32,
            )
            .await
            .map_err(internal_err)?;

            Ok(Json(AnalyzeResp {
                run_id,
                node_count: analysis.node_count,
                edge_count: analysis.edge_count,
                findings_count: analysis.findings.len(),
            }))
        }
        Err(e) => {
            db::fail_run(&state.pool, run_id, &e.to_string())
                .await
                .map_err(internal_err)?;
            Err((StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))
        }
    }
}

#[derive(Serialize)]
pub struct FindingRow {
    pub id: Uuid,
    pub source_key: String,
    pub sink_key: String,
    pub path: serde_json::Value,
    pub sanitized: bool,
    pub confidence: String,
    pub status: String,
}

pub async fn list_findings(
    State(state): State<AppState>,
    AxPath(run_id): AxPath<Uuid>,
) -> Result<Json<Vec<FindingRow>>, (StatusCode, String)> {
    let rows = sqlx::query_as!(
        FindingRow,
        r#"SELECT id, source_key, sink_key, path, sanitized, confidence, status
           FROM findings WHERE run_id = $1 ORDER BY confidence DESC"#,
        run_id
    )
    .fetch_all(&state.pool)
    .await
    .map_err(internal_err)?;

    Ok(Json(rows))
}

#[derive(Serialize)]
pub struct GraphNode {
    pub id: String,
    pub label: String,
    pub file: String,
    pub start_line: i32,
}

#[derive(Serialize)]
pub struct GraphEdge {
    pub source: String,
    pub target: String,
}

#[derive(Serialize)]
pub struct GraphResp {
    pub nodes: Vec<GraphNode>,
    pub edges: Vec<GraphEdge>,
}

pub async fn get_graph(
    State(state): State<AppState>,
    AxPath(run_id): AxPath<Uuid>,
) -> Result<Json<GraphResp>, (StatusCode, String)> {
    let rows = sqlx::query!(
        "SELECT function_key, name, file, start_line FROM functions WHERE run_id = $1",
        run_id
    )
    .fetch_all(&state.pool)
    .await
    .map_err(internal_err)?;

    let nodes = rows
        .into_iter()
        .map(|r| GraphNode {
            id: r.function_key,
            label: r.name,
            file: r.file,
            start_line: r.start_line,
        })
        .collect();

    // Только резолвленные вызовы (caller и callee — оба реально объявлены
    // в проекте) — вызовы во внешние библиотеки не образуют узел графа,
    // поэтому не могут быть ребром.
    let edge_rows = sqlx::query!(
        "SELECT caller_key, callee_key FROM calls WHERE run_id = $1 AND callee_key IS NOT NULL",
        run_id
    )
    .fetch_all(&state.pool)
    .await
    .map_err(internal_err)?;

    let edges = edge_rows
        .into_iter()
        .filter_map(|r| {
            r.callee_key.map(|target| GraphEdge {
                source: r.caller_key,
                target,
            })
        })
        .collect();

    Ok(Json(GraphResp { nodes, edges }))
}

#[derive(Serialize)]
pub struct ProjectListItem {
    pub id: Uuid,
    pub name: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

pub async fn list_projects(
    State(state): State<AppState>,
) -> Result<Json<Vec<ProjectListItem>>, (StatusCode, String)> {
    let rows = db::list_projects(&state.pool).await.map_err(internal_err)?;
    Ok(Json(
        rows.into_iter()
            .map(|r| ProjectListItem {
                id: r.id,
                name: r.name,
                created_at: r.created_at,
            })
            .collect(),
    ))
}

#[derive(Serialize)]
pub struct LatestRunResp {
    pub run_id: Option<Uuid>,
    pub status: Option<String>,
    pub node_count: Option<i32>,
    pub edge_count: Option<i32>,
    pub findings_count: Option<i64>,
}

pub async fn get_latest_run(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<LatestRunResp>, (StatusCode, String)> {
    let run = db::get_latest_run(&state.pool, project_id)
        .await
        .map_err(internal_err)?;
    match run {
        Some(r) => {
            let findings_count = db::count_findings(&state.pool, r.id).await.map_err(internal_err)?;
            Ok(Json(LatestRunResp {
                run_id: Some(r.id),
                status: Some(r.status),
                node_count: r.node_count,
                edge_count: r.edge_count,
                findings_count: Some(findings_count),
            }))
        }
        None => Ok(Json(LatestRunResp {
            run_id: None,
            status: None,
            node_count: None,
            edge_count: None,
            findings_count: None,
        })),
    }
}

/// Список .kt файлов проекта на диске — для вкладки "Ручная проверка",
/// где выбор файла не завязан на клик по узлу графа.
pub async fn list_project_files(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<Vec<String>>, (StatusCode, String)> {
    let project_dir = state.upload_dir.join(project_id.to_string());
    let mut files = Vec::new();
    for entry in walkdir::WalkDir::new(&project_dir)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| {
            e.path()
                .extension()
                .and_then(|ext| ext.to_str())
                .map(|ext| matches!(ext, "kt" | "kts" | "go" | "rs" | "py" | "js" | "jsx" | "ts" | "tsx" | "cs"))
                .unwrap_or(false)
        })
    {
        let rel = entry.path().strip_prefix(&project_dir).unwrap_or(entry.path());
        files.push(rel.to_string_lossy().to_string());
    }
    files.sort();
    Ok(Json(files))
}

/// Удаляет проект: строка в БД удаляется каскадно (runs/functions/calls/
/// findings/annotations — все ссылаются на projects с ON DELETE CASCADE),
/// плюс подчищаем загруженные файлы с диска.
pub async fn delete_project(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    sqlx::query!("DELETE FROM projects WHERE id = $1", project_id)
        .execute(&state.pool)
        .await
        .map_err(internal_err)?;

    let project_dir = state.upload_dir.join(project_id.to_string());
    let _ = std::fs::remove_dir_all(project_dir); // best-effort, не критично если уже нет

    Ok(StatusCode::NO_CONTENT)
}

#[derive(Deserialize)]
pub struct RenameProjectReq {
    pub name: String,
}

pub async fn rename_project(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    Json(req): Json<RenameProjectReq>,
) -> Result<StatusCode, (StatusCode, String)> {
    if req.name.trim().is_empty() {
        return Err((StatusCode::BAD_REQUEST, "name must not be empty".into()));
    }
    db::rename_project(&state.pool, project_id, req.name.trim())
        .await
        .map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Serialize)]
pub struct ChecklistItem {
    pub id: Uuid,
    pub section: String,
    pub language: Option<String>,
    pub label: String,
    pub checked: bool,
    pub notes: String,
    pub is_custom: bool,
}

#[derive(Serialize)]
pub struct ChecklistRow {
    pub id: Uuid,
    pub section: String,
    pub data: serde_json::Value,
}

#[derive(Serialize)]
pub struct ChecklistResp {
    pub items: Vec<ChecklistItem>,
    pub rows: Vec<ChecklistRow>,
    pub languages: Vec<String>,
}

pub async fn get_checklist(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<ChecklistResp>, (StatusCode, String)> {
    let project_dir = state.upload_dir.join(project_id.to_string());
    let languages = dispatch::detect_project_domains(&project_dir);

    let mut items = db::list_checklist_items(&state.pool, project_id)
        .await
        .map_err(internal_err)?;

    // Досеиваем шаблоны, которых у проекта ещё нет — срабатывает и на первом
    // открытии (пусто), и на существующих проектах после того, как в
    // checklist_templates появились новые пункты/секции (например, когда мы
    // добавили OWASP-стандарты уже после того, как ты начал ревью).
    let templates = db::list_templates_for(&state.pool, &languages)
        .await
        .map_err(internal_err)?;
    let existing: std::collections::HashSet<(String, Option<String>, String)> = items
        .iter()
        .map(|i| (i.section.clone(), i.language.clone(), i.label.clone()))
        .collect();
    let missing: Vec<db::ChecklistTemplateRow> = templates
        .into_iter()
        .filter(|t| {
            let lang = if t.language == "generic" { None } else { Some(t.language.clone()) };
            !existing.contains(&(t.section.clone(), lang, t.label.clone()))
        })
        .collect();
    if !missing.is_empty() {
        db::seed_checklist_items(&state.pool, project_id, &missing)
            .await
            .map_err(internal_err)?;
        items = db::list_checklist_items(&state.pool, project_id)
            .await
            .map_err(internal_err)?;
    }

    let rows = db::list_checklist_rows(&state.pool, project_id)
        .await
        .map_err(internal_err)?;

    Ok(Json(ChecklistResp {
        items: items
            .into_iter()
            .map(|i| ChecklistItem {
                id: i.id,
                section: i.section,
                language: i.language,
                label: i.label,
                checked: i.checked,
                notes: i.notes,
                is_custom: i.is_custom,
            })
            .collect(),
        rows: rows
            .into_iter()
            .map(|r| ChecklistRow { id: r.id, section: r.section, data: r.data })
            .collect(),
        languages,
    }))
}

#[derive(Deserialize)]
pub struct AddChecklistItemReq {
    pub section: String,
    pub language: Option<String>,
    pub label: String,
}

pub async fn add_checklist_item(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    Json(req): Json<AddChecklistItemReq>,
) -> Result<Json<CreateAnnotationResp>, (StatusCode, String)> {
    let id = db::add_checklist_item(&state.pool, project_id, &req.section, req.language.as_deref(), &req.label)
        .await
        .map_err(internal_err)?;
    Ok(Json(CreateAnnotationResp { id }))
}

#[derive(Deserialize)]
pub struct UpdateChecklistItemReq {
    pub checked: bool,
    pub notes: String,
}

pub async fn update_checklist_item(
    State(state): State<AppState>,
    AxPath(item_id): AxPath<Uuid>,
    Json(req): Json<UpdateChecklistItemReq>,
) -> Result<StatusCode, (StatusCode, String)> {
    db::update_checklist_item(&state.pool, item_id, req.checked, &req.notes)
        .await
        .map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

pub async fn delete_checklist_item(
    State(state): State<AppState>,
    AxPath(item_id): AxPath<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    db::delete_checklist_item(&state.pool, item_id).await.map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

pub async fn promote_checklist_item(
    State(state): State<AppState>,
    AxPath(item_id): AxPath<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    db::promote_checklist_item(&state.pool, item_id).await.map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Deserialize)]
pub struct AddChecklistRowReq {
    pub section: String,
    pub data: serde_json::Value,
}

pub async fn add_checklist_row(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    Json(req): Json<AddChecklistRowReq>,
) -> Result<Json<CreateAnnotationResp>, (StatusCode, String)> {
    let id = db::add_checklist_row(&state.pool, project_id, &req.section, &req.data)
        .await
        .map_err(internal_err)?;
    Ok(Json(CreateAnnotationResp { id }))
}

#[derive(Deserialize)]
pub struct UpdateChecklistRowReq {
    pub data: serde_json::Value,
}

pub async fn update_checklist_row(
    State(state): State<AppState>,
    AxPath(row_id): AxPath<Uuid>,
    Json(req): Json<UpdateChecklistRowReq>,
) -> Result<StatusCode, (StatusCode, String)> {
    db::update_checklist_row(&state.pool, row_id, &req.data).await.map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

pub async fn delete_checklist_row(
    State(state): State<AppState>,
    AxPath(row_id): AxPath<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    db::delete_checklist_row(&state.pool, row_id).await.map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Serialize)]
pub struct GenerateReportResp {
    pub id: Uuid,
}

/// Генерирует отчёт СЕЙЧАС, пока файлы проекта ещё на диске — это важно:
/// отчёт снапшотит код/находки/чек-лист в момент вызова, и дальше живёт
/// независимо от того, удалишь ли ты потом сам проект.
pub async fn generate_report(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<GenerateReportResp>, (StatusCode, String)> {
    let project = sqlx::query!("SELECT name FROM projects WHERE id = $1", project_id)
        .fetch_optional(&state.pool)
        .await
        .map_err(internal_err)?
        .ok_or((StatusCode::NOT_FOUND, "project not found".to_string()))?;

    let input = crate::report::ReportInput {
        project_name: project.name.clone(),
        upload_dir: state.upload_dir.clone(),
        project_id,
    };
    let html = crate::report::generate_html(&state.pool, &input)
        .await
        .map_err(internal_err)?;

    let reports_dir = state.upload_dir.join("reports");
    std::fs::create_dir_all(&reports_dir).map_err(internal_err)?;
    let file_name = format!("{}.html", Uuid::new_v4());
    std::fs::write(reports_dir.join(&file_name), html).map_err(internal_err)?;

    let id = db::create_report(&state.pool, project_id, &project.name, &file_name)
        .await
        .map_err(internal_err)?;

    Ok(Json(GenerateReportResp { id }))
}

#[derive(Serialize)]
pub struct ReportListItem {
    pub id: Uuid,
    pub project_name: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

pub async fn list_reports(
    State(state): State<AppState>,
) -> Result<Json<Vec<ReportListItem>>, (StatusCode, String)> {
    let rows = db::list_reports(&state.pool).await.map_err(internal_err)?;
    Ok(Json(
        rows.into_iter()
            .map(|r| ReportListItem { id: r.id, project_name: r.project_name, created_at: r.created_at })
            .collect(),
    ))
}

pub async fn get_report(
    State(state): State<AppState>,
    AxPath(report_id): AxPath<Uuid>,
) -> Result<axum::response::Html<String>, (StatusCode, String)> {
    let file_name = db::get_report_file_name(&state.pool, report_id)
        .await
        .map_err(internal_err)?
        .ok_or((StatusCode::NOT_FOUND, "report not found".to_string()))?;
    let content = std::fs::read_to_string(state.upload_dir.join("reports").join(file_name))
        .map_err(internal_err)?;
    Ok(axum::response::Html(content))
}

pub async fn delete_report_handler(
    State(state): State<AppState>,
    AxPath(report_id): AxPath<Uuid>,
) -> Result<StatusCode, (StatusCode, String)> {
    if let Some(file_name) = db::get_report_file_name(&state.pool, report_id).await.map_err(internal_err)? {
        let _ = std::fs::remove_file(state.upload_dir.join("reports").join(file_name));
    }
    db::delete_report(&state.pool, report_id).await.map_err(internal_err)?;
    Ok(StatusCode::NO_CONTENT)
}

fn internal_err<E: std::fmt::Display>(e: E) -> (StatusCode, String) {
    (StatusCode::INTERNAL_SERVER_ERROR, e.to_string())
}

#[derive(Deserialize)]
pub struct CreateAnnotationReq {
    pub file: String,
    pub line: i32,
    pub kind: String, // source | sink | sanitizer
    pub note: Option<String>,
}

#[derive(Serialize)]
pub struct CreateAnnotationResp {
    pub id: Uuid,
}

pub async fn create_annotation(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    Json(req): Json<CreateAnnotationReq>,
) -> Result<Json<CreateAnnotationResp>, (StatusCode, String)> {
    if !["source", "sink", "sanitizer"].contains(&req.kind.as_str()) {
        return Err((StatusCode::BAD_REQUEST, "kind must be source|sink|sanitizer".into()));
    }
    let id = db::create_manual_annotation(
        &state.pool,
        project_id,
        &req.file,
        req.line,
        &req.kind,
        req.note.as_deref(),
    )
    .await
    .map_err(internal_err)?;
    Ok(Json(CreateAnnotationResp { id }))
}

#[derive(Serialize)]
pub struct AnnotationRow {
    pub file: String,
    pub line: i32,
    pub kind: String,
}

pub async fn list_annotations(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
) -> Result<Json<Vec<AnnotationRow>>, (StatusCode, String)> {
    let rows = db::list_manual_annotations(&state.pool, project_id)
        .await
        .map_err(internal_err)?;
    Ok(Json(
        rows.into_iter()
            .map(|r| AnnotationRow {
                file: r.file,
                line: r.line,
                kind: r.kind,
            })
            .collect(),
    ))
}

#[derive(Deserialize)]
pub struct FileQuery {
    pub path: String,
}

/// Отдаёт сырое содержимое файла для code-viewer. query.path — ОТНОСИТЕЛЬНЫЙ
/// путь внутри проекта (тот же формат, что в GraphNode.file) — сюда
/// подставляется upload_dir/project_id сервером, фронт не должен знать
/// про физическое расположение файлов на диске.
pub async fn get_file_content(
    State(state): State<AppState>,
    AxPath(project_id): AxPath<Uuid>,
    Query(query): Query<FileQuery>,
) -> Result<String, (StatusCode, String)> {
    let full_path = state.upload_dir.join(project_id.to_string()).join(&query.path);
    std::fs::read_to_string(&full_path).map_err(|e| (StatusCode::NOT_FOUND, e.to_string()))
}
