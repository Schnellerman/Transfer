//! Парсинг .go файлов через tree-sitter-go.
//!
//! ⚠️ НЕ ПРОВЕРЕНО на реальном коде — в отличие от lang-kotlin, который прошёл
//! через несколько раундов отладки на реальных файлах. Grammar-поля ниже
//! (name/parameters/body/receiver/function/arguments/operand/field)
//! соответствуют документированной структуре tree-sitter-go, но прежде чем
//! доверять результатам — прогони bin/debug_parse.rs на реальном .go файле
//! из своих тикетов и сверь вывод, как мы делали для Kotlin.
//!
//! В Go нет аннотаций — source обычно определяется вызовом (например
//! `r.URL.Query().Get(...)`), а не декларацией функции. Поэтому здесь
//! annotations/param_annotations всегда пустые: сам движок (core::graph)
//! умеет матчить source-правила по вызовам, см. config/rules-go.yaml.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const NODE_FUNCTION_DECL: &str = "function_declaration";
const NODE_METHOD_DECL: &str = "method_declaration";
const NODE_CALL_EXPR: &str = "call_expression";
const NODE_SELECTOR_EXPR: &str = "selector_expression";
const NODE_IDENTIFIER: &str = "identifier";
const NODE_POINTER_TYPE: &str = "pointer_type";
const NODE_TYPE_IDENTIFIER: &str = "type_identifier";

pub fn make_parser() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_go::language())
        .context("failed to load go grammar")?;
    Ok(parser)
}

pub fn dump_sexp(source: &str) -> Result<String> {
    let mut parser = make_parser()?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = make_parser()?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    let mut cursor = root.walk();
    for child in root.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_FUNCTION_DECL => parse_function(child, source, &file_str, None, &mut result),
            k if k == NODE_METHOD_DECL => {
                let owner = extract_receiver_type(child, source);
                parse_function(child, source, &file_str, owner, &mut result);
            }
            _ => {}
        }
    }
    Ok(result)
}

fn extract_receiver_type(method_node: Node, source: &str) -> Option<String> {
    let receiver = method_node.child_by_field_name("receiver")?;
    // receiver — parameter_list с одним parameter_declaration, поле type
    let mut cursor = receiver.walk();
    let param_decl = receiver.children(&mut cursor).find(|c| c.kind() == "parameter_declaration")?;
    let ty = param_decl.child_by_field_name("type")?;
    let type_node = if ty.kind() == NODE_POINTER_TYPE {
        find_child_of_kind(ty, NODE_TYPE_IDENTIFIER)?
    } else {
        ty
    };
    Some(node_text(type_node, source))
}

fn parse_function(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    out: &mut ParsedProject,
) {
    let Some(name_node) = node.child_by_field_name("name") else { return };
    let name = node_text(name_node, source);
    let id = make_function_id(file, owner.as_deref(), &name);

    out.functions.push(FunctionDef {
        id: id.clone(),
        name,
        owner,
        receiver_type: None,
        file: file.to_string(),
        start_line: node.start_position().row + 1,
        end_line: node.end_position().row + 1,
        annotations: Vec::new(),
        param_annotations: Vec::new(),
    });

    if let Some(body) = node.child_by_field_name("body") {
        collect_calls(body, source, file, &id, out);
    }
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_CALL_EXPR {
            if let Some((callee_name, receiver)) = extract_call_info(child, source) {
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name,
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        }
        collect_calls(child, source, file, caller_id, out);
    }
}

/// Возвращает (имя_вызова, receiver). receiver — текст поля "operand" из
/// selector_expression ("db" в "db.Query(...)"), нужен для owner в правилах.
fn extract_call_info(call_node: Node, source: &str) -> Option<(String, Option<String>)> {
    let func_node = call_node.child_by_field_name("function")?;
    match func_node.kind() {
        k if k == NODE_IDENTIFIER => Some((node_text(func_node, source), None)),
        k if k == NODE_SELECTOR_EXPR => {
            let field = func_node.child_by_field_name("field")?;
            let receiver = func_node.child_by_field_name("operand").map(|n| node_text(n, source));
            Some((node_text(field, source), receiver))
        }
        _ => None,
    }
}

fn find_child_of_kind<'a>(node: Node<'a>, kind: &str) -> Option<Node<'a>> {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == kind {
            return Some(child);
        }
    }
    None
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

fn make_function_id(file: &str, owner: Option<&str>, name: &str) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}"),
        None => format!("{file}::{name}"),
    }
}
