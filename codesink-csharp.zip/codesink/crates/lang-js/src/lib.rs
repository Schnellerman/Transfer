//! Парсинг .js/.jsx/.ts/.tsx через tree-sitter-javascript / tree-sitter-typescript.
//!
//! ⚠️ НЕ ПРОВЕРЕНО на реальном коде — прогони bin/debug_parse.rs на реальном
//! файле, прежде чем доверять результатам (см. предупреждение в lang-go).
//!
//! Самое сложное здесь — анонимные функции: в Express/Koa-стиле роутов
//! обработчик почти всегда встроен прямо в вызов: `app.get('/x', (req, res)
//! => { ... })`. У такой стрелочной функции нет имени, поэтому: если она
//! присвоена переменной — берём имя переменной; иначе — синтетическое имя
//! `<anon>:строка`, чтобы вызовы внутри неё всё равно попали в граф и могли
//! матчиться как source по самому факту вызова (см. rules-js.yaml).
//! ВАЖНО: у member-выражений (a.b) поле называется "property", а не "field"
//! (в отличие от Go/Rust) — источник частых опечаток при портировании.
//!
//! ⚠️ ДОПОЛНИТЕЛЬНО: версия tree-sitter-typescript = "0.21.1" и имя функции
//! `language_typescript()` я не смог стопроцентно подтвердить документацией
//! (только `language_tsx()` подтверждён напрямую) — если cargo ругнётся на
//! отсутствие такой функции, смотри `cargo doc -p tree-sitter-typescript --open`
//! или `docs.rs/tree-sitter-typescript/0.21.1` за точным именем.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const NODE_FUNCTION_DECL: &str = "function_declaration";
const NODE_METHOD_DEF: &str = "method_definition";
const NODE_ARROW_FN: &str = "arrow_function";
const NODE_FUNCTION_EXPR: &str = "function_expression";
const NODE_CLASS_DECL: &str = "class_declaration";
const NODE_VARIABLE_DECLARATOR: &str = "variable_declarator";
const NODE_CALL_EXPR: &str = "call_expression";
const NODE_MEMBER_EXPR: &str = "member_expression";
const NODE_IDENTIFIER: &str = "identifier";
const NODE_DECORATOR: &str = "decorator";

pub fn make_parser_js() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_javascript::language())
        .context("failed to load javascript grammar")?;
    Ok(parser)
}

pub fn make_parser_ts(tsx: bool) -> Result<Parser> {
    let mut parser = Parser::new();
    let lang = if tsx {
        tree_sitter_typescript::language_tsx()
    } else {
        tree_sitter_typescript::language_typescript()
    };
    parser.set_language(&lang).context("failed to load typescript grammar")?;
    Ok(parser)
}

fn parser_for(path: &Path) -> Result<Parser> {
    match path.extension().and_then(|e| e.to_str()) {
        Some("ts") => make_parser_ts(false),
        Some("tsx") => make_parser_ts(true),
        _ => make_parser_js(), // .js/.jsx по умолчанию
    }
}

pub fn dump_sexp(path: &Path, source: &str) -> Result<String> {
    let mut parser = parser_for(path)?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = parser_for(path)?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    walk_declarations(root, source, &file_str, None, &mut result);
    Ok(result)
}

fn walk_declarations(
    node: Node,
    source: &str,
    file: &str,
    current_owner: Option<String>,
    out: &mut ParsedProject,
) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_CLASS_DECL => {
                let owner = child.child_by_field_name("name").map(|n| node_text(n, source));
                walk_declarations(child, source, file, owner, out);
            }
            k if k == NODE_FUNCTION_DECL || k == NODE_METHOD_DEF => {
                let name = child
                    .child_by_field_name("name")
                    .map(|n| node_text(n, source))
                    .unwrap_or_else(|| format!("<anon>:{}", child.start_position().row + 1));
                parse_function(child, source, file, current_owner.clone(), name, out);
            }
            k if k == NODE_VARIABLE_DECLARATOR => {
                // const handler = (req, res) => {...} — имя из переменной,
                // сама функция лежит в поле "value".
                if let Some(value) = child.child_by_field_name("value") {
                    if value.kind() == NODE_ARROW_FN || value.kind() == NODE_FUNCTION_EXPR {
                        let name = child
                            .child_by_field_name("name")
                            .map(|n| node_text(n, source))
                            .unwrap_or_else(|| format!("<anon>:{}", value.start_position().row + 1));
                        parse_function(value, source, file, current_owner.clone(), name, out);
                        continue;
                    }
                }
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
            k if k == NODE_ARROW_FN || k == NODE_FUNCTION_EXPR => {
                // Инлайн-колбэк напрямую в аргументах вызова, например
                // app.get('/x', (req, res) => {...}) — своего имени нет.
                let name = format!("<anon>:{}", child.start_position().row + 1);
                parse_function(child, source, file, current_owner.clone(), name, out);
            }
            _ => {
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
        }
    }
}

fn parse_function(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    name: String,
    out: &mut ParsedProject,
) {
    let id = make_function_id(file, owner.as_deref(), &name);

    // Декораторы (TS): @Get('/search') и т.п. — ищем среди предыдущих
    // siblings узла (в грамматике они не вложены внутрь самого метода).
    let annotations = collect_preceding_decorators(node, source);

    out.functions.push(FunctionDef {
        id: id.clone(),
        name,
        owner,
        receiver_type: None,
        file: file.to_string(),
        start_line: node.start_position().row + 1,
        end_line: node.end_position().row + 1,
        annotations,
        param_annotations: Vec::new(),
    });

    if let Some(body) = node.child_by_field_name("body") {
        collect_calls(body, source, file, &id, out);
    }

    // Рекурсия внутрь тела — на случай вложенных функций.
    if let Some(body) = node.child_by_field_name("body") {
        walk_declarations(body, source, file, owner_from_id(&id), out);
    }
}

fn owner_from_id(_id: &str) -> Option<String> {
    None // вложенные функции не наследуют owner — упрощение для MVP
}

fn collect_preceding_decorators(node: Node, source: &str) -> Vec<String> {
    let mut result = Vec::new();
    let mut prev = node.prev_sibling();
    while let Some(p) = prev {
        if p.kind() == NODE_DECORATOR {
            result.push(node_text(p, source));
            prev = p.prev_sibling();
        } else {
            break;
        }
    }
    result.reverse();
    result
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_CALL_EXPR {
            if let Some((callee_name, receiver)) = extract_call_info(child, source) {
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name,
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        } else if child.kind() == NODE_MEMBER_EXPR && !is_call_function_part(child) {
            // req.query / req.body / req.params и т.п. — самые частые
            // источники в Express на практике НЕ вызовы функций, а прямое
            // обращение к свойству. Записываем как псевдо-вызов, чтобы
            // source-правила (function_name) могли их матчить так же, как
            // обычные вызовы — см. rules-js.yaml.
            if let Some(prop) = child.child_by_field_name("property") {
                let receiver = child.child_by_field_name("object").map(|n| node_text(n, source));
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name: node_text(prop, source),
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        }
        // Не рекурсируем внутрь вложенных function/arrow здесь — они
        // обрабатываются отдельно через walk_declarations на теле функции,
        // иначе вызовы задвоятся (попадут и во внешнего, и во внутреннего caller).
        if !is_function_like(child.kind()) {
            collect_calls(child, source, file, caller_id, out);
        }
    }
}

/// true, если этот member_expression — то самое "req.get" внутри
/// call_expression("req.get", args), то есть его уже обработает
/// extract_callee_name как обычный вызов, и повторно как property-access
/// записывать не нужно (иначе задвоится).
fn is_call_function_part(node: Node) -> bool {
    let Some(parent) = node.parent() else { return false };
    if parent.kind() != NODE_CALL_EXPR {
        return false;
    }
    parent.child_by_field_name("function") == Some(node)
}

fn is_function_like(kind: &str) -> bool {
    kind == NODE_ARROW_FN || kind == NODE_FUNCTION_EXPR || kind == NODE_FUNCTION_DECL || kind == NODE_METHOD_DEF
}

/// Возвращает (имя_вызова, receiver). receiver — текст поля "object" из
/// member_expression ("req" в "req.get(...)"), нужен для owner в правилах.
fn extract_call_info(call_node: Node, source: &str) -> Option<(String, Option<String>)> {
    let func_node = call_node.child_by_field_name("function")?;
    match func_node.kind() {
        k if k == NODE_IDENTIFIER => Some((node_text(func_node, source), None)),
        k if k == NODE_MEMBER_EXPR => {
            let prop = func_node.child_by_field_name("property")?;
            let receiver = func_node.child_by_field_name("object").map(|n| node_text(n, source));
            Some((node_text(prop, source), receiver))
        }
        _ => None,
    }
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

fn make_function_id(file: &str, owner: Option<&str>, name: &str) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}"),
        None => format!("{file}::{name}"),
    }
}
