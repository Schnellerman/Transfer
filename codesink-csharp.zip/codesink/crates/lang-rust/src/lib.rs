//! Парсинг .rs файлов через tree-sitter-rust.
//!
//! ⚠️ НЕ ПРОВЕРЕНО на реальном коде — прогони bin/debug_parse.rs на реальном
//! .rs файле, прежде чем доверять результатам (см. предупреждение в lang-go).
//!
//! Атрибуты (#[get("/search")] и т.п.) в грамматике Rust — отдельные узлы
//! ПЕРЕД function_item, а не внутри него, поэтому их разбор сложнее
//! позиционно и пока не реализован. Source/sink здесь определяются через
//! вызовы (см. config/rules-rust.yaml), как и в Go.
//!
//! Версия tree-sitter-rust = "0.21.2" подтверждена: её зависимость от
//! tree-sitter указана как ">=0.21.0" без верхней границы, поэтому спокойно
//! уживается с tree-sitter=0.22, который жёстко требует tree-sitter-kotlin.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const NODE_FUNCTION_ITEM: &str = "function_item";
const NODE_IMPL_ITEM: &str = "impl_item";
const NODE_MOD_ITEM: &str = "mod_item";
const NODE_CALL_EXPR: &str = "call_expression";
const NODE_FIELD_EXPR: &str = "field_expression";
const NODE_IDENTIFIER: &str = "identifier";
const NODE_FIELD_IDENTIFIER: &str = "field_identifier";

pub fn make_parser() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_rust::language())
        .context("failed to load rust grammar")?;
    Ok(parser)
}

pub fn dump_sexp(source: &str) -> Result<String> {
    let mut parser = make_parser()?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = make_parser()?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    walk_declarations(root, source, &file_str, None, &mut result);
    Ok(result)
}

fn walk_declarations(
    node: Node,
    source: &str,
    file: &str,
    current_owner: Option<String>,
    out: &mut ParsedProject,
) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_IMPL_ITEM => {
                let owner = child.child_by_field_name("type").map(|n| node_text(n, source));
                walk_declarations(child, source, file, owner, out);
            }
            k if k == NODE_MOD_ITEM => {
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
            k if k == NODE_FUNCTION_ITEM => {
                parse_function(child, source, file, current_owner.clone(), out);
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
            _ => {
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
        }
    }
}

fn parse_function(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    out: &mut ParsedProject,
) {
    let Some(name_node) = node.child_by_field_name("name") else { return };
    let name = node_text(name_node, source);
    let id = make_function_id(file, owner.as_deref(), &name);

    out.functions.push(FunctionDef {
        id: id.clone(),
        name,
        owner,
        receiver_type: None,
        file: file.to_string(),
        start_line: node.start_position().row + 1,
        end_line: node.end_position().row + 1,
        annotations: Vec::new(),
        param_annotations: Vec::new(),
    });

    if let Some(body) = node.child_by_field_name("body") {
        collect_calls(body, source, file, &id, out);
    }
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_CALL_EXPR {
            if let Some((callee_name, receiver)) = extract_call_info(child, source) {
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name,
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        }
        collect_calls(child, source, file, caller_id, out);
    }
}

/// Возвращает (имя_вызова, receiver). receiver — текст поля "value" из
/// field_expression ("pool" в "pool.execute(...)"), нужен для owner в
/// правилах. Для цепочек вроде sqlx::query(sql).execute(pool) receiver
/// будет всем текстом до последней точки — тоже полезно, просто длиннее.
fn extract_call_info(call_node: Node, source: &str) -> Option<(String, Option<String>)> {
    let func_node = call_node.child_by_field_name("function")?;
    match func_node.kind() {
        k if k == NODE_IDENTIFIER => Some((node_text(func_node, source), None)),
        k if k == NODE_FIELD_EXPR => {
            let field = func_node.child_by_field_name("field")?;
            if field.kind() != NODE_FIELD_IDENTIFIER {
                return None;
            }
            let receiver = func_node.child_by_field_name("value").map(|n| node_text(n, source));
            Some((node_text(field, source), receiver))
        }
        _ => None,
    }
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

fn make_function_id(file: &str, owner: Option<&str>, name: &str) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}"),
        None => format!("{file}::{name}"),
    }
}
