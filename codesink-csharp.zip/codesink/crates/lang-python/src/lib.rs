//! Парсинг .py файлов через tree-sitter-python.
//!
//! ⚠️ НЕ ПРОВЕРЕНО на реальном коде — прогони bin/debug_parse.rs на реальном
//! .py файле, прежде чем доверять результатам (см. предупреждение в lang-go).
//!
//! ВАЖНО: у Python вызов называется "call", а не "call_expression" — легко
//! перепутать по аналогии с другими языками, будь внимателен при отладке.
//! Декораторы (@app.route(...)) собираются как аннотации — работает похоже
//! на @RequestParam в Kotlin.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const NODE_FUNCTION_DEF: &str = "function_definition";
const NODE_CLASS_DEF: &str = "class_definition";
const NODE_DECORATED_DEF: &str = "decorated_definition";
const NODE_DECORATOR: &str = "decorator";
const NODE_CALL: &str = "call";
const NODE_ATTRIBUTE: &str = "attribute";
const NODE_IDENTIFIER: &str = "identifier";

pub fn make_parser() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_python::language())
        .context("failed to load python grammar")?;
    Ok(parser)
}

pub fn dump_sexp(source: &str) -> Result<String> {
    let mut parser = make_parser()?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = make_parser()?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    walk_declarations(root, source, &file_str, None, &mut result);
    Ok(result)
}

fn walk_declarations(
    node: Node,
    source: &str,
    file: &str,
    current_owner: Option<String>,
    out: &mut ParsedProject,
) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_CLASS_DEF => {
                let owner = child.child_by_field_name("name").map(|n| node_text(n, source));
                if let Some(body) = child.child_by_field_name("body") {
                    walk_declarations(body, source, file, owner, out);
                }
            }
            k if k == NODE_DECORATED_DEF => {
                let decorators: Vec<String> = {
                    let mut c = child.walk();
                    child
                        .children(&mut c)
                        .filter(|n| n.kind() == NODE_DECORATOR)
                        .map(|n| node_text(n, source))
                        .collect()
                };
                if let Some(def) = child.child_by_field_name("definition") {
                    if def.kind() == NODE_FUNCTION_DEF {
                        parse_function(def, source, file, current_owner.clone(), decorators, out);
                    } else if def.kind() == NODE_CLASS_DEF {
                        walk_declarations(child, source, file, current_owner.clone(), out);
                    }
                }
            }
            k if k == NODE_FUNCTION_DEF => {
                parse_function(child, source, file, current_owner.clone(), Vec::new(), out);
            }
            _ => {
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
        }
    }
}

fn parse_function(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    annotations: Vec<String>,
    out: &mut ParsedProject,
) {
    let Some(name_node) = node.child_by_field_name("name") else { return };
    let name = node_text(name_node, source);
    let id = make_function_id(file, owner.as_deref(), &name);

    out.functions.push(FunctionDef {
        id: id.clone(),
        name,
        owner,
        receiver_type: None,
        file: file.to_string(),
        start_line: node.start_position().row + 1,
        end_line: node.end_position().row + 1,
        annotations,
        param_annotations: Vec::new(),
    });

    if let Some(body) = node.child_by_field_name("body") {
        collect_calls(body, source, file, &id, out);
    }
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_CALL {
            if let Some((callee_name, receiver)) = extract_call_info(child, source) {
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name,
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        }
        collect_calls(child, source, file, caller_id, out);
    }
}

/// Возвращает (имя_вызова, receiver). receiver — текст поля "object" из
/// attribute ("pickle" в "pickle.load(f)") — критично для правил вроде
/// ai-unsafe-model-load, чтобы не путать pickle.load с json.load.
fn extract_call_info(call_node: Node, source: &str) -> Option<(String, Option<String>)> {
    let func_node = call_node.child_by_field_name("function")?;
    match func_node.kind() {
        k if k == NODE_IDENTIFIER => Some((node_text(func_node, source), None)),
        k if k == NODE_ATTRIBUTE => {
            let attr = func_node.child_by_field_name("attribute")?;
            let receiver = func_node.child_by_field_name("object").map(|n| node_text(n, source));
            Some((node_text(attr, source), receiver))
        }
        _ => None,
    }
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

fn make_function_id(file: &str, owner: Option<&str>, name: &str) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}"),
        None => format!("{file}::{name}"),
    }
}
