//! Парсинг .cs файлов через tree-sitter-c-sharp.
//!
//! ⚠️ НЕ ПРОВЕРЕНО на реальном коде (в песочнице не было доступа к crates.io).
//! Прогони bin/debug_parse.rs на настоящем контроллере и сверь вывод, как мы
//! делали для Kotlin. Парсер намеренно написан устойчиво к названиям полей
//! грамматики: где возможно, он ищет узлы по `kind` среди детей, а не по полю.
//!
//! Что извлекается:
//! * методы, конструкторы, local functions, top-level statements
//!   (Program.cs → функция `<top-level>`);
//! * атрибуты метода и параметров как аннотации: `[FromQuery]` → "@FromQuery",
//!   `[HttpGet("/x")]` → "@HttpGet(\"/x\")" (правила матчатся по подстроке);
//! * вызовы `Foo()`, `obj.Foo()`, `obj?.Foo()`, `new Foo(...)` (как вызов `Foo`);
//! * обращения к свойствам из списка PROPERTY_SOURCES (`Request.Query`,
//!   `Request.Form`, …) как pseudo-call — так же, как мы делали для JS `req.query`.
//!
//! receiver — последний сегмент выражения: `HttpContext.Request.Query` →
//! receiver "Request", `this.db.Foo()` → "db". Для owner в правилах это важно.
//!
//! Ограничения: лямбды без имени (Minimal API `app.MapGet("/", (string q) => ...)`)
//! не становятся отдельными функциями — их вызовы приписываются охватывающей
//! функции или `<top-level>`; параметры лямбд не считаются source.
//! Свойства (get/set) и инициализаторы полей не обходятся.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const TYPE_KINDS: &[&str] = &[
    "class_declaration",
    "struct_declaration",
    "record_declaration",
    "record_struct_declaration",
    "interface_declaration",
];
const FUNCTION_KINDS: &[&str] = &[
    "method_declaration",
    "constructor_declaration",
    "destructor_declaration",
    "operator_declaration",
    "local_function_statement",
];
const NODE_LOCAL_FUNCTION: &str = "local_function_statement";
const NODE_GLOBAL_STATEMENT: &str = "global_statement";
const NODE_INVOCATION: &str = "invocation_expression";
const NODE_OBJECT_CREATION: &str = "object_creation_expression";
const NODE_MEMBER_ACCESS: &str = "member_access_expression";
const NODE_MEMBER_BINDING: &str = "member_binding_expression";
const NODE_COND_ACCESS: &str = "conditional_access_expression";
const NODE_IDENTIFIER: &str = "identifier";
const NODE_GENERIC_NAME: &str = "generic_name";
const NODE_ATTRIBUTE_LIST: &str = "attribute_list";
const NODE_ATTRIBUTE: &str = "attribute";
const NODE_PARAMETER_LIST: &str = "parameter_list";
const NODE_PARAMETER: &str = "parameter";

/// Свойства, чьё чтение считается pseudo-call (иначе в граф попадал бы каждый `a.b`).
const PROPERTY_SOURCES: &[&str] = &[
    "Query", "Form", "Headers", "Cookies", "QueryString", "Body", "RouteValues", "Files",
    "Path", "PathBase", "Referer", "UserAgent", "RawUrl", "Params", "ServerVariables",
];

pub fn make_parser() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_c_sharp::language())
        .context("failed to load c# grammar")?;
    Ok(parser)
}

pub fn dump_sexp(source: &str) -> Result<String> {
    let mut parser = make_parser()?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = make_parser()?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    let mut top = TopLevel::default();
    visit(root, source, &file_str, None, &mut result, &mut top);

    if top.seen {
        let id = format!("{file_str}::<top-level>");
        result.functions.push(FunctionDef {
            id: id.clone(),
            name: "<top-level>".to_string(),
            owner: None,
            receiver_type: None,
            file: file_str.clone(),
            start_line: top.start_line,
            end_line: top.end_line,
            annotations: Vec::new(),
            param_annotations: Vec::new(),
        });
        for mut c in top.calls {
            c.caller = id.clone();
            result.calls.push(c);
        }
    }
    Ok(result)
}

#[derive(Default)]
struct TopLevel {
    seen: bool,
    start_line: usize,
    end_line: usize,
    calls: Vec<CallSite>,
}

fn visit(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    out: &mut ParsedProject,
    top: &mut TopLevel,
) {
    let kind = node.kind();

    if FUNCTION_KINDS.contains(&kind) {
        parse_function(node, source, file, owner, out);
        return;
    }

    if kind == NODE_GLOBAL_STATEMENT {
        let start = node.start_position().row + 1;
        let end = node.end_position().row + 1;
        if !top.seen {
            top.seen = true;
            top.start_line = start;
        }
        top.end_line = top.end_line.max(end);
        let mut calls = ParsedProject::default();
        collect_calls(node, source, file, "", &mut calls);
        top.calls.extend(calls.calls);
        // local functions внутри top-level — отдельные функции
        parse_local_functions(node, source, file, None, out);
        return;
    }

    let next_owner = if TYPE_KINDS.contains(&kind) {
        type_name(node, source).or(owner)
    } else {
        owner
    };

    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        visit(child, source, file, next_owner.clone(), out, top);
    }
}

fn type_name(node: Node, source: &str) -> Option<String> {
    if let Some(n) = node.child_by_field_name("name") {
        return Some(node_text(n, source));
    }
    find_child_of_kind(node, NODE_IDENTIFIER).map(|n| node_text(n, source))
}

fn function_name(node: Node, source: &str) -> Option<String> {
    if let Some(n) = node.child_by_field_name("name") {
        return Some(node_text(n, source));
    }
    // fallback: последний identifier перед parameter_list
    let mut last_ident = None;
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_PARAMETER_LIST {
            break;
        }
        if child.kind() == NODE_IDENTIFIER {
            last_ident = Some(node_text(child, source));
        }
    }
    last_ident
}

fn parse_function(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    out: &mut ParsedProject,
) {
    let Some(name) = function_name(node, source) else { return };
    let id = make_function_id(file, owner.as_deref(), &name, node.start_position().row + 1);

    out.functions.push(FunctionDef {
        id: id.clone(),
        name,
        owner: owner.clone(),
        receiver_type: None,
        file: file.to_string(),
        start_line: node.start_position().row + 1,
        end_line: node.end_position().row + 1,
        annotations: collect_annotations(node, source),
        param_annotations: Vec::new(),
    });

    collect_calls(node, source, file, &id, out);
    parse_local_functions(node, source, file, owner, out);
}

/// Атрибуты метода + атрибуты его параметров (как в Kotlin-парсере: всё в annotations).
fn collect_annotations(func: Node, source: &str) -> Vec<String> {
    let mut result = Vec::new();
    let mut cursor = func.walk();
    for child in func.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_ATTRIBUTE_LIST => push_attributes(child, source, &mut result),
            k if k == NODE_PARAMETER_LIST => {
                let mut pc = child.walk();
                for param in child.children(&mut pc) {
                    if param.kind() != NODE_PARAMETER {
                        continue;
                    }
                    let mut ac = param.walk();
                    for p in param.children(&mut ac) {
                        if p.kind() == NODE_ATTRIBUTE_LIST {
                            push_attributes(p, source, &mut result);
                        }
                    }
                }
            }
            _ => {}
        }
    }
    result
}

fn push_attributes(list: Node, source: &str, out: &mut Vec<String>) {
    let mut cursor = list.walk();
    for attr in list.children(&mut cursor) {
        if attr.kind() == NODE_ATTRIBUTE {
            out.push(format!("@{}", node_text(attr, source)));
        }
    }
}

/// Ищет local functions внутри узла (не заходя в сами local functions) и
/// разбирает их как отдельные функции.
fn parse_local_functions(
    node: Node,
    source: &str,
    file: &str,
    owner: Option<String>,
    out: &mut ParsedProject,
) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_LOCAL_FUNCTION {
            parse_function(child, source, file, owner.clone(), out);
        } else {
            parse_local_functions(child, source, file, owner.clone(), out);
        }
    }
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        let kind = child.kind();
        if kind == NODE_LOCAL_FUNCTION {
            continue; // у local function своя запись, вызов к ней резолвится по имени
        }
        if kind == NODE_INVOCATION {
            if let Some((name, receiver)) = invocation_info(child, source) {
                push_call(out, caller_id, file, child, name, receiver);
            }
        } else if kind == NODE_OBJECT_CREATION {
            if let Some(ty) = child.child_by_field_name("type") {
                let name = simple_type_name(&node_text(ty, source));
                if !name.is_empty() {
                    push_call(out, caller_id, file, child, name, None);
                }
            }
        } else if kind == NODE_MEMBER_ACCESS && !is_invocation_target(child) {
            if let Some(name_node) = child.child_by_field_name("name") {
                let name = generic_ident(name_node, source);
                if PROPERTY_SOURCES.contains(&name.as_str()) {
                    let receiver = child
                        .child_by_field_name("expression")
                        .map(|e| receiver_text(e, source));
                    push_call(out, caller_id, file, child, name, receiver);
                }
            }
        }
        collect_calls(child, source, file, caller_id, out);
    }
}

fn push_call(
    out: &mut ParsedProject,
    caller: &str,
    file: &str,
    node: Node,
    name: String,
    receiver: Option<String>,
) {
    out.calls.push(CallSite {
        caller: caller.to_string(),
        callee_name: name,
        receiver,
        callee_resolved: None,
        file: file.to_string(),
        line: node.start_position().row + 1,
    });
}

/// true, если member_access — это `function` у invocation_expression (тогда его
/// уже учтёт invocation_info, а как pseudo-call писать не надо).
fn is_invocation_target(node: Node) -> bool {
    match node.parent() {
        Some(p) if p.kind() == NODE_INVOCATION => p
            .child_by_field_name("function")
            .map(|f| f.id() == node.id())
            .unwrap_or_else(|| p.child(0).map(|f| f.id() == node.id()).unwrap_or(false)),
        _ => false,
    }
}

/// (имя_вызова, receiver)
fn invocation_info(call: Node, source: &str) -> Option<(String, Option<String>)> {
    let func = call.child_by_field_name("function").or_else(|| call.child(0))?;
    match func.kind() {
        k if k == NODE_IDENTIFIER || k == NODE_GENERIC_NAME => {
            Some((generic_ident(func, source), None))
        }
        k if k == NODE_MEMBER_ACCESS => {
            let name = generic_ident(func.child_by_field_name("name")?, source);
            let receiver = func
                .child_by_field_name("expression")
                .map(|e| receiver_text(e, source));
            Some((name, receiver))
        }
        // `a?.Foo()` — receiver лежит у охватывающего conditional_access_expression
        k if k == NODE_MEMBER_BINDING => {
            let name = generic_ident(func.child_by_field_name("name")?, source);
            let mut parent = call.parent();
            let mut receiver = None;
            while let Some(p) = parent {
                if p.kind() == NODE_COND_ACCESS {
                    receiver = p
                        .child_by_field_name("condition")
                        .or_else(|| p.child(0))
                        .map(|e| receiver_text(e, source));
                    break;
                }
                parent = p.parent();
            }
            Some((name, receiver))
        }
        _ => None,
    }
}

/// identifier -> текст; generic_name (`Foo<T>`) -> "Foo".
fn generic_ident(node: Node, source: &str) -> String {
    if node.kind() == NODE_GENERIC_NAME {
        if let Some(id) = find_child_of_kind(node, NODE_IDENTIFIER) {
            return node_text(id, source);
        }
    }
    node_text(node, source)
}

/// Последний сегмент выражения-получателя.
fn receiver_text(expr: Node, source: &str) -> String {
    match expr.kind() {
        k if k == NODE_IDENTIFIER || k == NODE_GENERIC_NAME => generic_ident(expr, source),
        k if k == NODE_MEMBER_ACCESS => expr
            .child_by_field_name("name")
            .map(|n| generic_ident(n, source))
            .unwrap_or_else(|| truncate(node_text(expr, source))),
        "this_expression" => "this".to_string(),
        _ => truncate(node_text(expr, source)),
    }
}

/// `System.Data.SqlClient.SqlCommand<T>` -> "SqlCommand"
fn simple_type_name(text: &str) -> String {
    let no_generics = text.split('<').next().unwrap_or(text);
    no_generics
        .rsplit('.')
        .next()
        .unwrap_or(no_generics)
        .trim()
        .to_string()
}

fn truncate(s: String) -> String {
    if s.chars().count() > 60 {
        s.chars().take(60).collect()
    } else {
        s
    }
}

fn find_child_of_kind<'a>(node: Node<'a>, kind: &str) -> Option<Node<'a>> {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == kind {
            return Some(child);
        }
    }
    None
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

/// Строка в id нужна, чтобы перегрузки (одинаковое имя в одном классе) не
/// склеивались в один узел графа.
fn make_function_id(file: &str, owner: Option<&str>, name: &str, line: usize) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}@{line}"),
        None => format!("{file}::{name}@{line}"),
    }
}
