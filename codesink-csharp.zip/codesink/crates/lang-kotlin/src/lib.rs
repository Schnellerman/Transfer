//! Парсинг .kt файлов через tree-sitter-kotlin.
//!
//! ВАЖНО: используемая версия грамматики (crate tree-sitter-kotlin 0.3.8) НЕ
//! экспонирует именованные поля (field_name) для function_declaration —
//! child_by_field_name("name"/"body"/"receiver_type") всегда возвращает None.
//! Поэтому вся структура разбирается позиционно, по порядку прямых потомков
//! и их kind(). ЭТО ПРОВЕРЕНО НА РЕАЛЬНОМ КОДЕ (см. bin/debug_parse.rs) — в
//! отличие от lang-go/lang-js/lang-rust/lang-python, которые пока не
//! проверялись на реальных файлах.

use anyhow::{Context, Result};
use codesink_core::model::{CallSite, FunctionDef, ParsedProject};
use std::path::Path;
use tree_sitter::{Node, Parser, Tree};

const NODE_FUNCTION_DECL: &str = "function_declaration";
const NODE_CLASS_DECL: &str = "class_declaration";
const NODE_OBJECT_DECL: &str = "object_declaration";
const NODE_CALL_EXPR: &str = "call_expression";
const NODE_NAVIGATION_EXPR: &str = "navigation_expression";
const NODE_NAVIGATION_SUFFIX: &str = "navigation_suffix";
const NODE_SIMPLE_IDENTIFIER: &str = "simple_identifier";
const NODE_ANNOTATION: &str = "annotation";
const NODE_USER_TYPE: &str = "user_type";
const NODE_TYPE_IDENTIFIER: &str = "type_identifier";
const NODE_MODIFIERS: &str = "modifiers";
const NODE_FUNCTION_VALUE_PARAMS: &str = "function_value_parameters";
const NODE_FUNCTION_BODY: &str = "function_body";

pub fn make_parser() -> Result<Parser> {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_kotlin::language())
        .context("failed to load kotlin grammar")?;
    Ok(parser)
}

pub fn dump_sexp(source: &str) -> Result<String> {
    let mut parser = make_parser()?;
    let tree = parser.parse(source, None).context("parse failed")?;
    Ok(tree.root_node().to_sexp())
}

pub fn parse_file(path: &Path, source: &str) -> Result<ParsedProject> {
    let mut parser = make_parser()?;
    let tree: Tree = parser.parse(source, None).context("parse failed")?;
    let root = tree.root_node();
    let file_str = path.to_string_lossy().to_string();

    let mut result = ParsedProject::default();
    walk_declarations(root, source, &file_str, None, &mut result);
    Ok(result)
}

fn walk_declarations(
    node: Node,
    source: &str,
    file: &str,
    current_owner: Option<String>,
    out: &mut ParsedProject,
) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_CLASS_DECL || k == NODE_OBJECT_DECL => {
                let owner_name = find_child_of_kind(child, NODE_TYPE_IDENTIFIER)
                    .map(|n| node_text(n, source));
                walk_declarations(child, source, file, owner_name, out);
            }
            k if k == NODE_FUNCTION_DECL => {
                let shape = parse_function_shape(child);

                let name = shape
                    .name
                    .map(|n| node_text(n, source))
                    .unwrap_or_else(|| "<anonymous>".to_string());
                let receiver = shape.receiver.map(|n| node_text(n, source));
                let owner = receiver.clone().or_else(|| current_owner.clone());
                let id = make_function_id(file, owner.as_deref(), &name);

                let annotations = find_child_of_kind(child, NODE_MODIFIERS)
                    .map(|m| collect_annotations(m, source))
                    .unwrap_or_default();
                let param_annotations = shape
                    .params
                    .map(|p| collect_annotations(p, source))
                    .unwrap_or_default();

                out.functions.push(FunctionDef {
                    id: id.clone(),
                    name,
                    owner,
                    receiver_type: receiver,
                    file: file.to_string(),
                    start_line: child.start_position().row + 1,
                    end_line: child.end_position().row + 1,
                    annotations,
                    param_annotations,
                });

                if let Some(body) = shape.body {
                    collect_calls(body, source, file, &id, out);
                }

                walk_declarations(child, source, file, current_owner.clone(), out);
            }
            _ => {
                walk_declarations(child, source, file, current_owner.clone(), out);
            }
        }
    }
}

struct FunctionShape<'a> {
    receiver: Option<Node<'a>>,
    name: Option<Node<'a>>,
    params: Option<Node<'a>>,
    body: Option<Node<'a>>,
}

fn parse_function_shape(node: Node) -> FunctionShape {
    let mut receiver = None;
    let mut name = None;
    let mut params: Option<Node> = None;
    let mut body = None;
    let mut seen_name = false;

    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        match child.kind() {
            k if k == NODE_MODIFIERS => continue,
            k if k == NODE_SIMPLE_IDENTIFIER && !seen_name => {
                name = Some(child);
                seen_name = true;
            }
            k if k == NODE_USER_TYPE && !seen_name => {
                receiver = Some(child);
            }
            k if k == NODE_FUNCTION_VALUE_PARAMS => {
                params = Some(child);
            }
            k if k == NODE_FUNCTION_BODY => {
                body = Some(child);
            }
            _ => {}
        }
    }

    FunctionShape { receiver, name, params, body }
}

fn collect_calls(node: Node, source: &str, file: &str, caller_id: &str, out: &mut ParsedProject) {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_CALL_EXPR {
            if let Some((callee_name, receiver)) = extract_call_info(child, source) {
                out.calls.push(CallSite {
                    caller: caller_id.to_string(),
                    callee_name,
                    receiver,
                    callee_resolved: None,
                    file: file.to_string(),
                    line: child.start_position().row + 1,
                });
            }
        }
        collect_calls(child, source, file, caller_id, out);
    }
}

/// Возвращает (имя_вызова, receiver). receiver — базовый идентификатор
/// слева от точки ("stmt" в "stmt.execute()"), нужен, чтобы owner в
/// правилах мог отличать, например, objectMapper.readValue от json.readValue.
fn extract_call_info(call_node: Node, source: &str) -> Option<(String, Option<String>)> {
    let func_node = call_node.child(0)?;
    match func_node.kind() {
        k if k == NODE_SIMPLE_IDENTIFIER => Some((node_text(func_node, source), None)),
        k if k == NODE_NAVIGATION_EXPR => {
            let name = extract_callee_name(call_node, source)?;
            let receiver = extract_receiver_base(func_node, source);
            Some((name, receiver))
        }
        _ => None,
    }
}

/// Спускается к первому потомку navigation_expression, пока не найдёт
/// simple_identifier — это и есть базовый объект вызова.
fn extract_receiver_base(func_node: Node, source: &str) -> Option<String> {
    let mut current = func_node.child(0)?;
    for _ in 0..10 {
        if current.kind() == NODE_SIMPLE_IDENTIFIER {
            return Some(node_text(current, source));
        }
        current = current.child(0)?;
    }
    None
}

fn extract_callee_name(call_node: Node, source: &str) -> Option<String> {
    let func_node = call_node.child(0)?;
    match func_node.kind() {
        k if k == NODE_SIMPLE_IDENTIFIER => Some(node_text(func_node, source)),
        k if k == NODE_NAVIGATION_EXPR => {
            let mut cursor = func_node.walk();
            let mut last_suffix_ident = None;
            for n in func_node.children(&mut cursor) {
                if n.kind() == NODE_NAVIGATION_SUFFIX {
                    if let Some(ident) = find_child_of_kind(n, NODE_SIMPLE_IDENTIFIER) {
                        last_suffix_ident = Some(ident);
                    }
                }
            }
            last_suffix_ident.map(|n| node_text(n, source))
        }
        _ => None,
    }
}

fn collect_annotations(node: Node, source: &str) -> Vec<String> {
    let mut result = Vec::new();
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == NODE_ANNOTATION {
            result.push(node_text(child, source));
        }
        result.extend(collect_annotations(child, source));
    }
    result
}

fn find_child_of_kind<'a>(node: Node<'a>, kind: &str) -> Option<Node<'a>> {
    let mut cursor = node.walk();
    for child in node.children(&mut cursor) {
        if child.kind() == kind {
            return Some(child);
        }
    }
    None
}

fn node_text(node: Node, source: &str) -> String {
    node.utf8_text(source.as_bytes()).unwrap_or_default().to_string()
}

fn make_function_id(file: &str, owner: Option<&str>, name: &str) -> String {
    match owner {
        Some(o) => format!("{file}::{o}.{name}"),
        None => format!("{file}::{name}"),
    }
}
