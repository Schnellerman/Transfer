use crate::model::{CallSite, Confidence, Finding, FunctionId, MatchKind, RuleMatch};
use crate::rules::any_rule_matches_call;
use petgraph::graph::{DiGraph, NodeIndex};
use petgraph::visit::EdgeRef;
use std::collections::{HashMap, HashSet};

pub struct CallGraph {
    graph: DiGraph<FunctionId, ()>,
    index_by_id: HashMap<FunctionId, NodeIndex>,
}

impl CallGraph {
    pub fn build(function_ids: &[FunctionId], calls: &[CallSite]) -> Self {
        let mut graph = DiGraph::new();
        let mut index_by_id = HashMap::new();

        for id in function_ids {
            let idx = graph.add_node(id.clone());
            index_by_id.insert(id.clone(), idx);
        }

        for call in calls {
            if let Some(callee) = &call.callee_resolved {
                if let (Some(&from), Some(&to)) =
                    (index_by_id.get(&call.caller), index_by_id.get(callee))
                {
                    graph.add_edge(from, to, ());
                }
            }
        }

        Self { graph, index_by_id }
    }

    /// Ищет пути source -> (функция, которая делает sink-вызов). Source
    /// определяется ДВУМЯ способами: (1) function-level match из `matches`
    /// (аннотации типа @RequestParam на объявленной функции — характерно для
    /// Kotlin/Java) и (2) call-level match по source_rules (вызов вроде
    /// `r.URL.Query().Get()` в Go или `request.args.get()` в Python — там,
    /// где нет аннотаций, source — это сам факт вызова). Функция, которая
    /// делает такой вызов, становится стартовой точкой поиска.
    pub fn find_findings(
        &self,
        calls: &[CallSite],
        matches: &[RuleMatch],
        source_rules: &[crate::rules::Rule],
        sink_rules: &[crate::rules::Rule],
        sanitizer_rules: &[crate::rules::Rule],
        max_depth: usize,
    ) -> Vec<Finding> {
        let mut calls_by_caller: HashMap<&FunctionId, Vec<&CallSite>> = HashMap::new();
        for c in calls {
            calls_by_caller.entry(&c.caller).or_default().push(c);
        }

        let mut sources: HashSet<&FunctionId> = matches
            .iter()
            .filter(|m| m.kind == MatchKind::Source)
            .map(|m| &m.function_id)
            .collect();

        if !source_rules.is_empty() {
            for (caller, caller_calls) in &calls_by_caller {
                if caller_calls.iter().any(|c| any_rule_matches_call(source_rules, &c.callee_name, c.receiver.as_deref())) {
                    sources.insert(caller);
                }
            }
        }

        // Function-level sink/sanitizer метки — это в основном ручная разметка
        // (см. manual_annotations), потому что автоматические sink-правила
        // почти всегда матчат вызовы внешних API, а не объявленные функции.
        let manual_sink_fns: HashSet<&FunctionId> = matches
            .iter()
            .filter(|m| m.kind == MatchKind::Sink)
            .map(|m| &m.function_id)
            .collect();
        let manual_sanitizer_fns: HashSet<&FunctionId> = matches
            .iter()
            .filter(|m| m.kind == MatchKind::Sanitizer)
            .map(|m| &m.function_id)
            .collect();

        let mut findings = Vec::new();

        for source in sources {
            let Some(&start) = self.index_by_id.get(source) else {
                continue;
            };
            let mut path = vec![start];
            self.dfs(
                start,
                &calls_by_caller,
                sink_rules,
                sanitizer_rules,
                &manual_sink_fns,
                &manual_sanitizer_fns,
                max_depth,
                false,
                &mut path,
                &mut findings,
                source,
            );
        }

        findings
    }

    #[allow(clippy::too_many_arguments)]
    fn dfs(
        &self,
        current: NodeIndex,
        calls_by_caller: &HashMap<&FunctionId, Vec<&CallSite>>,
        sink_rules: &[crate::rules::Rule],
        sanitizer_rules: &[crate::rules::Rule],
        manual_sink_fns: &HashSet<&FunctionId>,
        manual_sanitizer_fns: &HashSet<&FunctionId>,
        remaining_depth: usize,
        sanitized_so_far: bool,
        path: &mut Vec<NodeIndex>,
        findings: &mut Vec<Finding>,
        source: &FunctionId,
    ) {
        let current_id = &self.graph[current];

        // Санитайзер мог быть вызван прямо в текущей функции, либо сама
        // функция размечена вручную как sanitizer.
        let sanitized_here = manual_sanitizer_fns.contains(current_id)
            || calls_by_caller
                .get(current_id)
                .map(|calls| calls.iter().any(|c| any_rule_matches_call(sanitizer_rules, &c.callee_name, c.receiver.as_deref())))
                .unwrap_or(false);
        let sanitized = sanitized_so_far || sanitized_here;

        // Вариант 1: текущая функция сама размечена вручную как sink
        // (ручная аннотация на строке внутри неё).
        if manual_sink_fns.contains(current_id) {
            let path_ids: Vec<FunctionId> =
                path.iter().map(|&idx| self.graph[idx].clone()).collect();
            findings.push(Finding {
                source: source.clone(),
                sink_name: format!("manual: {}", current_id.split("::").last().unwrap_or(current_id)),
                sink_file: current_id.split("::").next().unwrap_or_default().to_string(),
                sink_line: 0,
                path: path_ids,
                sanitized,
                confidence: if sanitized { Confidence::Low } else { Confidence::High },
            });
        }

        // Вариант 2: текущая функция делает вызов, матчащийся под sink-правило
        // (execute, ProcessBuilder и т.д. — внешние API).
        if let Some(calls) = calls_by_caller.get(current_id) {
            for call in calls {
                if any_rule_matches_call(sink_rules, &call.callee_name, call.receiver.as_deref()) {
                    let path_ids: Vec<FunctionId> =
                        path.iter().map(|&idx| self.graph[idx].clone()).collect();
                    findings.push(Finding {
                        source: source.clone(),
                        sink_name: call.callee_name.clone(),
                        sink_file: call.file.clone(),
                        sink_line: call.line,
                        path: path_ids,
                        sanitized,
                        confidence: if sanitized {
                            Confidence::Low
                        } else {
                            Confidence::Medium
                        },
                    });
                }
            }
        }

        if remaining_depth == 0 {
            return;
        }

        for edge in self.graph.edges(current) {
            let next = edge.target();
            if path.contains(&next) {
                continue; // избегаем циклов
            }
            path.push(next);
            self.dfs(
                next,
                calls_by_caller,
                sink_rules,
                sanitizer_rules,
                manual_sink_fns,
                manual_sanitizer_fns,
                remaining_depth - 1,
                sanitized,
                path,
                findings,
                source,
            );
            path.pop();
        }
    }

    pub fn node_count(&self) -> usize {
        self.graph.node_count()
    }

    pub fn edge_count(&self) -> usize {
        self.graph.edge_count()
    }
}
