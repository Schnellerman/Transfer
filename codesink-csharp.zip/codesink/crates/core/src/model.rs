use serde::{Deserialize, Serialize};

/// Уникальный идентификатор функции внутри проекта: "путь/к/файлу.kt::имяФункции"
/// Упрощение для MVP — не учитывает перегрузку по сигнатуре и generic-параметры.
pub type FunctionId = String;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FunctionDef {
    pub id: FunctionId,
    pub name: String,
    /// Класс/объект, которому принадлежит функция (если есть)
    pub owner: Option<String>,
    /// Receiver-тип, если это extension-функция Kotlin (fun String.foo())
    pub receiver_type: Option<String>,
    pub file: String,
    pub start_line: usize,
    pub end_line: usize,
    /// Аннотации на функции: @RequestMapping, @PostMapping и т.д.
    pub annotations: Vec<String>,
    /// Аннотации на параметрах: @RequestParam, @RequestBody
    pub param_annotations: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CallSite {
    /// Кто вызывает
    pub caller: FunctionId,
    /// Текстовое имя вызываемой функции (до резолвинга)
    pub callee_name: String,
    /// Текстовое имя получателя вызова (например "pickle" в "pickle.load(f)",
    /// "db" в "db.query(sql)") — если вызов вида a.b(...). None для прямых
    /// вызовов вида foo(...) без получателя. Это НЕ анализ типов — просто
    /// исходный текст идентификатора слева от точки, поэтому легко обмануть
    /// переименованием импорта (import pickle as p), но для честного кода
    /// разруливает большинство коллизий вроде json.load vs pickle.load.
    pub receiver: Option<String>,
    /// Резолвленный FunctionId вызываемой функции, если удалось найти
    pub callee_resolved: Option<FunctionId>,
    pub file: String,
    pub line: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleMatch {
    pub function_id: FunctionId,
    pub kind: MatchKind,
    pub rule_name: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MatchKind {
    Source,
    Sink,
    Sanitizer,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Finding {
    pub source: FunctionId,
    /// Имя вызванной sink-функции (например "execute", "exec") — это вызов
    /// внешнего API, а не функция, объявленная в проекте, поэтому здесь имя,
    /// а не FunctionId.
    pub sink_name: String,
    pub sink_file: String,
    pub sink_line: usize,
    /// Путь вызовов функций проекта от source до функции, которая делает sink-вызов
    pub path: Vec<FunctionId>,
    pub sanitized: bool,
    pub confidence: Confidence,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Confidence {
    Low,
    Medium,
    High,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ParsedProject {
    pub functions: Vec<FunctionDef>,
    pub calls: Vec<CallSite>,
}
