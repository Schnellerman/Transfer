//! Простая таблица символов: сопоставляет текстовое имя вызова (callee_name)
//! с FunctionId по всему проекту.
//!
//! Ограничения MVP (осознанно упрощено, чтобы не тонуть в edge-кейсах Kotlin):
//! - не учитывает перегрузку функций по сигнатуре — если имён-омонимов
//!   несколько, берём первый найденный кандидат и это может давать
//!   ложные пути в графе. Для secure code review это приемлемо: ты всё равно
//!   верифицируешь путь глазами, а не доверяешь тулзе вслепую.
//! - scope-функции (let/apply/also/run/with) не разворачиваются автоматически —
//!   вызовы внутри их лямбд просто попадают в тот же caller, что и снаружи,
//!   так как AST-обход не создаёт для лямбды отдельный caller-контекст.

use crate::model::ParsedProject;
use std::collections::HashMap;

/// name -> все FunctionId с таким именем (могут быть в разных файлах/классах)
pub struct SymbolTable {
    by_name: HashMap<String, Vec<String>>,
    /// "ReceiverType::name" -> FunctionId, для точного резолвинга extension-функций
    by_receiver_and_name: HashMap<String, String>,
}

impl SymbolTable {
    pub fn build(project: &ParsedProject) -> Self {
        let mut by_name: HashMap<String, Vec<String>> = HashMap::new();
        let mut by_receiver_and_name = HashMap::new();

        for f in &project.functions {
            by_name.entry(f.name.clone()).or_default().push(f.id.clone());
            if let Some(receiver) = &f.receiver_type {
                by_receiver_and_name.insert(format!("{receiver}::{}", f.name), f.id.clone());
            }
        }

        Self {
            by_name,
            by_receiver_and_name,
        }
    }

    /// Резолвит имя вызова в FunctionId. receiver_hint — если известен тип
    /// объекта, на котором вызывается метод (для будущего расширения; в MVP
    /// обычно None, потому что мы не делаем полноценный type inference).
    pub fn resolve(&self, callee_name: &str, receiver_hint: Option<&str>) -> Option<String> {
        if let Some(receiver) = receiver_hint {
            if let Some(id) = self
                .by_receiver_and_name
                .get(&format!("{receiver}::{callee_name}"))
            {
                return Some(id.clone());
            }
        }
        self.by_name.get(callee_name).and_then(|v| v.first()).cloned()
    }
}

/// Проставляет callee_resolved на всех CallSite проекта, используя таблицу символов.
pub fn resolve_calls(project: &mut ParsedProject) {
    let table = SymbolTable::build(project);
    for call in &mut project.calls {
        call.callee_resolved = table.resolve(&call.callee_name, None);
    }
}
