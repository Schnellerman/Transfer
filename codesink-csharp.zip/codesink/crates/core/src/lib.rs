pub mod graph;
pub mod model;
pub mod rules;
pub mod symbols;

use anyhow::Result;
use model::{Finding, MatchKind, ParsedProject, RuleMatch};
use rules::RuleSet;

pub struct AnalysisResult {
    pub parsed: ParsedProject,
    pub findings: Vec<Finding>,
    pub node_count: usize,
    pub edge_count: usize,
}

/// Ручная метка: путь к файлу (в том же формате, что FunctionDef.file — то есть
/// как его вернул конкретный языковой парсер), номер строки, вид метки.
pub struct ManualAnnotation {
    pub file: String,
    pub line: usize,
    pub kind: MatchKind,
}

/// Языко-агностичная точка входа: принимает УЖЕ распарсенный проект (парсинг —
/// забота конкретного языкового крейта, см. crates/lang-*), резолвит вызовы,
/// применяет правила (+ опционально ручную разметку) и ищет пути source -> sink.
/// Если проект смешанный (несколько языков), просто объедини их ParsedProject
/// перед вызовом (functions.extend(...), calls.extend(...)) и передай сюда один раз.
pub fn analyze_project(
    mut project: ParsedProject,
    rules: &RuleSet,
    manual_annotations: &[ManualAnnotation],
    max_depth: usize,
) -> Result<AnalysisResult> {
    symbols::resolve_calls(&mut project);

    let mut matches = rules::match_rules(&project.functions, rules);
    matches.extend(resolve_manual_annotations(&project, manual_annotations));

    let function_ids: Vec<String> = project.functions.iter().map(|f| f.id.clone()).collect();
    let call_graph = graph::CallGraph::build(&function_ids, &project.calls);
    let findings = call_graph.find_findings(
        &project.calls,
        &matches,
        &rules.sources,
        &rules.sinks,
        &rules.sanitizers,
        max_depth,
    );

    Ok(AnalysisResult {
        node_count: call_graph.node_count(),
        edge_count: call_graph.edge_count(),
        parsed: project,
        findings,
    })
}

fn resolve_manual_annotations(
    project: &ParsedProject,
    annotations: &[ManualAnnotation],
) -> Vec<RuleMatch> {
    let mut result = Vec::new();
    for ann in annotations {
        if let Some(f) = project.functions.iter().find(|f| {
            f.file == ann.file && ann.line >= f.start_line && ann.line <= f.end_line
        }) {
            result.push(RuleMatch {
                function_id: f.id.clone(),
                kind: ann.kind,
                rule_name: "manual".to_string(),
            });
        }
    }
    result
}
