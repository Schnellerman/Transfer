use crate::model::{FunctionDef, MatchKind, RuleMatch};
use anyhow::{Context, Result};
use serde::Deserialize;

#[derive(Debug, Deserialize, Clone)]
pub struct RuleSet {
    pub language: String,
    #[serde(default)]
    pub sources: Vec<Rule>,
    #[serde(default)]
    pub sinks: Vec<Rule>,
    #[serde(default)]
    pub sanitizers: Vec<Rule>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct Rule {
    pub name: String,
    /// Матчить по точному имени функции (например "exec")
    #[serde(default)]
    pub function_name: Vec<String>,
    /// Матчить по аннотации на функции/параметре (например "@RequestParam")
    #[serde(default)]
    pub annotation: Vec<String>,
    /// Матчить по owner/классу (например "ProcessBuilder")
    #[serde(default)]
    pub owner: Vec<String>,
}

impl RuleSet {
    pub fn load_from_str(yaml: &str) -> Result<Self> {
        serde_yaml::from_str(yaml).context("failed to parse rules YAML")
    }
}

fn rule_matches(rule: &Rule, f: &FunctionDef) -> bool {
    if rule.function_name.iter().any(|n| n == &f.name) {
        return true;
    }
    if let Some(owner) = &f.owner {
        if rule.owner.iter().any(|o| o == owner) {
            return true;
        }
    }
    let all_annotations = f.annotations.iter().chain(f.param_annotations.iter());
    for ann in all_annotations {
        if rule.annotation.iter().any(|a| ann.contains(a.as_str())) {
            return true;
        }
    }
    false
}

/// Матчит вызов (CallSite.callee_name) против правила — только по имени функции.
/// В отличие от rule_matches (для FunctionDef), здесь НЕ проверяется owner,
/// потому что для произвольного вызова `a.b()` мы не знаем реальный тип `a`
/// без полноценного type inference (см. ограничения в symbols.rs). Это значит:
/// если у тебя в проекте есть своя функция с тем же именем, что у sink-паттерна
/// (например собственная `execute()` с другим смыслом), она тоже даст findings —
/// придётся сузить function_name в конфиге под конкретный проект, если это
/// станет реальной проблемой ложных срабатываний.
/// Матчит вызов (CallSite) против правила по имени функции и, если в
/// правиле указан owner, дополнительно по receiver (текст слева от точки:
/// "pickle" в "pickle.load(f)"). Если owner в правиле пуст — матчим по
/// имени независимо от receiver (как раньше). Если owner указан, а у
/// вызова receiver — None (прямой вызов без точки) — не матчим, чтобы не
/// давать ложных срабатываний.
pub fn rule_matches_call(rule: &Rule, callee_name: &str, receiver: Option<&str>) -> bool {
    if !rule.function_name.iter().any(|n| n == callee_name) {
        return false;
    }
    if rule.owner.is_empty() {
        return true;
    }
    match receiver {
        Some(r) => rule.owner.iter().any(|o| o == r),
        None => false,
    }
}

pub fn any_rule_matches_call(rules: &[Rule], callee_name: &str, receiver: Option<&str>) -> bool {
    rules.iter().any(|r| rule_matches_call(r, callee_name, receiver))
}
pub fn match_rules(functions: &[FunctionDef], rules: &RuleSet) -> Vec<RuleMatch> {
    let mut matches = Vec::new();
    for f in functions {
        for r in &rules.sources {
            if rule_matches(r, f) {
                matches.push(RuleMatch {
                    function_id: f.id.clone(),
                    kind: MatchKind::Source,
                    rule_name: r.name.clone(),
                });
            }
        }
        for r in &rules.sinks {
            if rule_matches(r, f) {
                matches.push(RuleMatch {
                    function_id: f.id.clone(),
                    kind: MatchKind::Sink,
                    rule_name: r.name.clone(),
                });
            }
        }
        for r in &rules.sanitizers {
            if rule_matches(r, f) {
                matches.push(RuleMatch {
                    function_id: f.id.clone(),
                    kind: MatchKind::Sanitizer,
                    rule_name: r.name.clone(),
                });
            }
        }
    }
    matches
}
